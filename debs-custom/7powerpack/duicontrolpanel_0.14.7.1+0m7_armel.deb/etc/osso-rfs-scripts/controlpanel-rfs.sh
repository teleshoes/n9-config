#! /bin/sh

#
# Reset factory settings script for controlpanel.
#
gconftool-2 --recursive-unset /apps/duicontrolpanel

