//var pageSettingsObject
//var pageAboutObject

WorkerScript.onMessage = function(message) {
     WorkerScript.sendMessage({ 'reply': message.searchword })
 }

/*function generatePages() {
    var pageSettings = Qt.createComponent("Settings.qml");
    var pageAbout = Qt.createComponent("About.qml");

    pageSettingsObject = pageSettings.createObject(pageSettings);
    pageAboutObject = pageAbout.createObject(pageAbout);
}

function getSettingsPage() {
    return pageSettingsObject;
}

function getAboutPage() {
    return pageAboutObject;
}*/
