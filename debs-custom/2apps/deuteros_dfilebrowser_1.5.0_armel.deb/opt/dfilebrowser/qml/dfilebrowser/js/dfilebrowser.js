//! Sets the visibility of aboutItem
/*!
  Sets the visibility of aboutItem which is a button in the BrowserButtons bar for desktop and a menu option
    in appMenu for mobile devices
  \param visible Determines if the button is shown or not
  */
function aboutItemVisible(visible){
    if (typeof appMenuButton=="undefined"){ //appMenuButton does not exist on desktop environments
        if (visible)
            browserButtons.aboutItemVisible=true;
        else
            browserButtons.aboutItemVisible=false;
        console.log("Button visible")
    }
    else if (appMenuButton.status!="undefined"){
        if (visible)
            appMenu.aboutItemVisible=true;
        else
            appMenu.aboutItemVisible=false;
        console.log("Item visible")
    }
}

//! Sets the visibility of applicationButton
/*!
  Sets the visibility of appMenuButton located next to the BrowserButtons bar. This button is only available on mobile environments
  \param visible Determines if the button is shown or not
  */
function appMenuButtonVisible(visible){
    if (visible)
        appMenuButton.visible=true;
    else
        appMenuButton.visible=false;
}
