function goHome() {
    fBrowser.historyPush(dirview.model.rootIndex);
    fBrowser.futureClear()
    dirview.model.rootIndex = fBrowser.getIndexFromModel(fBrowser.homeDir)
    mainWindow.refresh();
}

function goBack(){
    if  (!fBrowser.historyIsEmpty()){
        fBrowser.futurePush(dirview.model.rootIndex)
        var newindex =fBrowser.historyPop()
        dirview.model.rootIndex = newindex
        mainWindow.refresh();
    }
}

function goNext(){
    if  (!fBrowser.futureIsEmpty()){
        fBrowser.historyPush(dirview.model.rootIndex)
        var newindex =fBrowser.futurePop
        dirview.model.rootIndex = newindex
        mainWindow.refresh();
    }
}

function goUp(){
    fBrowser.historyPush(dirview.model.rootIndex);
    fBrowser.futureClear()
    dirview.model.rootIndex =dirview.model.parentModelIndex
    mainWindow.refresh()
}

//! Returns a formatted file size for a given index
/*!
  Returns a formatted file size for a given index
  \param index File index in the data model
  */
function fileInfo(index){
    var displayRole=0;
    var info=eval('('+fBrowser.data(dirview.model.modelIndex(index),displayRole)+')');
    var size=info["size"];
    var returnValue=info["modified"] + " | "+ formattedFileSize(size);

    return returnValue;
}

//! Returns a formatted file size for a given index
/*!
  Returns a formatted file size for a given index
  \param size Raw file size (int)
  */
function formattedFileSize(size){
    var returnValue="";
    if (size<1024)
        returnValue= Math.floor(size)+ " Bytes";
    else if (size<1024*1024)
        returnValue= Math.floor(size/1024)+ " KB";
    else if (size<1024*1024*1024)
        returnValue+= Math.floor(size/(1024*1024))+ " MB";
    else
        returnValue= Math.floor(size/(1024*1024*1024))+ " GB";
    return returnValue;
}
