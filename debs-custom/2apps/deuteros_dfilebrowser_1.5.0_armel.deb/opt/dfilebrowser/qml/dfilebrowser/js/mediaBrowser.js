/* Functions used in the media browser to show information about files or MediaInformation
  This data is displayed using some labels on a column layout.
  In addition there are some functions helping to display some controls (i.e buttons)
  */
Qt.include("actions.js")

//! Fills data labels with information from QFileInfo
/*!
  Fills data labels with information from QFileInfo. Normally is used when the file has not tagged data
  (ie an MP3 tagged with id3)
  */
function fillLablelsWithFileInfo(){
    var filePath=fBrowser.getPathFromIndex(vmodel.modelIndex(pathview.currentIndex))
    fProperties.setFile(filePath)
    fillLabels(fProperties.getFileName(),fProperties.getFileOwner(),formattedFileSize(fProperties.getFileSize()),fProperties.getFileModificationDate())
}

//! Fills data labels with the information contained in the params
/*!
  This is a general purpose function in order to fill the data labels with the information provided in the call
    \param titel Data to be displayed on the title label
    \param info1 Data to be displayed on the info1 label
    \param info2 Data to be displayed on the info2 label
    \param info3 Data to be displayed on the info3 label
  */
function fillLabels(title, info1, info2, info3){
    columnWrapper.lblTitleText=title
    columnWrapper.lblInfo1Text=info1
    columnWrapper.lblInfo2Text=info2
    columnWrapper.lblInfo3Text=info3
}

//! Clears the text of all labels
/*!
  Clears the text of all labels
  */
function clearLabels(){
    columnWrapper.lblTitleText=""
    columnWrapper.lblInfo1Text=""
    columnWrapper.lblInfo2Text=""
    columnWrapper.lblInfo3Text=""
}

//! Makes top and bottom button bars visible
/*!
  Makes top and bottom button bars visible setting their opacity to one and stopping the timer used to hide them
  */
function showBars(){
    topButtonsAnimation.running = false
    mediaButtonsAnimation.running=false
    topButtons.opacity=1;
    mediaButtons.opacity=1;
}
