#!/bin/sh
#

#Author: Danilo Luvizotto <danilo.luvizotto@gmail.com>

#I've read a lot of documentation to get to the conclusions
#and explanations detailed here, but I may be wrong. If you're
#an expert and something is wrong, please let me know.

#If you want to learn about about cgroups, this is the best
#documentation I've found:
#http://docs.redhat.com/docs/en-US/Red_Hat_Enterprise_Linux/6/html/Resource_Management_Guide/index.html
#Beware some parts are specific to Red Hat Enterprise Linux.

#This is only a small part of the mod. The biggest part is the file
#/opt/FasterN9/config/syspart.conf and the postinst script.

#Change the IO scheduler
echo deadline > /sys/block/mmcblk0/queue/scheduler

#echo 2097152 > /proc/sys/vm/vfs_cache_pressure
#echo 3 > /proc/sys/vm/swappiness

