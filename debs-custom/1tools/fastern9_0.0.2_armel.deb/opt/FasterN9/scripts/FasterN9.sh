#!/bin/sh
#

#Author: Danilo Luvizotto <danilo.luvizotto@gmail.com>
#License: do whatever you want with it.

#This is mainly a memory MOD. The idea is to avoid swapping.
#Swapping will cause the process to freeze while waiting
#data to be available in RAM. In our case it will also waste
#battery because the swap is compressed in N9.
#
#I've read a lot of documentation to get to the conclusions
#and explanations detailed here, but I may be wrong. If you're
#an expert and something is wrong, please let me know.

#If you want to learn about about cgroups, this is the best
#documentation I've found:
#http://docs.redhat.com/docs/en-US/Red_Hat_Enterprise_Linux/6/html/Resource_Management_Guide/index.html
#Beware some parts are specific to Red Hat Enterprise Linux.

#Source: http://www.kernel.org/doc/Documentation/sysctl/vm.txt
#
#vfs_cache_pressure controls the tendency of the kernel to
#reclaim the memory which is used for caching of directory
#and inode objects.
#At the default value of vfs_cache_pressure=100 the kernel
#will attempt to reclaim dentries and inodes at a "fair" rate
#with respect to pagecache and swapcache reclaim.  Decreasing
#vfs_cache_pressure causes the kernel to prefer to retain dentry
#and inode caches.
#
#This is a mobile phone, we want applications to be available in
#RAM, so we prefer pagecache and swapcache, not directory and
#inode cache. We don't want applications to freeze while their
#code come back from swap!
echo 2097151 > /proc/sys/vm/vfs_cache_pressure

#This will make the system less proactive moving data to swap.
#The value '3' worked better in my tests.
echo 3 > /proc/sys/vm/swappiness

#This will limit memory used by background processes to 10MB.
#The default value is arround 70MB.
#In my phone only 3 processes are in this group:
#msyncd, obexd and the infamous smartsearch
while [[ `cat /syspart/system/background/memory.limit_in_bytes` != 10485760 ]]
do
	echo 10M > /syspart/system/background/memory.limit_in_bytes
	sleep 5
done
#This will make background processes to have less CPU priority.                             
echo 128 > /syspart/system/background/cpu.shares

#This will limit memory used by desktop processes to 100MB.
#The default value is 200MB.
#The most important process in this group is meegotouchhome,
#to wich the 3 home views belong.
#At fist I thought performance would be better if this group
#has a higher limit, but it makes no difference. High limits
#will cause processes to swap, so performance will decrease.
while [[ `cat /syspart/system/desktop/memory.limit_in_bytes` != 104857600 ]]
do
        echo 100M > /syspart/system/desktop/memory.limit_in_bytes
	sleep 5
done

