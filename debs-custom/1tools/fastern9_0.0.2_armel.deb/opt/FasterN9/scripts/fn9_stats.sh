
#to run: sh fn9_stats.sh

ROOT_MAX=`cat /syspart/memory.max_usage_in_bytes`
SYS_MAX=`cat /syspart/system/memory.max_usage_in_bytes`
DESKTOP_MAX=`cat /syspart/system/desktop/memory.max_usage_in_bytes`
BACKGROUND_MAX=`cat /syspart/system/background/memory.max_usage_in_bytes`
APPLICATIONS_MAX=`cat /syspart/system/applications/memory.max_usage_in_bytes`
STANDBY_MAX=`cat /syspart/system/applications/standby/memory.max_usage_in_bytes`

ROOT_USAGE=`cat /syspart/memory.usage_in_bytes`
SYS_USAGE=`cat /syspart/system/memory.usage_in_bytes`
DESKTOP_USAGE=`cat /syspart/system/desktop/memory.usage_in_bytes`
BACKGROUND_USAGE=`cat /syspart/system/background/memory.usage_in_bytes`
APPLICATIONS_USAGE=`cat /syspart/system/applications/memory.usage_in_bytes`
STANDBY_USAGE=`cat /syspart/system/applications/standby/memory.usage_in_bytes`

DESKTOP_LIMIT=`cat /syspart/system/desktop/memory.limit_in_bytes`
BACKGROUND_LIMIT=`cat /syspart/system/background/memory.limit_in_bytes`
APPLICATIONS_LIMIT=`cat /syspart/system/applications/memory.limit_in_bytes`
STANDBY_LIMIT=`cat /syspart/system/applications/standby/memory.limit_in_bytes`

echo "--Max"
echo "root: $(( ($ROOT_MAX) / (1024*1024) ))MB"
echo "system: $(($SYS_MAX/(1024*1024)))MB"
echo "desktop: $(($DESKTOP_MAX/(1024*1024)))MB"
echo "background: $(($BACKGROUND_MAX/(1024*1024)))MB"    
echo "applications: $(($APPLICATIONS_MAX/(1024*1024)))MB"
echo "standby: $(($STANDBY_MAX/(1024*1024)))MB"
echo "-"
echo "root -system: $(( ($ROOT_MAX-$SYS_MAX) / (1024*1024) ))MB"
echo "system -desktop -background -applications: $((($SYS_MAX-$DESKTOP_MAX-$BACKGROUND_MAX-$APPLICATIONS_MAX)/(1024*1024)))MB"
echo "applications -standby: $(( ($ROOT_MAX-$SYS_MAX) / (1024*1024) ))MB"
echo "total: $(($ROOT_MAX/(1024*1024)))MB"
echo "total device memory: $((1008648/1024))MB"
echo ""
echo "--Usage"
echo "root: $(( ($ROOT_USAGE) / (1024*1024) ))MB"                                                                         
echo "system: $(($SYS_USAGE/(1024*1024)))MB"                                      
echo "-"
echo "desktop: $(($DESKTOP_USAGE/(1024*1024)))MB/$(($DESKTOP_LIMIT/(1024*1024)))MB"
echo "background: $(($BACKGROUND_USAGE/(1024*1024)))MB/$(($BACKGROUND_LIMIT/(1024*1024)))MB"
echo "applications: $(($APPLICATIONS_USAGE/(1024*1024)))MB/$(($APPLICATIONS_LIMIT/(1024*1024)))MB"
echo "standby: $(($STANDBY_USAGE/(1024*1024)))MB/$(($STANDBY_LIMIT/(1024*1024)))MB"
echo "subtotal: $((($DESKTOP_USAGE+$BACKGROUND_USAGE+$APPLICATIONS_USAGE)/(1024*1024)))MB/$((($DESKTOP_LIMIT + $BACKGROUND_LIMIT + $APPLICATIONS_LIMIT)/(1024*1024)))MB"
echo ""
echo "root -system: $(( ($ROOT_USAGE-$SYS_USAGE) / (1024*1024) ))MB"
echo "system -desktop -background -applications: $((($SYS_USAGE-$DESKTOP_USAGE-$BACKGROUND_USAGE-$APPLICATIONS_USAGE)/(1024*1024)))MB"
echo "applications -standby: $(( ($APPLICATIONS_USAGE-$STANDBY_USAGE) / (1024*1024) ))MB"
echo ""
echo "total: $(($ROOT_USAGE/(1024*1024)))MB/$((1008648/1024))MB"
echo ""

