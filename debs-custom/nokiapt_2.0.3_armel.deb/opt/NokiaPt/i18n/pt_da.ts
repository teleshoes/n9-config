<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="da">
  <context>
    <name>Maps</name>
    <message numerus="no" id="qtn_pt_feedback_text">
      <source>qtn_pt_feedback_text</source>
      <translation variants="no">Kan du fortælle os, hvorfor du gav denne vurdering?</translation>
    </message>
    <message numerus="no" id="qtn_pt_ok">
      <source>qtn_pt_ok</source>
      <translation variants="no">OK</translation>
    </message>
    <message numerus="no" id="qtn_pt_aboutpage_title">
      <source>qtn_pt_aboutpage_title</source>
      <translation variants="no">Om dette program</translation>
    </message>
    <message numerus="no" id="qtn_pt_ttdropdown_transportmode_0">
      <source>qtn_pt_ttdropdown_transportmode_0</source>
      <translation variants="no">Eksprestog</translation>
    </message>
    <message numerus="no" id="qtn_pt_timepicker_pm">
      <source>qtn_pt_timepicker_pm</source>
      <translation variants="no">PM</translation>
    </message>
    <message numerus="no" id="qtn_pt_ttdropdown_transportmode_3">
      <source>qtn_pt_ttdropdown_transportmode_3</source>
      <translation variants="no">Regionaltog</translation>
    </message>
    <message numerus="no" id="qtn_pt_cancel">
      <source>qtn_pt_cancel</source>
      <translation variants="no">Annuller</translation>
    </message>
    <message numerus="no" id="qtn_pt_journeydetails_walkdistancetime">
      <source>qtn_pt_journeydetails_walkdistancetime</source>
      <translation variants="no">Gå i %2 (%1)</translation>
    </message>
    <message numerus="no" id="qtn_pt_journeydetails_today">
      <source>qtn_pt_journeydetails_today</source>
      <translation variants="no">I dag</translation>
    </message>
    <message numerus="no" id="qtn_pt_routeplanner_from">
      <source>qtn_pt_routeplanner_from</source>
      <translation variants="no">Fra</translation>
    </message>
    <message numerus="no" id="qtn_pt_routeplanner_earlier_hold">
      <source>qtn_pt_routeplanner_earlier_hold</source>
      <translation variants="no">Hold for at se tidligere rejser</translation>
    </message>
    <message numerus="no" id="qtn_pt_value_with_unit">
      <source>qtn_pt_value_with_unit</source>
      <translation variants="no">%1 %2</translation>
    </message>
    <message numerus="no" id="qtn_pt_aboutpage_appdescription">
      <source>qtn_pt_aboutpage_appdescription</source>
      <translation variants="no">Navigation i offentlig transport</translation>
    </message>
    <message numerus="no" id="qtn_pt_stationdetails_blindguidinglines">
      <source>qtn_pt_stationdetails_blindguidinglines</source>
      <translation variants="no">Følelig belægning</translation>
    </message>
    <message numerus="no" id="qtn_pt_journeydetails_navigation_error">
      <source>qtn_pt_journeydetails_navigation_error</source>
      <translation variants="no">Kunne ikke åbne Kort. Prøv igen.</translation>
    </message>
    <message numerus="no" id="qtn_pt_homepage_nextDepartures">
      <source>qtn_pt_homepage_nextDepartures</source>
      <translation variants="no">Næste rejser herfra til</translation>
    </message>
    <message numerus="no" id="qtn_pt_splashscreen_welcome_to">
      <source>qtn_pt_splashscreen_welcome_to</source>
      <translation variants="no">Velkommen til </translation>
    </message>
    <message numerus="no" id="qtn_pt_value_less_than_one">
      <source>qtn_pt_value_less_than_one</source>
      <translation variants="no">&lt; 1</translation>
    </message>
    <message numerus="no" id="qtn_pt_supportedRegions_title">
      <source>qtn_pt_supportedRegions_title</source>
      <translation variants="no">Dækningsoplysninger</translation>
    </message>
    <message numerus="no" id="qtn_pt_homepage_routeplanner">
      <source>qtn_pt_homepage_routeplanner</source>
      <translation variants="no">Rejseplanlægning</translation>
    </message>
    <message numerus="no" id="qtn_pt_feedback_positive">
      <source>qtn_pt_feedback_positive</source>
      <translation variants="no">Meget sandsynligt</translation>
    </message>
    <message numerus="no" id="qtn_pt_homepage_update_notnow">
      <source>qtn_pt_homepage_update_notnow</source>
      <translation variants="no">Ikke nu</translation>
    </message>
    <message numerus="no" id="qtn_pt_ttdropdown_transportmode_all">
      <source>qtn_pt_ttdropdown_transportmode_all</source>
      <translation variants="no">Alle transportformer</translation>
    </message>
    <message numerus="no" id="qtn_pt_unit_minute">
      <source>qtn_pt_unit_minute</source>
      <translation variants="no">min.</translation>
    </message>
    <message numerus="no" id="qtn_pt_departures_station_title">
      <source>qtn_pt_departures_station_title</source>
      <translation variants="no">Forventede afgange</translation>
    </message>
    <message numerus="no" id="qtn_pt_unit_hour">
      <source>qtn_pt_unit_hour</source>
      <translation variants="no">t</translation>
    </message>
    <message numerus="no" id="qtn_pt_ttdropdown_transportmode_7">
      <source>qtn_pt_ttdropdown_transportmode_7</source>
      <translation variants="no">Metro</translation>
    </message>
    <message numerus="no" id="qtn_pt_error_area_not_supported">
      <source>qtn_pt_error_area_not_supported</source>
      <translation variants="no">Vi har endnu ikke transportoplysninger om dette område.</translation>
    </message>
    <message numerus="no" id="qtn_pt_homepage_update_mandatory_text">
      <source>qtn_pt_homepage_update_mandatory_text</source>
      <translation variants="no">Dette program skal snart opdateres. Tryk på 'Opdater', hvis du vil gøre det nu.</translation>
    </message>
    <message numerus="no" id="qtn_pt_journeydetails_tomorrow">
      <source>qtn_pt_journeydetails_tomorrow</source>
      <translation variants="no">I morgen</translation>
    </message>
    <message numerus="no" id="qtn_pt_ttdropdown_transportmode_9">
      <source>qtn_pt_ttdropdown_transportmode_9</source>
      <translation variants="no">Bestilt service</translation>
    </message>
    <message numerus="no" id="qtn_pt_ttdropdown_transportmode_5">
      <source>qtn_pt_ttdropdown_transportmode_5</source>
      <translation variants="no">Bus</translation>
    </message>
    <message numerus="no" id="qtn_pt_routeplanner_noconnections">
      <source>qtn_pt_routeplanner_noconnections</source>
      <translation variants="no">Der blev ikke fundet nogen rejser</translation>
    </message>
    <message numerus="no" id="qtn_pt_journeycalendaritem_minutes_ago">
      <source>qtn_pt_journeycalendaritem_minutes_ago</source>
      <translation variants="no">%1 min. siden</translation>
    </message>
    <message numerus="no" id="qtn_pt_homepage_update_update">
      <source>qtn_pt_homepage_update_update</source>
      <translation variants="no">Opdater</translation>
    </message>
    <message numerus="no" id="qtn_pt_journeydetails_estimateridingtime">
      <source>qtn_pt_journeydetails_estimateridingtime</source>
      <translation variants="no">~%1 ved hjælp af</translation>
    </message>
    <message numerus="no" id="qtn_pt_loadingindicator_loading">
      <source>qtn_pt_loadingindicator_loading</source>
      <translation variants="no">Indlæser</translation>
    </message>
    <message numerus="no" id="qtn_pt_routeplanner_nomoreconnections">
      <source>qtn_pt_routeplanner_nomoreconnections</source>
      <translation variants="no">Der blev ikke fundet flere rejser</translation>
    </message>
    <message numerus="no" id="qtn_pt_routingerror_retry">
      <source>qtn_pt_routingerror_retry</source>
      <translation variants="no">Prøv igen</translation>
    </message>
    <message numerus="no" id="qtn_pt_homepage_favoriteroutesupdated_title">
      <source>qtn_pt_homepage_favoriteroutesupdated_title</source>
      <translation variants="no">Ny funktion</translation>
    </message>
    <message numerus="no" id="qtn_pt_routeplanner_later_loading">
      <source>qtn_pt_routeplanner_later_loading</source>
      <translation variants="no">Henter senere rejser</translation>
    </message>
    <message numerus="no" id="qtn_pt_editfavorite_showHomeScreen">
      <source>qtn_pt_editfavorite_showHomeScreen</source>
      <translation variants="no">Vis næste rejser ved start</translation>
    </message>
    <message numerus="no" id="qtn_pt_homepage_favoriteroutesupdated_text">
      <source>qtn_pt_homepage_favoriteroutesupdated_text</source>
      <translation variants="no">Nu kan du gemme dine foretrukne destinationer fra rejseplanlægningen og se de næste rejser med det samme. (Dine eksisterende foretrukne blev opdateret eller gemt i din søgehistorik).</translation>
    </message>
    <message numerus="no" id="qtn_pt_departureitem_minutes">
      <source>qtn_pt_departureitem_minutes</source>
      <translation variants="no">%1 min</translation>
    </message>
    <message numerus="no" id="qtn_pt_timepicker_in_15min">
      <source>qtn_pt_timepicker_in_15min</source>
      <translation variants="no">Om 15 min</translation>
    </message>
    <message numerus="no" id="qtn_pt_routeplanner_gps_waiting">
      <source>qtn_pt_routeplanner_gps_waiting</source>
      <translation variants="no">Henter din placering</translation>
    </message>
    <message numerus="no" id="qtn_pt_autocompletion_currentposition_no_address">
      <source>qtn_pt_autocompletion_currentposition_no_address</source>
      <translation variants="no">Din placering</translation>
    </message>
    <message numerus="no" id="qtn_pt_error_network_release">
      <source>qtn_pt_error_network_release</source>
      <translation variants="no">Det ser ud til, at forbindelsen er afbrudt. Kontroller den, og prøv igen.</translation>
    </message>
    <message numerus="no" id="qtn_pt_journeydetails_from_location">
      <source>qtn_pt_journeydetails_from_location</source>
      <translation variants="no">Fra %1</translation>
    </message>
    <message numerus="no" id="qtn_pt_homepage_update_downloading">
      <source>qtn_pt_homepage_update_downloading</source>
      <translation variants="no">Henter</translation>
    </message>
    <message numerus="no" id="qtn_pt_feedback_title">
      <source>qtn_pt_feedback_title</source>
      <translation variants="no">Kommentarer</translation>
    </message>
    <message numerus="no" id="qtn_pt_ttfilterpage_title">
      <source>qtn_pt_ttfilterpage_title</source>
      <translation variants="no">Filterindstillinger</translation>
    </message>
    <message numerus="no" id="qtn_pt_homepage_departures">
      <source>qtn_pt_homepage_departures</source>
      <translation variants="no">Transport i nærheden</translation>
    </message>
    <message numerus="no" id="qtn_pt_supportedRegions_header_withsimplerouting">
      <source>qtn_pt_supportedRegions_header_withsimplerouting</source>
      <translation variants="no">Linjer er tilgængelige i %1 byer over hele verden, ligesom køreplaner er for disse områder:</translation>
    </message>
    <message numerus="no" id="qtn_pt_unit_mile">
      <source>qtn_pt_unit_mile</source>
      <translation variants="no">miles</translation>
    </message>
    <message numerus="no" id="qtn_pt_feedback_error_no_rating">
      <source>qtn_pt_feedback_error_no_rating</source>
      <translation variants="no">Vælg en vurdering</translation>
    </message>
    <message numerus="no" id="qtn_pt_routeplanner_later_drag">
      <source>qtn_pt_routeplanner_later_drag</source>
      <translation variants="no">Træk for at hente senere rejser</translation>
    </message>
    <message numerus="no" id="qtn_pt_timepicker_now">
      <source>qtn_pt_timepicker_now</source>
      <translation variants="no">Nu</translation>
    </message>
    <message numerus="no" id="qtn_pt_journeydetails_to_location">
      <source>qtn_pt_journeydetails_to_location</source>
      <translation variants="no">Til %1</translation>
    </message>
    <message numerus="no" id="qtn_pt_aboutpage_feedback">
      <source>qtn_pt_aboutpage_feedback</source>
      <translation variants="no">Kommentarer</translation>
    </message>
    <message numerus="no" id="qtn_pt_aboutpage_acknowledgements_opensource_nokiapt_uses">
      <source>qtn_pt_aboutpage_acknowledgements_opensource_nokiapt_uses</source>
      <translation variants="no">%1 bruger Nokia Qt, som er et program og en UI-struktur på tværs af platforme, og Zlib-komprimeringsbiblioteket, skrevet af Jean-Loup Gailly og Mark Adler.</translation>
    </message>
    <message numerus="no" id="qtn_pt_departures_title">
      <source>qtn_pt_departures_title</source>
      <translation variants="no">Transport i nærheden</translation>
    </message>
    <message numerus="no" id="qtn_pt_supportedRegions_header_nosimplerouting">
      <source>qtn_pt_supportedRegions_header_nosimplerouting</source>
      <translation variants="no">Hvor køreplaner er tilgængelige</translation>
    </message>
    <message numerus="no" id="qtn_pt_ttdropdown_transportmode_1">
      <source>qtn_pt_ttdropdown_transportmode_1</source>
      <translation variants="no">Intercitytog</translation>
    </message>
    <message numerus="no" id="qtn_pt_stationdetails_barrierfree">
      <source>qtn_pt_stationdetails_barrierfree</source>
      <translation variants="no">Barrierefri</translation>
    </message>
    <message numerus="no" id="qtn_pt_aboutpage_acknowledgements_opensource">
      <source>qtn_pt_aboutpage_acknowledgements_opensource</source>
      <translation variants="no">Open source-software</translation>
    </message>
    <message numerus="no" id="qtn_pt_unit_kilometer">
      <source>qtn_pt_unit_kilometer</source>
      <translation variants="no">km</translation>
    </message>
    <message numerus="no" id="qtn_pt_journey_no_warranty">
      <source>qtn_pt_journey_no_warranty</source>
      <translation variants="no">Alle oplysninger leveres uden nogen form for garanti</translation>
    </message>
    <message numerus="no" id="qtn_pt_routingerror_showregions">
      <source>qtn_pt_routingerror_showregions</source>
      <translation variants="no">Vis områder</translation>
    </message>
    <message numerus="no" id="qtn_pt_aboutpage_acknowledgements_source">
      <source>qtn_pt_aboutpage_acknowledgements_source</source>
      <translation variants="no">med støtte fra</translation>
    </message>
    <message numerus="no" id="qtn_pt_homepage_update_updating_text">
      <source>qtn_pt_homepage_update_updating_text</source>
      <translation variants="no">Vent et øjeblik, mens programmet opdateres. (Det lukkes og åbnes igen, så tænk ikke på det).</translation>
    </message>
    <message numerus="no" id="qtn_pt_editfavorite_namefield_label">
      <source>qtn_pt_editfavorite_namefield_label</source>
      <translation variants="no">Vælg et navn</translation>
    </message>
    <message numerus="no" id="qtn_pt_aboutpage_supportedRegions">
      <source>qtn_pt_aboutpage_supportedRegions</source>
      <translation variants="no">Dækkede områder</translation>
    </message>
    <message numerus="no" id="qtn_pt_timepicker_departure">
      <source>qtn_pt_timepicker_departure</source>
      <translation variants="no">Afgang</translation>
    </message>
    <message numerus="no" id="qtn_pt_timepicker_am">
      <source>qtn_pt_timepicker_am</source>
      <translation variants="no">AM</translation>
    </message>
    <message numerus="no" id="Application short caption">
      <source>Application short caption</source>
      <translation variants="no">Offentlig transport</translation>
    </message>
    <message numerus="no" id="qtn_pt_journeydetails_month_day">
      <source>qtn_pt_journeydetails_month_day</source>
      <translation variants="no">d MMM</translation>
    </message>
    <message numerus="no" id="qtn_pt_autocompletion_retry_search">
      <source>qtn_pt_autocompletion_retry_search</source>
      <translation variants="no">Kan ikke finde nogen resultater</translation>
    </message>
    <message numerus="no" id="qtn_pt_ttdropdown_transportmode_4">
      <source>qtn_pt_ttdropdown_transportmode_4</source>
      <translation variants="no">S-tog</translation>
    </message>
    <message numerus="no" id="qtn_pt_feedback_recommend_app">
      <source>qtn_pt_feedback_recommend_app</source>
      <translation variants="no">Hvor sandsynligt er det, at du vil anbefale %1 til en ven eller kollega?</translation>
    </message>
    <message numerus="no" id="qtn_pt_editfavorite_helpText">
      <source>qtn_pt_editfavorite_helpText</source>
      <translation variants="no">Find hurtige og nemme rejser til dette sted direkte fra %1 startskærmen.</translation>
    </message>
    <message numerus="no" id="qtn_pt_routeplanner_to">
      <source>qtn_pt_routeplanner_to</source>
      <translation variants="no">Til</translation>
    </message>
    <message numerus="no" id="qtn_pt_journeydetails_title">
      <source>qtn_pt_journeydetails_title</source>
      <translation variants="no">Rejse %1/%2</translation>
    </message>
    <message numerus="no" id="qtn_pt_ttdropdown_transportmode_6">
      <source>qtn_pt_ttdropdown_transportmode_6</source>
      <translation variants="no">Færge</translation>
    </message>
    <message numerus="no" id="qtn_pt_editfavorite_title">
      <source>qtn_pt_editfavorite_title</source>
      <translation variants="no">Foretrukne</translation>
    </message>
    <message numerus="no" id="qtn_pt_stationdetails_elevators">
      <source>qtn_pt_stationdetails_elevators</source>
      <translation variants="no">Elevatorer</translation>
    </message>
    <message numerus="no" id="qtn_pt_ttfilterpage_select_transport">
      <source>qtn_pt_ttfilterpage_select_transport</source>
      <translation variants="no">Vælg dine foretrukne transportformer</translation>
    </message>
    <message numerus="no" id="qtn_pt_editfavorite_caption">
      <source>qtn_pt_editfavorite_caption</source>
      <translation variants="no">Gem en foretrukken destination</translation>
    </message>
    <message numerus="no" id="qtn_pt_favoritedestinationitem_unavailable">
      <source>qtn_pt_favoritedestinationitem_unavailable</source>
      <translation variants="no">Kan ikke vise dig nogen rejser</translation>
    </message>
    <message numerus="no" id="qtn_pt_unit_meter">
      <source>qtn_pt_unit_meter</source>
      <translation variants="no">m</translation>
    </message>
    <message numerus="no" id="qtn_pt_journeydetails_navigation_text">
      <source>qtn_pt_journeydetails_navigation_text</source>
      <translation variants="no">Vent et øjeblik, mens Kort starter</translation>
    </message>
    <message numerus="no" id="qtn_pt_journeycalendaritem_in_minutes">
      <source>qtn_pt_journeycalendaritem_in_minutes</source>
      <translation variants="no">om %1 min</translation>
    </message>
    <message numerus="no" id="qtn_pt_homepage_update_cancel">
      <source>qtn_pt_homepage_update_cancel</source>
      <translation variants="no">Annuller</translation>
    </message>
    <message numerus="no" id="qtn_pt_homepage_update_low_text">
      <source>qtn_pt_homepage_update_low_text</source>
      <translation variants="no">Der er en opdatering til dette program. Tryk på 'Opdater' for at installere den nu eller 'Ikke nu' for at springe den over.</translation>
    </message>
    <message numerus="no" id="qtn_pt_editfavorite_create">
      <source>qtn_pt_editfavorite_create</source>
      <translation variants="no">Gem</translation>
    </message>
    <message numerus="no" id="qtn_pt_feedback_negative">
      <source>qtn_pt_feedback_negative</source>
      <translation variants="no">Slet ikke sandsynligt</translation>
    </message>
    <message numerus="no" id="qtn_pt_departures_header_label">
      <source>qtn_pt_departures_header_label</source>
      <translation variants="no">Søg efter transport i nærheden af</translation>
    </message>
    <message numerus="no" id="qtn_pt_timepicker_arrival">
      <source>qtn_pt_timepicker_arrival</source>
      <translation variants="no">Ankomst</translation>
    </message>
    <message numerus="no" id="qtn_pt_aboutpage_buildnumber">
      <source>qtn_pt_aboutpage_buildnumber</source>
      <translation variants="no">Build %1</translation>
    </message>
    <message numerus="no" id="qtn_pt_journeydetails_platform">
      <source>qtn_pt_journeydetails_platform</source>
      <translation variants="no">Platform %1</translation>
    </message>
    <message numerus="no" id="qtn_pt_routeplanner_earlier_drag">
      <source>qtn_pt_routeplanner_earlier_drag</source>
      <translation variants="no">Træk for at se tidligere rejser</translation>
    </message>
    <message numerus="no" id="qtn_pt_routeplanner_later_hold">
      <source>qtn_pt_routeplanner_later_hold</source>
      <translation variants="no">Hold for at hente senere rejser</translation>
    </message>
    <message numerus="no" id="qtn_pt_routeplanner_simpleroutinghint">
      <source>qtn_pt_routeplanner_simpleroutinghint</source>
      <translation variants="no">Kan ikke give dig en nøjagtig plan for denne rejse.</translation>
    </message>
    <message numerus="no" id="qtn_pt_feedback_send_error">
      <source>qtn_pt_feedback_send_error</source>
      <translation variants="no">Kunne ikke sende dine kommentarer</translation>
    </message>
    <message numerus="no" id="qtn_pt_error_places">
      <source>qtn_pt_error_places</source>
      <translation variants="no">Kan ikke finde nogen resultater.</translation>
    </message>
    <message numerus="no" id="qtn_pt_ttdropdown_transportmode_8">
      <source>qtn_pt_ttdropdown_transportmode_8</source>
      <translation variants="no">Sporvogn</translation>
    </message>
    <message numerus="no" id="qtn_pt_routeplanner_earlier_loading">
      <source>qtn_pt_routeplanner_earlier_loading</source>
      <translation variants="no">Henter tidligere rejser</translation>
    </message>
    <message numerus="no" id="qtn_pt_homepage_update_exit">
      <source>qtn_pt_homepage_update_exit</source>
      <translation variants="no">Luk</translation>
    </message>
    <message numerus="no" id="qtn_pt_estimate_time">
      <source>qtn_pt_estimate_time</source>
      <translation variants="no">~%1</translation>
    </message>
    <message numerus="no" id="qtn_pt_stationdetails_bicyclesallowed">
      <source>qtn_pt_stationdetails_bicyclesallowed</source>
      <translation variants="no">Cykler tilladt</translation>
    </message>
    <message numerus="no" id="qtn_pt_departurenearbystations_nodepartures">
      <source>qtn_pt_departurenearbystations_nodepartures</source>
      <translation variants="no">Ingen afgange inden for 1 time</translation>
    </message>
    <message numerus="no" id="qtn_pt_homepage_update_timeleft">
      <source>qtn_pt_homepage_update_timeleft</source>
      <translation variants="no">%1 tilbage</translation>
    </message>
    <message numerus="no" id="qtn_pt_ttdropdown_transportmode_2">
      <source>qtn_pt_ttdropdown_transportmode_2</source>
      <translation variants="no">Lyntog</translation>
    </message>
    <message numerus="no" id="qtn_pt_feedback_submit">
      <source>qtn_pt_feedback_submit</source>
      <translation variants="no">Send</translation>
    </message>
    <message numerus="no" id="qtn_pt_app_error">
      <source>qtn_pt_app_error</source>
      <translation variants="no">Noget gik galt</translation>
    </message>
    <message numerus="no" id="qtn_pt_favoritedestinationitem_alreadythere">
      <source>qtn_pt_favoritedestinationitem_alreadythere</source>
      <translation variants="no">Du er her nu</translation>
    </message>
    <message numerus="no" id="qtn_pt_error_hafas_stations">
      <source>qtn_pt_error_hafas_stations</source>
      <translation variants="no">Kan ikke finde nogen resultater.
%1</translation>
    </message>
    <message numerus="no" id="qtn_pt_autocompletion_start_searching">
      <source>qtn_pt_autocompletion_start_searching</source>
      <translation variants="no">Søger</translation>
    </message>
    <message numerus="no" id="qtn_pt_autocompletion_currentposition_with_address">
      <source>qtn_pt_autocompletion_currentposition_with_address</source>
      <translation variants="no">Her, %1</translation>
    </message>
    <message numerus="no" id="qtn_pt_unit_foot">
      <source>qtn_pt_unit_foot</source>
      <translation variants="no">ft</translation>
    </message>
    <message numerus="no" id="qtn_pt_aboutpage_termsconditions">
      <source>qtn_pt_aboutpage_termsconditions</source>
      <translation variants="no">Vilkår for tjeneste</translation>
    </message>
    <message numerus="no" id="qtn_pt_departureitem_loading">
      <source>qtn_pt_departureitem_loading</source>
      <translation variants="no">indlæser</translation>
    </message>
    <message numerus="no" id="qtn_pt_timepicker_in_60min">
      <source>qtn_pt_timepicker_in_60min</source>
      <translation variants="no">Om 60 min</translation>
    </message>
    <message numerus="no" id="qtn_pt_error_hafas_connections">
      <source>qtn_pt_error_hafas_connections</source>
      <translation variants="no">Kan ikke finde nogen rejser.</translation>
    </message>
    <message numerus="no" id="qtn_pt_routeplanner_title">
      <source>qtn_pt_routeplanner_title</source>
      <translation variants="no">Rejseplanlægning</translation>
    </message>
    <message numerus="no" id="qtn_pt_stationdetails_escalators">
      <source>qtn_pt_stationdetails_escalators</source>
      <translation variants="no">Rulletrapper</translation>
    </message>
    <message numerus="no" id="qtn_pt_aboutpage_noteofthanks">
      <source>qtn_pt_aboutpage_noteofthanks</source>
      <translation variants="no">Tak til</translation>
    </message>
    <message numerus="no" id="qtn_pt_timepicker_title">
      <source>qtn_pt_timepicker_title</source>
      <translation variants="no">Rejseindstillinger</translation>
    </message>
    <message numerus="no" id="qtn_pt_termsandconditions">
      <source>qtn_pt_termsandconditions</source>
      <translation variants="no">&lt;p&gt;Brug af tjenester eller overførsel af indhold kan indebære, at der sendes store mængder data gennem din tjenesteudbyders netværk.
Alle tjenesterne er muligvis ikke tilgængelige eller nøjagtige hele tiden. Når dette program bruges i trafikken, er sikkerheden dit første hensyn.
Brug af tjenesten kan indebære, at der sendes oplysninger om din position.
Vi kan indsamle oplysninger om din telefon og brug af tjenesten for at forbedre Nokia-produkter og for at levere mere relevant indhold til dig.
Vi deler ikke dine data med tredjepart uden at spørge dig først.
Du kan få flere oplysninger om beskyttelse af personlige oplysninger ved at klikke [her|%1].

Ved at vælge 'Start' bekræfter du, at du har læst og accepteret [Vilkår for Nokia-tjenesten|%2] og [Politik om beskyttelse af personlige oplysninger|%3].&lt;/p&gt;</translation>
    </message>
    <message numerus="no" id="qtn_pt_coverage_button_skip">
      <source>qtn_pt_coverage_button_skip</source>
      <translation variants="no">Spring registrering over</translation>
    </message>
    <message numerus="no" id="qtn_pt_coverage_button_showcoveredregions">
      <source>qtn_pt_coverage_button_showcoveredregions</source>
      <translation variants="no">Dækkede områder</translation>
    </message>
    <message numerus="no" id="qtn_pt_coverage_position_nocoverage">
      <source>qtn_pt_coverage_position_nocoverage</source>
      <translation variants="no">&lt;p&gt;Vi har ingen oplysninger om %1 lige nu..
&lt;/p&gt;
&lt;p&gt;Men vi tilføjer nye byer hver dag, så hold dig informeret.&lt;/p&gt;</translation>
    </message>
    <message numerus="no" id="qtn_pt_coverage_title_nocoverage">
      <source>qtn_pt_coverage_title_nocoverage</source>
      <translation variants="no">Vi beklager</translation>
    </message>
    <message numerus="no" id="qtn_pt_coverage_position_timetablecoverage">
      <source>qtn_pt_coverage_position_timetablecoverage</source>
      <translation variants="no">&lt;p&gt;
Ser ud, som om du er i  &lt;b&gt;%1&lt;/b&gt;.
&lt;/p&gt;
&lt;p&gt;
Vi understøtter %2. &lt;br&gt;Vi har dækket denne og mange andre byer.
&lt;/p&gt;</translation>
    </message>
    <message numerus="no" id="qtn_pt_firsttimeuse_welcome">
      <source>qtn_pt_firsttimeuse_welcome</source>
      <translation variants="no">Velkommen</translation>
    </message>
    <message numerus="no" id="qtn_pt_coverage_button_continue">
      <source>qtn_pt_coverage_button_continue</source>
      <translation variants="no">Fortsæt</translation>
    </message>
    <message numerus="no" id="qtn_pt_coverage_button_retry">
      <source>qtn_pt_coverage_button_retry</source>
      <translation variants="no">Prøv igen</translation>
    </message>
    <message numerus="no" id="qtn_pt_coverage_position_noposition">
      <source>qtn_pt_coverage_position_noposition</source>
      <translation variants="no">Kan ikke finde din aktuelle placering. Kontroller dækningslisten for at sikre, at programmet fungerer i dette område.</translation>
    </message>
    <message numerus="no" id="qtn_pt_start">
      <source>qtn_pt_start</source>
      <translation variants="no">Start </translation>
    </message>
    <message numerus="no" id="qtn_pt_nothanks">
      <source>qtn_pt_nothanks</source>
      <translation variants="no">Nej tak</translation>
    </message>
    <message numerus="no" id="qtn_pt_stationdetails_title">
      <source>qtn_pt_stationdetails_title</source>
      <translation variants="no">Stop/stationsoplysninger</translation>
    </message>
    <message numerus="no" id="qtn_pt_journeydetails_walk_title">
      <source>qtn_pt_journeydetails_walk_title</source>
      <translation variants="no">Fodgængervejledning</translation>
    </message>
    <message numerus="no" id="qtn_pt_journeydetails_show_on_map_title">
      <source>qtn_pt_journeydetails_show_on_map_title</source>
      <translation variants="no">Vis på kort</translation>
    </message>
    <message numerus="no" id="qtn_pt_journeydetails_show_on_map_text">
      <source>qtn_pt_journeydetails_show_on_map_text</source>
      <translation variants="no">Klar til at vise  &lt;b&gt;%1&lt;/b&gt; i Nokia Kort.</translation>
    </message>
    <message numerus="no" id="qtn_pt_journeydetails_show">
      <source>qtn_pt_journeydetails_show</source>
      <translation variants="no">Kortlæg det</translation>
    </message>
    <message numerus="no" id="qtn_pt_journeydetails_go">
      <source>qtn_pt_journeydetails_go</source>
      <translation variants="no">Lad os komme af sted</translation>
    </message>
    <message numerus="no" id="qtn_pt_linedetails_title">
      <source>qtn_pt_linedetails_title</source>
      <translation variants="no">Linjeoplysninger</translation>
    </message>
    <message numerus="no" id="qtn_pt_linedetails_on_time">
      <source>qtn_pt_linedetails_on_time</source>
      <translation variants="no">til tiden</translation>
    </message>
    <message numerus="no" id="qtn_pt_linedetails_late">
      <source>qtn_pt_linedetails_late</source>
      <translation variants="no">%1 min. for sent</translation>
    </message>
    <message numerus="no" id="qtn_pt_journeydetails_walk_text">
      <source>qtn_pt_journeydetails_walk_text</source>
      <translation variants="no">Klar til at starte fodgængernavigation til &lt;b&gt;%1&lt;/b&gt; i Nokia Kort.</translation>
    </message>
    <message numerus="no" id="qtn_pt_feedback_contact">
      <source>qtn_pt_feedback_contact</source>
      <translation variants="no">Kontakt mig for flere oplysninger (valgfrit)</translation>
    </message>
    <message numerus="no" id="qtn_pt_feedback_contact_placeholder">
      <source>qtn_pt_feedback_contact_placeholder</source>
      <translation variants="no">E-mail-adresse</translation>
    </message>
    <message numerus="no" id="qtn_pt_feedback_privacy">
      <source>qtn_pt_feedback_privacy</source>
      <translation variants="no">Dine oplysninger bliver knyttet til din enhed og behandles i henhold til [Nokias politik om beskyttelse af personlige oplysninger|%1]</translation>
    </message>
    <message numerus="no" id="qtn_pt_feedback_text_placeholder">
      <source>qtn_pt_feedback_text_placeholder</source>
      <translation variants="no">Din kommentar</translation>
    </message>
    <message numerus="no" id="qtn_pt_privacy">
      <source>qtn_pt_privacy</source>
      <translation variants="no">&lt;p&gt;
Nokia respekterer dit privatliv.
Vi vil muligvis indsamle oplysninger om din telefon og brug af tjenesten for at forbedre Nokia-produkter, og for at levere mere relevant indhold til dig.

Vi deler ikke dine data med tredjepart uden at spørge dig først.

[Politik om beskyttelse af personlige oplysninger|%1]

[Beskyttelse af personlige oplysninger i %2|%3]
&lt;/p&gt;</translation>
    </message>
    <message numerus="no" id="qtn_pt_aboutpage_support">
      <source>qtn_pt_aboutpage_support</source>
      <translation variants="no">Support</translation>
    </message>
    <message numerus="no" id="Application long caption">
      <source>Application long caption</source>
      <translation variants="no">Offentlig transport</translation>
    </message>
    <message numerus="no" id="qtn_pt_error_noresults">
      <source>qtn_pt_error_noresults</source>
      <translation variants="no">Der er ikke nogen fuldstændig rute tilgængelig.</translation>
    </message>
    <message numerus="no" id="qtn_pt_privacy_title">
      <source>qtn_pt_privacy_title</source>
      <translation variants="no">Fortrolighed</translation>
    </message>
    <message numerus="no" id="qtn_pt_routeplanner_input_watermark">
      <source>qtn_pt_routeplanner_input_watermark</source>
      <translation variants="no">Søg efter stop eller steder</translation>
    </message>
    <message numerus="no" id="qtn_pt_location_no_info">
      <source>qtn_pt_location_no_info</source>
      <translation variants="no">Din valgte position</translation>
    </message>
    <message numerus="no" id="qtn_pt_location_taiwan">
      <source>qtn_pt_location_taiwan</source>
      <translation variants="no">Taiwan</translation>
    </message>
    <message numerus="no" id="qtn_pt_location_taiwan_area">
      <source>qtn_pt_location_taiwan_area</source>
      <translation variants="no">Taiwan-området</translation>
    </message>
    <message numerus="no" id="Package name">
      <source>Package name</source>
      <translation variants="no">Offentlig transport</translation>
    </message>
    <message numerus="no" id="Smart installer package name">
      <source>Smart installer package name</source>
      <translation variants="no">Offentlig transport</translation>
    </message>
    <message numerus="no" id="qtn_pt_coverage_thanksforinstalling">
      <source>qtn_pt_coverage_thanksforinstalling</source>
      <translation variants="no">Tak, fordi du installerede %1.&lt;br&gt;Vi har planlagte ruteoplysninger i %2 by over hele verden.</translation>
    </message>
  </context>
</TS>
