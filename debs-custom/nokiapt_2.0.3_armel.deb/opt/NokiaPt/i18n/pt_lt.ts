<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="lt">
  <context>
    <name>Maps</name>
    <message numerus="no" id="qtn_pt_feedback_text">
      <source>qtn_pt_feedback_text</source>
      <translation variants="no">Ar galėtumėte mums pasakyti, kodėl taip įvertinote?</translation>
    </message>
    <message numerus="no" id="qtn_pt_ok">
      <source>qtn_pt_ok</source>
      <translation variants="no">Gerai</translation>
    </message>
    <message numerus="no" id="qtn_pt_aboutpage_title">
      <source>qtn_pt_aboutpage_title</source>
      <translation variants="no">Apie šią programą</translation>
    </message>
    <message numerus="no" id="qtn_pt_ttdropdown_transportmode_0">
      <source>qtn_pt_ttdropdown_transportmode_0</source>
      <translation variants="no">Traukinys ekspresas</translation>
    </message>
    <message numerus="no" id="qtn_pt_timepicker_pm">
      <source>qtn_pt_timepicker_pm</source>
      <translation variants="no">PM</translation>
    </message>
    <message numerus="no" id="qtn_pt_ttdropdown_transportmode_3">
      <source>qtn_pt_ttdropdown_transportmode_3</source>
      <translation variants="no">Regioninis traukinys</translation>
    </message>
    <message numerus="no" id="qtn_pt_cancel">
      <source>qtn_pt_cancel</source>
      <translation variants="no">Atšaukti</translation>
    </message>
    <message numerus="no" id="qtn_pt_journeydetails_walkdistancetime">
      <source>qtn_pt_journeydetails_walkdistancetime</source>
      <translation variants="no">Eikite %2 (%1)</translation>
    </message>
    <message numerus="no" id="qtn_pt_journeydetails_today">
      <source>qtn_pt_journeydetails_today</source>
      <translation variants="no">Šiandien</translation>
    </message>
    <message numerus="no" id="qtn_pt_routeplanner_from">
      <source>qtn_pt_routeplanner_from</source>
      <translation variants="no">Iš</translation>
    </message>
    <message numerus="no" id="qtn_pt_routeplanner_earlier_hold">
      <source>qtn_pt_routeplanner_earlier_hold</source>
      <translation variants="no">Norėdami pamatyti ankstesnes keliones, laikykite</translation>
    </message>
    <message numerus="no" id="qtn_pt_value_with_unit">
      <source>qtn_pt_value_with_unit</source>
      <translation variants="no">%1 %2</translation>
    </message>
    <message numerus="no" id="qtn_pt_aboutpage_appdescription">
      <source>qtn_pt_aboutpage_appdescription</source>
      <translation variants="no">Viešojo transporto navigacija</translation>
    </message>
    <message numerus="no" id="qtn_pt_stationdetails_blindguidinglines">
      <source>qtn_pt_stationdetails_blindguidinglines</source>
      <translation variants="no">Taktilinė grindų danga</translation>
    </message>
    <message numerus="no" id="qtn_pt_journeydetails_navigation_error">
      <source>qtn_pt_journeydetails_navigation_error</source>
      <translation variants="no">Nepavyko įjungti programos „Žemėlapiai“. Bandykite dar kartą.</translation>
    </message>
    <message numerus="no" id="qtn_pt_homepage_nextDepartures">
      <source>qtn_pt_homepage_nextDepartures</source>
      <translation variants="no">Kitos kelionės iš čia į</translation>
    </message>
    <message numerus="no" id="qtn_pt_splashscreen_welcome_to">
      <source>qtn_pt_splashscreen_welcome_to</source>
      <translation variants="no">Sveiki atvykę į </translation>
    </message>
    <message numerus="no" id="qtn_pt_value_less_than_one">
      <source>qtn_pt_value_less_than_one</source>
      <translation variants="no">&lt; 1</translation>
    </message>
    <message numerus="no" id="qtn_pt_supportedRegions_title">
      <source>qtn_pt_supportedRegions_title</source>
      <translation variants="no">Informacija apie aprėptį</translation>
    </message>
    <message numerus="no" id="qtn_pt_homepage_routeplanner">
      <source>qtn_pt_homepage_routeplanner</source>
      <translation variants="no">Kelionių planavimo priemonė</translation>
    </message>
    <message numerus="no" id="qtn_pt_feedback_positive">
      <source>qtn_pt_feedback_positive</source>
      <translation variants="no">Labai tikėtina</translation>
    </message>
    <message numerus="no" id="qtn_pt_homepage_update_notnow">
      <source>qtn_pt_homepage_update_notnow</source>
      <translation variants="no">Ne dabar</translation>
    </message>
    <message numerus="no" id="qtn_pt_ttdropdown_transportmode_all">
      <source>qtn_pt_ttdropdown_transportmode_all</source>
      <translation variants="no">Visi transporto būdai</translation>
    </message>
    <message numerus="no" id="qtn_pt_unit_minute">
      <source>qtn_pt_unit_minute</source>
      <translation variants="no">min.</translation>
    </message>
    <message numerus="no" id="qtn_pt_departures_station_title">
      <source>qtn_pt_departures_station_title</source>
      <translation variants="no">Numatomi išvykstantys maršrutai</translation>
    </message>
    <message numerus="no" id="qtn_pt_unit_hour">
      <source>qtn_pt_unit_hour</source>
      <translation variants="no">val.</translation>
    </message>
    <message numerus="no" id="qtn_pt_ttdropdown_transportmode_7">
      <source>qtn_pt_ttdropdown_transportmode_7</source>
      <translation variants="no">Metro</translation>
    </message>
    <message numerus="no" id="qtn_pt_error_area_not_supported">
      <source>qtn_pt_error_area_not_supported</source>
      <translation variants="no">Šios vietovės transporto informacijos dar neturime.</translation>
    </message>
    <message numerus="no" id="qtn_pt_homepage_update_mandatory_text">
      <source>qtn_pt_homepage_update_mandatory_text</source>
      <translation variants="no">Šią programą reikia netrukus atnaujinti. Norėdami tai padaryti dabar, palieskite „Naujinti“</translation>
    </message>
    <message numerus="no" id="qtn_pt_journeydetails_tomorrow">
      <source>qtn_pt_journeydetails_tomorrow</source>
      <translation variants="no">Rytoj</translation>
    </message>
    <message numerus="no" id="qtn_pt_ttdropdown_transportmode_9">
      <source>qtn_pt_ttdropdown_transportmode_9</source>
      <translation variants="no">Užsakyta paslauga</translation>
    </message>
    <message numerus="no" id="qtn_pt_ttdropdown_transportmode_5">
      <source>qtn_pt_ttdropdown_transportmode_5</source>
      <translation variants="no">Autobusas</translation>
    </message>
    <message numerus="no" id="qtn_pt_routeplanner_noconnections">
      <source>qtn_pt_routeplanner_noconnections</source>
      <translation variants="no">Nerasta jokių kelionių</translation>
    </message>
    <message numerus="no" id="qtn_pt_journeycalendaritem_minutes_ago">
      <source>qtn_pt_journeycalendaritem_minutes_ago</source>
      <translation variants="no">Prieš %1 min.</translation>
    </message>
    <message numerus="no" id="qtn_pt_homepage_update_update">
      <source>qtn_pt_homepage_update_update</source>
      <translation variants="no">Naujinti</translation>
    </message>
    <message numerus="no" id="qtn_pt_journeydetails_estimateridingtime">
      <source>qtn_pt_journeydetails_estimateridingtime</source>
      <translation variants="no">~%1 naudojant</translation>
    </message>
    <message numerus="no" id="qtn_pt_loadingindicator_loading">
      <source>qtn_pt_loadingindicator_loading</source>
      <translation variants="no">Įkeliama</translation>
    </message>
    <message numerus="no" id="qtn_pt_routeplanner_nomoreconnections">
      <source>qtn_pt_routeplanner_nomoreconnections</source>
      <translation variants="no">Daugiau kelionių nerasta</translation>
    </message>
    <message numerus="no" id="qtn_pt_routingerror_retry">
      <source>qtn_pt_routingerror_retry</source>
      <translation variants="no">Bandyti dar</translation>
    </message>
    <message numerus="no" id="qtn_pt_homepage_favoriteroutesupdated_title">
      <source>qtn_pt_homepage_favoriteroutesupdated_title</source>
      <translation variants="no">Nauja funkcija</translation>
    </message>
    <message numerus="no" id="qtn_pt_routeplanner_later_loading">
      <source>qtn_pt_routeplanner_later_loading</source>
      <translation variants="no">Gaunami vėlesnių kelionių duomenys</translation>
    </message>
    <message numerus="no" id="qtn_pt_editfavorite_showHomeScreen">
      <source>qtn_pt_editfavorite_showHomeScreen</source>
      <translation variants="no">Įjungus rodyti kitas keliones</translation>
    </message>
    <message numerus="no" id="qtn_pt_homepage_favoriteroutesupdated_text">
      <source>qtn_pt_homepage_favoriteroutesupdated_text</source>
      <translation variants="no">Dabar parankinius tikslus galite įrašyti iš kelionių planavimo priemonės ir iškart matyti kitas keliones. (Jūsų esami parankiniai atnaujinti arba įrašyti ieškos chronologijoje.)</translation>
    </message>
    <message numerus="no" id="qtn_pt_departureitem_minutes">
      <source>qtn_pt_departureitem_minutes</source>
      <translation variants="no">%1 min.</translation>
    </message>
    <message numerus="no" id="qtn_pt_timepicker_in_15min">
      <source>qtn_pt_timepicker_in_15min</source>
      <translation variants="no">Per 15</translation>
    </message>
    <message numerus="no" id="qtn_pt_routeplanner_gps_waiting">
      <source>qtn_pt_routeplanner_gps_waiting</source>
      <translation variants="no">Nustatoma jūsų vieta</translation>
    </message>
    <message numerus="no" id="qtn_pt_autocompletion_currentposition_no_address">
      <source>qtn_pt_autocompletion_currentposition_no_address</source>
      <translation variants="no">Jūsų vieta</translation>
    </message>
    <message numerus="no" id="qtn_pt_error_network_release">
      <source>qtn_pt_error_network_release</source>
      <translation variants="no">Atrodo, nutrūko ryšys. Patikrinkite ir vėl bandykite.</translation>
    </message>
    <message numerus="no" id="qtn_pt_journeydetails_from_location">
      <source>qtn_pt_journeydetails_from_location</source>
      <translation variants="no">Iš %1</translation>
    </message>
    <message numerus="no" id="qtn_pt_homepage_update_downloading">
      <source>qtn_pt_homepage_update_downloading</source>
      <translation variants="no">Atsisiunčiama</translation>
    </message>
    <message numerus="no" id="qtn_pt_feedback_title">
      <source>qtn_pt_feedback_title</source>
      <translation variants="no">Atsiliepimas</translation>
    </message>
    <message numerus="no" id="qtn_pt_ttfilterpage_title">
      <source>qtn_pt_ttfilterpage_title</source>
      <translation variants="no">Filtro parametrai</translation>
    </message>
    <message numerus="no" id="qtn_pt_homepage_departures">
      <source>qtn_pt_homepage_departures</source>
      <translation variants="no">Transportas arti</translation>
    </message>
    <message numerus="no" id="qtn_pt_supportedRegions_header_withsimplerouting">
      <source>qtn_pt_supportedRegions_header_withsimplerouting</source>
      <translation variants="no">Pateikiamos %1 pasaulio miestų linijos ir tvarkaraščiai  šiuose regionuose:</translation>
    </message>
    <message numerus="no" id="qtn_pt_unit_mile">
      <source>qtn_pt_unit_mile</source>
      <translation variants="no">myl.</translation>
    </message>
    <message numerus="no" id="qtn_pt_feedback_error_no_rating">
      <source>qtn_pt_feedback_error_no_rating</source>
      <translation variants="no">Pasirinkite įvertinimą</translation>
    </message>
    <message numerus="no" id="qtn_pt_routeplanner_later_drag">
      <source>qtn_pt_routeplanner_later_drag</source>
      <translation variants="no">Norėdami pamatyti vėlesnes keliones, vilkite</translation>
    </message>
    <message numerus="no" id="qtn_pt_timepicker_now">
      <source>qtn_pt_timepicker_now</source>
      <translation variants="no">Dabar</translation>
    </message>
    <message numerus="no" id="qtn_pt_journeydetails_to_location">
      <source>qtn_pt_journeydetails_to_location</source>
      <translation variants="no">Į %1</translation>
    </message>
    <message numerus="no" id="qtn_pt_aboutpage_feedback">
      <source>qtn_pt_aboutpage_feedback</source>
      <translation variants="no">Atsiliepimai</translation>
    </message>
    <message numerus="no" id="qtn_pt_aboutpage_acknowledgements_opensource_nokiapt_uses">
      <source>qtn_pt_aboutpage_acknowledgements_opensource_nokiapt_uses</source>
      <translation variants="no">%1 naudojama daugiaplatformė taikomųjų programų ir naudotojo sąsajos sistema „Nokia Qt“, ir glaudinimo biblioteka „Zlib“, parašyta Jean-Loup Gailly ir Mark Adler.</translation>
    </message>
    <message numerus="no" id="qtn_pt_departures_title">
      <source>qtn_pt_departures_title</source>
      <translation variants="no">Transportas arti</translation>
    </message>
    <message numerus="no" id="qtn_pt_supportedRegions_header_nosimplerouting">
      <source>qtn_pt_supportedRegions_header_nosimplerouting</source>
      <translation variants="no">Kur pateikiami tvarkaraščiai</translation>
    </message>
    <message numerus="no" id="qtn_pt_ttdropdown_transportmode_1">
      <source>qtn_pt_ttdropdown_transportmode_1</source>
      <translation variants="no">Tarpmiestinis traukinys</translation>
    </message>
    <message numerus="no" id="qtn_pt_stationdetails_barrierfree">
      <source>qtn_pt_stationdetails_barrierfree</source>
      <translation variants="no">Be užtvarų</translation>
    </message>
    <message numerus="no" id="qtn_pt_aboutpage_acknowledgements_opensource">
      <source>qtn_pt_aboutpage_acknowledgements_opensource</source>
      <translation variants="no">Atvirojo kodo programinė įranga</translation>
    </message>
    <message numerus="no" id="qtn_pt_unit_kilometer">
      <source>qtn_pt_unit_kilometer</source>
      <translation variants="no">km</translation>
    </message>
    <message numerus="no" id="qtn_pt_journey_no_warranty">
      <source>qtn_pt_journey_no_warranty</source>
      <translation variants="no">Visa informacija teikiama be jokių garantijų</translation>
    </message>
    <message numerus="no" id="qtn_pt_routingerror_showregions">
      <source>qtn_pt_routingerror_showregions</source>
      <translation variants="no">Rodyti regionus</translation>
    </message>
    <message numerus="no" id="qtn_pt_aboutpage_acknowledgements_source">
      <source>qtn_pt_aboutpage_acknowledgements_source</source>
      <translation variants="no">padedant</translation>
    </message>
    <message numerus="no" id="qtn_pt_homepage_update_updating_text">
      <source>qtn_pt_homepage_update_updating_text</source>
      <translation variants="no">Prašome palaukti, kol programa bus atnaujinta. (Ji pati išsijungs ir vėl įsijungs, todėl nesirūpinkite.)</translation>
    </message>
    <message numerus="no" id="qtn_pt_editfavorite_namefield_label">
      <source>qtn_pt_editfavorite_namefield_label</source>
      <translation variants="no">Pasirinkti pavadinimą</translation>
    </message>
    <message numerus="no" id="qtn_pt_aboutpage_supportedRegions">
      <source>qtn_pt_aboutpage_supportedRegions</source>
      <translation variants="no">Apimami regionai</translation>
    </message>
    <message numerus="no" id="qtn_pt_timepicker_departure">
      <source>qtn_pt_timepicker_departure</source>
      <translation variants="no">Išvyksta</translation>
    </message>
    <message numerus="no" id="qtn_pt_timepicker_am">
      <source>qtn_pt_timepicker_am</source>
      <translation variants="no">AM</translation>
    </message>
    <message numerus="no" id="Application short caption">
      <source>Application short caption</source>
      <translation variants="no">Viešasis transportas</translation>
    </message>
    <message numerus="no" id="qtn_pt_journeydetails_month_day">
      <source>qtn_pt_journeydetails_month_day</source>
      <translation variants="no">d MMM</translation>
    </message>
    <message numerus="no" id="qtn_pt_autocompletion_retry_search">
      <source>qtn_pt_autocompletion_retry_search</source>
      <translation variants="no">Nerasta jokių rezultatų</translation>
    </message>
    <message numerus="no" id="qtn_pt_ttdropdown_transportmode_4">
      <source>qtn_pt_ttdropdown_transportmode_4</source>
      <translation variants="no">Priemiestinis traukinys</translation>
    </message>
    <message numerus="no" id="qtn_pt_feedback_recommend_app">
      <source>qtn_pt_feedback_recommend_app</source>
      <translation variants="no">Kiek tikėtina, kad %1 rekomenduotumėte draugui ar bendradarbiui?</translation>
    </message>
    <message numerus="no" id="qtn_pt_editfavorite_helpText">
      <source>qtn_pt_editfavorite_helpText</source>
      <translation variants="no">Tiesiai %1 pagrindiniame ekrane sužinokite apie greitas ir paprastas keliones į šią vietą.</translation>
    </message>
    <message numerus="no" id="qtn_pt_routeplanner_to">
      <source>qtn_pt_routeplanner_to</source>
      <translation variants="no">Į</translation>
    </message>
    <message numerus="no" id="qtn_pt_journeydetails_title">
      <source>qtn_pt_journeydetails_title</source>
      <translation variants="no">Kelionė %1 / %2</translation>
    </message>
    <message numerus="no" id="qtn_pt_ttdropdown_transportmode_6">
      <source>qtn_pt_ttdropdown_transportmode_6</source>
      <translation variants="no">Keltas</translation>
    </message>
    <message numerus="no" id="qtn_pt_editfavorite_title">
      <source>qtn_pt_editfavorite_title</source>
      <translation variants="no">Parankiniai</translation>
    </message>
    <message numerus="no" id="qtn_pt_stationdetails_elevators">
      <source>qtn_pt_stationdetails_elevators</source>
      <translation variants="no">Liftai</translation>
    </message>
    <message numerus="no" id="qtn_pt_ttfilterpage_select_transport">
      <source>qtn_pt_ttfilterpage_select_transport</source>
      <translation variants="no">Pasirinkite norimus transporto būdus</translation>
    </message>
    <message numerus="no" id="qtn_pt_editfavorite_caption">
      <source>qtn_pt_editfavorite_caption</source>
      <translation variants="no">Įrašyti parankinį tikslą</translation>
    </message>
    <message numerus="no" id="qtn_pt_favoritedestinationitem_unavailable">
      <source>qtn_pt_favoritedestinationitem_unavailable</source>
      <translation variants="no">Negalime parodyti jokių kelionių</translation>
    </message>
    <message numerus="no" id="qtn_pt_unit_meter">
      <source>qtn_pt_unit_meter</source>
      <translation variants="no">m</translation>
    </message>
    <message numerus="no" id="qtn_pt_journeydetails_navigation_text">
      <source>qtn_pt_journeydetails_navigation_text</source>
      <translation variants="no">Prašome palaukti, kol bus įjungta programa „Žemėlapiai“</translation>
    </message>
    <message numerus="no" id="qtn_pt_journeycalendaritem_in_minutes">
      <source>qtn_pt_journeycalendaritem_in_minutes</source>
      <translation variants="no">per %1 min.</translation>
    </message>
    <message numerus="no" id="qtn_pt_homepage_update_cancel">
      <source>qtn_pt_homepage_update_cancel</source>
      <translation variants="no">Atšaukti</translation>
    </message>
    <message numerus="no" id="qtn_pt_homepage_update_low_text">
      <source>qtn_pt_homepage_update_low_text</source>
      <translation variants="no">Yra šios programos naujinys. Norėdami įdiegti dabar, palieskite „Naujinti“, norėdami praleisti ‐ „Ne dabar“.</translation>
    </message>
    <message numerus="no" id="qtn_pt_editfavorite_create">
      <source>qtn_pt_editfavorite_create</source>
      <translation variants="no">Įrašyti</translation>
    </message>
    <message numerus="no" id="qtn_pt_feedback_negative">
      <source>qtn_pt_feedback_negative</source>
      <translation variants="no">Visiškai jokios tikimybės</translation>
    </message>
    <message numerus="no" id="qtn_pt_departures_header_label">
      <source>qtn_pt_departures_header_label</source>
      <translation variants="no">Ieškoti transporto arti</translation>
    </message>
    <message numerus="no" id="qtn_pt_timepicker_arrival">
      <source>qtn_pt_timepicker_arrival</source>
      <translation variants="no">Atvyksta</translation>
    </message>
    <message numerus="no" id="qtn_pt_aboutpage_buildnumber">
      <source>qtn_pt_aboutpage_buildnumber</source>
      <translation variants="no">%1 darinys</translation>
    </message>
    <message numerus="no" id="qtn_pt_journeydetails_platform">
      <source>qtn_pt_journeydetails_platform</source>
      <translation variants="no">%1 platforma</translation>
    </message>
    <message numerus="no" id="qtn_pt_routeplanner_earlier_drag">
      <source>qtn_pt_routeplanner_earlier_drag</source>
      <translation variants="no">Norėdami pamatyti ankstesnes keliones, vilkite</translation>
    </message>
    <message numerus="no" id="qtn_pt_routeplanner_later_hold">
      <source>qtn_pt_routeplanner_later_hold</source>
      <translation variants="no">Norėdami pamatyti vėlesnes keliones, laikykite</translation>
    </message>
    <message numerus="no" id="qtn_pt_routeplanner_simpleroutinghint">
      <source>qtn_pt_routeplanner_simpleroutinghint</source>
      <translation variants="no">Neįmanoma pateikti tikslaus šios kelionės grafiko.</translation>
    </message>
    <message numerus="no" id="qtn_pt_feedback_send_error">
      <source>qtn_pt_feedback_send_error</source>
      <translation variants="no">Nepavyko išsiųsti jūsų atsiliepimo</translation>
    </message>
    <message numerus="no" id="qtn_pt_error_places">
      <source>qtn_pt_error_places</source>
      <translation variants="no">Nerasta jokių rezultatų.</translation>
    </message>
    <message numerus="no" id="qtn_pt_ttdropdown_transportmode_8">
      <source>qtn_pt_ttdropdown_transportmode_8</source>
      <translation variants="no">Tramvajus</translation>
    </message>
    <message numerus="no" id="qtn_pt_routeplanner_earlier_loading">
      <source>qtn_pt_routeplanner_earlier_loading</source>
      <translation variants="no">Gaunami ankstesnių kelionių duomenys</translation>
    </message>
    <message numerus="no" id="qtn_pt_homepage_update_exit">
      <source>qtn_pt_homepage_update_exit</source>
      <translation variants="no">Uždaryti</translation>
    </message>
    <message numerus="no" id="qtn_pt_estimate_time">
      <source>qtn_pt_estimate_time</source>
      <translation variants="no">~%1</translation>
    </message>
    <message numerus="no" id="qtn_pt_stationdetails_bicyclesallowed">
      <source>qtn_pt_stationdetails_bicyclesallowed</source>
      <translation variants="no">Galima vežti dviračius</translation>
    </message>
    <message numerus="no" id="qtn_pt_departurenearbystations_nodepartures">
      <source>qtn_pt_departurenearbystations_nodepartures</source>
      <translation variants="no">Per artimiausią valandą išvykstančių maršrutų nėra</translation>
    </message>
    <message numerus="no" id="qtn_pt_homepage_update_timeleft">
      <source>qtn_pt_homepage_update_timeleft</source>
      <translation variants="no">Liko %1</translation>
    </message>
    <message numerus="no" id="qtn_pt_ttdropdown_transportmode_2">
      <source>qtn_pt_ttdropdown_transportmode_2</source>
      <translation variants="no">Greitasis traukinys</translation>
    </message>
    <message numerus="no" id="qtn_pt_feedback_submit">
      <source>qtn_pt_feedback_submit</source>
      <translation variants="no">Siųsti</translation>
    </message>
    <message numerus="no" id="qtn_pt_app_error">
      <source>qtn_pt_app_error</source>
      <translation variants="no">Kažkas ne taip</translation>
    </message>
    <message numerus="no" id="qtn_pt_favoritedestinationitem_alreadythere">
      <source>qtn_pt_favoritedestinationitem_alreadythere</source>
      <translation variants="no">Jūs esate čia</translation>
    </message>
    <message numerus="no" id="qtn_pt_error_hafas_stations">
      <source>qtn_pt_error_hafas_stations</source>
      <translation variants="no">Nerasta jokių rezultatų.
%1</translation>
    </message>
    <message numerus="no" id="qtn_pt_autocompletion_start_searching">
      <source>qtn_pt_autocompletion_start_searching</source>
      <translation variants="no">Ieškoma</translation>
    </message>
    <message numerus="no" id="qtn_pt_autocompletion_currentposition_with_address">
      <source>qtn_pt_autocompletion_currentposition_with_address</source>
      <translation variants="no">Čia, %1</translation>
    </message>
    <message numerus="no" id="qtn_pt_unit_foot">
      <source>qtn_pt_unit_foot</source>
      <translation variants="no">pėd.</translation>
    </message>
    <message numerus="no" id="qtn_pt_aboutpage_termsconditions">
      <source>qtn_pt_aboutpage_termsconditions</source>
      <translation variants="no">Paslaugos sąlygos</translation>
    </message>
    <message numerus="no" id="qtn_pt_departureitem_loading">
      <source>qtn_pt_departureitem_loading</source>
      <translation variants="no">įkeliama</translation>
    </message>
    <message numerus="no" id="qtn_pt_timepicker_in_60min">
      <source>qtn_pt_timepicker_in_60min</source>
      <translation variants="no">Per 60</translation>
    </message>
    <message numerus="no" id="qtn_pt_error_hafas_connections">
      <source>qtn_pt_error_hafas_connections</source>
      <translation variants="no">Nerasta jokių kelionių.</translation>
    </message>
    <message numerus="no" id="qtn_pt_routeplanner_title">
      <source>qtn_pt_routeplanner_title</source>
      <translation variants="no">Kelionių planavimo priemonė</translation>
    </message>
    <message numerus="no" id="qtn_pt_stationdetails_escalators">
      <source>qtn_pt_stationdetails_escalators</source>
      <translation variants="no">Eskalatoriai</translation>
    </message>
    <message numerus="no" id="qtn_pt_aboutpage_noteofthanks">
      <source>qtn_pt_aboutpage_noteofthanks</source>
      <translation variants="no">Padėka</translation>
    </message>
    <message numerus="no" id="qtn_pt_timepicker_title">
      <source>qtn_pt_timepicker_title</source>
      <translation variants="no">Kelionės parinktys</translation>
    </message>
    <message numerus="no" id="qtn_pt_termsandconditions">
      <source>qtn_pt_termsandconditions</source>
      <translation variants="no">&lt;p&gt;Naudojantis paslaugomis ar atsisiunčiant medžiagą ryšio paslaugų teikėjo tinklu gali būti perduodama daug duomenų.
tBet kuri paslauga gali ne visada veikti ir būti tiksli. Jei šia programa naudojatės eismo sraute, visų pirma turite galvoti apie saugą.
Naudojantis paslauga gali būti siunčiama informacija apie jūsų buvimo vietą.
Kad galėtume tobulinti „Nokia“ gaminius ir jums teikti tikslesnę medžiagą, galime rinkti informaciją apie jūsų telefoną ir paslaugos naudojimą.
                               Be jūsų leidimo duomenų apie jus nepateiksime jokiai trečiajai šaliai.
Norėdami daugiau sužinoti apie privatumą, spustelkite [čia|%1].

Pasirinkdami „Pradėti“ patvirtinate, kad perskaitėte ir sutinkate su [„Nokia“ paslaugos sąlygomis|%2] ir [privatumo taisyklėmis|%3].&lt;/p&gt;</translation>
    </message>
    <message numerus="no" id="qtn_pt_coverage_button_skip">
      <source>qtn_pt_coverage_button_skip</source>
      <translation variants="no">Praleisti aptikimą</translation>
    </message>
    <message numerus="no" id="qtn_pt_coverage_button_showcoveredregions">
      <source>qtn_pt_coverage_button_showcoveredregions</source>
      <translation variants="no">Apimami regionai</translation>
    </message>
    <message numerus="no" id="qtn_pt_coverage_position_nocoverage">
      <source>qtn_pt_coverage_position_nocoverage</source>
      <translation variants="no">&lt;p&gt;Šiuo metu neturime informacijos apie %1.
&lt;/p&gt;
&lt;p&gt; Tačiau kasdien įtraukiame naujus miestus, todėl netrukus vėl patikrinkite.&lt;/p&gt;</translation>
    </message>
    <message numerus="no" id="qtn_pt_coverage_title_nocoverage">
      <source>qtn_pt_coverage_title_nocoverage</source>
      <translation variants="no">Apgailestaujame</translation>
    </message>
    <message numerus="no" id="qtn_pt_coverage_position_timetablecoverage">
      <source>qtn_pt_coverage_position_timetablecoverage</source>
      <translation variants="no">&lt;p&gt;/nAtrodo, esate&lt;b&gt;%1&lt;/b&gt;.
&lt;/p&gt;
&lt;p&gt;
Suderinama su %2. &lt;br&gt;prėpiamas šis ir daugelis kitų miestų.
&lt;/p&gt;</translation>
    </message>
    <message numerus="no" id="qtn_pt_firsttimeuse_welcome">
      <source>qtn_pt_firsttimeuse_welcome</source>
      <translation variants="no">Sveiki!</translation>
    </message>
    <message numerus="no" id="qtn_pt_coverage_button_continue">
      <source>qtn_pt_coverage_button_continue</source>
      <translation variants="no">Tęsti</translation>
    </message>
    <message numerus="no" id="qtn_pt_coverage_button_retry">
      <source>qtn_pt_coverage_button_retry</source>
      <translation variants="no">Bandyti dar kartą</translation>
    </message>
    <message numerus="no" id="qtn_pt_coverage_position_noposition">
      <source>qtn_pt_coverage_position_noposition</source>
      <translation variants="no">Nepavyko rasti jūsų dabartinės vietos. Aprėpties sąraše patikrinkite, ar programa veikia šiame regione.</translation>
    </message>
    <message numerus="no" id="qtn_pt_start">
      <source>qtn_pt_start</source>
      <translation variants="no">Pradėti </translation>
    </message>
    <message numerus="no" id="qtn_pt_nothanks">
      <source>qtn_pt_nothanks</source>
      <translation variants="no">Ačiū, ne</translation>
    </message>
    <message numerus="no" id="qtn_pt_stationdetails_title">
      <source>qtn_pt_stationdetails_title</source>
      <translation variants="no">Informacija apie stotelę (stotį)</translation>
    </message>
    <message numerus="no" id="qtn_pt_journeydetails_walk_title">
      <source>qtn_pt_journeydetails_walk_title</source>
      <translation variants="no">Ėjimo nurodymai</translation>
    </message>
    <message numerus="no" id="qtn_pt_journeydetails_show_on_map_title">
      <source>qtn_pt_journeydetails_show_on_map_title</source>
      <translation variants="no">Rodyti žemėlapyje</translation>
    </message>
    <message numerus="no" id="qtn_pt_journeydetails_show_on_map_text">
      <source>qtn_pt_journeydetails_show_on_map_text</source>
      <translation variants="no">&lt;b&gt;%1&lt;/b&gt; paruoštas rodyti programoje „Nokia“ žemėlapiai“.</translation>
    </message>
    <message numerus="no" id="qtn_pt_journeydetails_show">
      <source>qtn_pt_journeydetails_show</source>
      <translation variants="no">Žymėti žemėlapyje</translation>
    </message>
    <message numerus="no" id="qtn_pt_journeydetails_go">
      <source>qtn_pt_journeydetails_go</source>
      <translation variants="no">Pirmyn</translation>
    </message>
    <message numerus="no" id="qtn_pt_linedetails_title">
      <source>qtn_pt_linedetails_title</source>
      <translation variants="no">Maršruto informacija</translation>
    </message>
    <message numerus="no" id="qtn_pt_linedetails_on_time">
      <source>qtn_pt_linedetails_on_time</source>
      <translation variants="no">laiku</translation>
    </message>
    <message numerus="no" id="qtn_pt_linedetails_late">
      <source>qtn_pt_linedetails_late</source>
      <translation variants="no">%1 min. vėluoja</translation>
    </message>
    <message numerus="no" id="qtn_pt_journeydetails_walk_text">
      <source>qtn_pt_journeydetails_walk_text</source>
      <translation variants="no">Viskas paruošta navigacijai į &lt;b&gt;%1&lt;/b&gt; pėsčiomis pradėti programoje „Nokia“ žemėlapiai“</translation>
    </message>
    <message numerus="no" id="qtn_pt_feedback_contact">
      <source>qtn_pt_feedback_contact</source>
      <translation variants="no">Prašau su manimi susisiekti dėl papildomos informacijos (nebūtina)</translation>
    </message>
    <message numerus="no" id="qtn_pt_feedback_contact_placeholder">
      <source>qtn_pt_feedback_contact_placeholder</source>
      <translation variants="no">El. pašto adresas</translation>
    </message>
    <message numerus="no" id="qtn_pt_feedback_privacy">
      <source>qtn_pt_feedback_privacy</source>
      <translation variants="no">Jūsų pateikta informacija bus susieta su jūsų prietaisu ir jai bus taikomos [„Nokia“ privatumo taisyklės|%1]</translation>
    </message>
    <message numerus="no" id="qtn_pt_feedback_text_placeholder">
      <source>qtn_pt_feedback_text_placeholder</source>
      <translation variants="no">Jūsų komentaras</translation>
    </message>
    <message numerus="no" id="qtn_pt_privacy">
      <source>qtn_pt_privacy</source>
      <translation variants="no"> &lt;p&gt;
„Nokia“ gerbia jūsų privatumą. 
Kad galėtume tobulinti „Nokia“ gaminius ir jums teikti tikslesnę medžiagą, galime rinkti informaciją apie jūsų telefoną ir paslaugos naudojimą.

Be jūsų leidimo duomenų apie jus nepateiksime jokiai trečiajai šaliai.

[Privatumo taisyklės|%1]

[Jūsų privatumas %2|%3]
&lt;/p&gt;</translation>
    </message>
    <message numerus="no" id="qtn_pt_aboutpage_support">
      <source>qtn_pt_aboutpage_support</source>
      <translation variants="no">Pagalba</translation>
    </message>
    <message numerus="no" id="Application long caption">
      <source>Application long caption</source>
      <translation variants="no">Viešasis transportas</translation>
    </message>
    <message numerus="no" id="qtn_pt_error_noresults">
      <source>qtn_pt_error_noresults</source>
      <translation variants="no">Nėra baigto maršruto.</translation>
    </message>
    <message numerus="no" id="qtn_pt_privacy_title">
      <source>qtn_pt_privacy_title</source>
      <translation variants="no">Privatumas</translation>
    </message>
    <message numerus="no" id="qtn_pt_routeplanner_input_watermark">
      <source>qtn_pt_routeplanner_input_watermark</source>
      <translation variants="no">Ieškoti stotelių arba vietų</translation>
    </message>
    <message numerus="no" id="qtn_pt_location_no_info">
      <source>qtn_pt_location_no_info</source>
      <translation variants="no">Jūsų pasirinkta vieta</translation>
    </message>
    <message numerus="no" id="qtn_pt_location_taiwan">
      <source>qtn_pt_location_taiwan</source>
      <translation variants="no">Taivanas</translation>
    </message>
    <message numerus="no" id="qtn_pt_location_taiwan_area">
      <source>qtn_pt_location_taiwan_area</source>
      <translation variants="no">Taivano sritis</translation>
    </message>
    <message numerus="no" id="Package name">
      <source>Package name</source>
      <translation variants="no">Viešasis transportas</translation>
    </message>
    <message numerus="no" id="Smart installer package name">
      <source>Smart installer package name</source>
      <translation variants="no">Viešasis transportas</translation>
    </message>
    <message numerus="no" id="qtn_pt_coverage_thanksforinstalling">
      <source>qtn_pt_coverage_thanksforinstalling</source>
      <translation variants="no">Dėkojame, kad įdiegėte %1&lt;br&gt; Mes teikiame suplanuotų maršrutų informaciją %2 pasaulio miestuose.</translation>
    </message>
  </context>
</TS>
