<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="nl">
  <context>
    <name>Maps</name>
    <message numerus="no" id="qtn_pt_feedback_text">
      <source>qtn_pt_feedback_text</source>
      <translation variants="no">Kunt u ons vertellen waarom u deze score hebt gegeven?</translation>
    </message>
    <message numerus="no" id="qtn_pt_ok">
      <source>qtn_pt_ok</source>
      <translation variants="no">OK</translation>
    </message>
    <message numerus="no" id="qtn_pt_aboutpage_title">
      <source>qtn_pt_aboutpage_title</source>
      <translation variants="no">Over deze app</translation>
    </message>
    <message numerus="no" id="qtn_pt_ttdropdown_transportmode_0">
      <source>qtn_pt_ttdropdown_transportmode_0</source>
      <translation variants="no">Sneltrein</translation>
    </message>
    <message numerus="no" id="qtn_pt_timepicker_pm">
      <source>qtn_pt_timepicker_pm</source>
      <translation variants="no">PM</translation>
    </message>
    <message numerus="no" id="qtn_pt_ttdropdown_transportmode_3">
      <source>qtn_pt_ttdropdown_transportmode_3</source>
      <translation variants="no">Regionale trein</translation>
    </message>
    <message numerus="no" id="qtn_pt_cancel">
      <source>qtn_pt_cancel</source>
      <translation variants="no">Annul.</translation>
    </message>
    <message numerus="no" id="qtn_pt_journeydetails_walkdistancetime">
      <source>qtn_pt_journeydetails_walkdistancetime</source>
      <translation variants="no">Loop gedurende %2 (%1)</translation>
    </message>
    <message numerus="no" id="qtn_pt_journeydetails_today">
      <source>qtn_pt_journeydetails_today</source>
      <translation variants="no">Vandaag</translation>
    </message>
    <message numerus="no" id="qtn_pt_routeplanner_from">
      <source>qtn_pt_routeplanner_from</source>
      <translation variants="no">Van</translation>
    </message>
    <message numerus="no" id="qtn_pt_routeplanner_earlier_hold">
      <source>qtn_pt_routeplanner_earlier_hold</source>
      <translation variants="no">Vasthouden om eerdere reizen weer te geven</translation>
    </message>
    <message numerus="no" id="qtn_pt_value_with_unit">
      <source>qtn_pt_value_with_unit</source>
      <translation variants="no">%1 %2</translation>
    </message>
    <message numerus="no" id="qtn_pt_aboutpage_appdescription">
      <source>qtn_pt_aboutpage_appdescription</source>
      <translation variants="no">Navigatie openbaar vervoer</translation>
    </message>
    <message numerus="no" id="qtn_pt_stationdetails_blindguidinglines">
      <source>qtn_pt_stationdetails_blindguidinglines</source>
      <translation variants="no">Routering voor blinden</translation>
    </message>
    <message numerus="no" id="qtn_pt_journeydetails_navigation_error">
      <source>qtn_pt_journeydetails_navigation_error</source>
      <translation variants="no">Kon Kaarten niet openen. Probeer het nogmaals.</translation>
    </message>
    <message numerus="no" id="qtn_pt_homepage_nextDepartures">
      <source>qtn_pt_homepage_nextDepartures</source>
      <translation variants="no">De volgende reizen van hier naar</translation>
    </message>
    <message numerus="no" id="qtn_pt_splashscreen_welcome_to">
      <source>qtn_pt_splashscreen_welcome_to</source>
      <translation variants="no">Welkom bij</translation>
    </message>
    <message numerus="no" id="qtn_pt_value_less_than_one">
      <source>qtn_pt_value_less_than_one</source>
      <translation variants="no">&lt; 1</translation>
    </message>
    <message numerus="no" id="qtn_pt_supportedRegions_title">
      <source>qtn_pt_supportedRegions_title</source>
      <translation variants="no">Info over dekking</translation>
    </message>
    <message numerus="no" id="qtn_pt_homepage_routeplanner">
      <source>qtn_pt_homepage_routeplanner</source>
      <translation variants="no">Reisplanner</translation>
    </message>
    <message numerus="no" id="qtn_pt_feedback_positive">
      <source>qtn_pt_feedback_positive</source>
      <translation variants="no">Zeer waarschijnlijk</translation>
    </message>
    <message numerus="no" id="qtn_pt_homepage_update_notnow">
      <source>qtn_pt_homepage_update_notnow</source>
      <translation variants="no">Niet nu</translation>
    </message>
    <message numerus="no" id="qtn_pt_ttdropdown_transportmode_all">
      <source>qtn_pt_ttdropdown_transportmode_all</source>
      <translation variants="no">Alle vervoerswijzen</translation>
    </message>
    <message numerus="no" id="qtn_pt_unit_minute">
      <source>qtn_pt_unit_minute</source>
      <translation variants="no">min</translation>
    </message>
    <message numerus="no" id="qtn_pt_departures_station_title">
      <source>qtn_pt_departures_station_title</source>
      <translation variants="no">Verwachte vertrektijden</translation>
    </message>
    <message numerus="no" id="qtn_pt_unit_hour">
      <source>qtn_pt_unit_hour</source>
      <translation variants="no">u</translation>
    </message>
    <message numerus="no" id="qtn_pt_ttdropdown_transportmode_7">
      <source>qtn_pt_ttdropdown_transportmode_7</source>
      <translation variants="no">Metro</translation>
    </message>
    <message numerus="no" id="qtn_pt_error_area_not_supported">
      <source>qtn_pt_error_area_not_supported</source>
      <translation variants="no">Voor dit gebied is nog geen vervoersinfo beschikbaar.</translation>
    </message>
    <message numerus="no" id="qtn_pt_homepage_update_mandatory_text">
      <source>qtn_pt_homepage_update_mandatory_text</source>
      <translation variants="no">Deze toepassing moet snel worden bijgewerkt. Tik op 'Update' als u dat nu wilt doen.</translation>
    </message>
    <message numerus="no" id="qtn_pt_journeydetails_tomorrow">
      <source>qtn_pt_journeydetails_tomorrow</source>
      <translation variants="no">Morgen</translation>
    </message>
    <message numerus="no" id="qtn_pt_ttdropdown_transportmode_9">
      <source>qtn_pt_ttdropdown_transportmode_9</source>
      <translation variants="no">Bestelde dienst</translation>
    </message>
    <message numerus="no" id="qtn_pt_ttdropdown_transportmode_5">
      <source>qtn_pt_ttdropdown_transportmode_5</source>
      <translation variants="no">Bus</translation>
    </message>
    <message numerus="no" id="qtn_pt_routeplanner_noconnections">
      <source>qtn_pt_routeplanner_noconnections</source>
      <translation variants="no">Geen reizen gevonden</translation>
    </message>
    <message numerus="no" id="qtn_pt_journeycalendaritem_minutes_ago">
      <source>qtn_pt_journeycalendaritem_minutes_ago</source>
      <translation variants="no">%1 min geleden</translation>
    </message>
    <message numerus="no" id="qtn_pt_homepage_update_update">
      <source>qtn_pt_homepage_update_update</source>
      <translation variants="no">Update</translation>
    </message>
    <message numerus="no" id="qtn_pt_journeydetails_estimateridingtime">
      <source>qtn_pt_journeydetails_estimateridingtime</source>
      <translation variants="no">~%1 met</translation>
    </message>
    <message numerus="no" id="qtn_pt_loadingindicator_loading">
      <source>qtn_pt_loadingindicator_loading</source>
      <translation variants="no">Bezig met laden</translation>
    </message>
    <message numerus="no" id="qtn_pt_routeplanner_nomoreconnections">
      <source>qtn_pt_routeplanner_nomoreconnections</source>
      <translation variants="no">Geen verdere reizen gevonden</translation>
    </message>
    <message numerus="no" id="qtn_pt_routingerror_retry">
      <source>qtn_pt_routingerror_retry</source>
      <translation variants="no">Opnieuw</translation>
    </message>
    <message numerus="no" id="qtn_pt_homepage_favoriteroutesupdated_title">
      <source>qtn_pt_homepage_favoriteroutesupdated_title</source>
      <translation variants="no">Nieuwe optie</translation>
    </message>
    <message numerus="no" id="qtn_pt_routeplanner_later_loading">
      <source>qtn_pt_routeplanner_later_loading</source>
      <translation variants="no">Latere reizen ophalen</translation>
    </message>
    <message numerus="no" id="qtn_pt_editfavorite_showHomeScreen">
      <source>qtn_pt_editfavorite_showHomeScreen</source>
      <translation variants="no">De volgende reizen bij het starten weergeven</translation>
    </message>
    <message numerus="no" id="qtn_pt_homepage_favoriteroutesupdated_text">
      <source>qtn_pt_homepage_favoriteroutesupdated_text</source>
      <translation variants="no">Nu kunt u uw favoriete bestemmingen uit de reisplanner opslaan en de volgende reizen direct zien. (Uw bestaande favorieten zijn bijgewerkt of opgeslagen in uw zoekgeschiedenis.)</translation>
    </message>
    <message numerus="no" id="qtn_pt_departureitem_minutes">
      <source>qtn_pt_departureitem_minutes</source>
      <translation variants="no">%1 min</translation>
    </message>
    <message numerus="no" id="qtn_pt_timepicker_in_15min">
      <source>qtn_pt_timepicker_in_15min</source>
      <translation variants="no">Over 15</translation>
    </message>
    <message numerus="no" id="qtn_pt_routeplanner_gps_waiting">
      <source>qtn_pt_routeplanner_gps_waiting</source>
      <translation variants="no">Uw locatie ophalen</translation>
    </message>
    <message numerus="no" id="qtn_pt_autocompletion_currentposition_no_address">
      <source>qtn_pt_autocompletion_currentposition_no_address</source>
      <translation variants="no">Uw locatie</translation>
    </message>
    <message numerus="no" id="qtn_pt_error_network_release">
      <source>qtn_pt_error_network_release</source>
      <translation variants="no">Uw verbinding schijnt verbroken te zijn. Controleer dit en probeer het nogmaals.</translation>
    </message>
    <message numerus="no" id="qtn_pt_journeydetails_from_location">
      <source>qtn_pt_journeydetails_from_location</source>
      <translation variants="no">Van %1</translation>
    </message>
    <message numerus="no" id="qtn_pt_homepage_update_downloading">
      <source>qtn_pt_homepage_update_downloading</source>
      <translation variants="no">Downloaden</translation>
    </message>
    <message numerus="no" id="qtn_pt_feedback_title">
      <source>qtn_pt_feedback_title</source>
      <translation variants="no">Feedback</translation>
    </message>
    <message numerus="no" id="qtn_pt_ttfilterpage_title">
      <source>qtn_pt_ttfilterpage_title</source>
      <translation variants="no">Filterinstellingen</translation>
    </message>
    <message numerus="no" id="qtn_pt_homepage_departures">
      <source>qtn_pt_homepage_departures</source>
      <translation variants="no">Vervoer in de omgeving</translation>
    </message>
    <message numerus="no" id="qtn_pt_supportedRegions_header_withsimplerouting">
      <source>qtn_pt_supportedRegions_header_withsimplerouting</source>
      <translation variants="no">Lijnen zijn beschikbaar in %1 steden wereldwijd, evenals tijdschema's voor deze gebieden.</translation>
    </message>
    <message numerus="no" id="qtn_pt_unit_mile">
      <source>qtn_pt_unit_mile</source>
      <translation variants="no">mijl</translation>
    </message>
    <message numerus="no" id="qtn_pt_feedback_error_no_rating">
      <source>qtn_pt_feedback_error_no_rating</source>
      <translation variants="no">Kies een waardering</translation>
    </message>
    <message numerus="no" id="qtn_pt_routeplanner_later_drag">
      <source>qtn_pt_routeplanner_later_drag</source>
      <translation variants="no">Slepen om latere reizen op te halen</translation>
    </message>
    <message numerus="no" id="qtn_pt_timepicker_now">
      <source>qtn_pt_timepicker_now</source>
      <translation variants="no">Nu</translation>
    </message>
    <message numerus="no" id="qtn_pt_journeydetails_to_location">
      <source>qtn_pt_journeydetails_to_location</source>
      <translation variants="no">Naar %1</translation>
    </message>
    <message numerus="no" id="qtn_pt_aboutpage_feedback">
      <source>qtn_pt_aboutpage_feedback</source>
      <translation variants="no">Feedback</translation>
    </message>
    <message numerus="no" id="qtn_pt_aboutpage_acknowledgements_opensource_nokiapt_uses">
      <source>qtn_pt_aboutpage_acknowledgements_opensource_nokiapt_uses</source>
      <translation variants="no">%1 gebruikt Nokia Qt, de cross-platform toepassing en UI-framework, en de Zlib Compression Library, geschreven door Jean-Loup Gailly en Mark Adler.</translation>
    </message>
    <message numerus="no" id="qtn_pt_departures_title">
      <source>qtn_pt_departures_title</source>
      <translation variants="no">Vervoer in de omgeving</translation>
    </message>
    <message numerus="no" id="qtn_pt_supportedRegions_header_nosimplerouting">
      <source>qtn_pt_supportedRegions_header_nosimplerouting</source>
      <translation variants="no">Waar tijdschema's verkrijgbaar zijn</translation>
    </message>
    <message numerus="no" id="qtn_pt_ttdropdown_transportmode_1">
      <source>qtn_pt_ttdropdown_transportmode_1</source>
      <translation variants="no">Intercity </translation>
    </message>
    <message numerus="no" id="qtn_pt_stationdetails_barrierfree">
      <source>qtn_pt_stationdetails_barrierfree</source>
      <translation variants="no">Zonder hekken</translation>
    </message>
    <message numerus="no" id="qtn_pt_aboutpage_acknowledgements_opensource">
      <source>qtn_pt_aboutpage_acknowledgements_opensource</source>
      <translation variants="no">Open-source software</translation>
    </message>
    <message numerus="no" id="qtn_pt_unit_kilometer">
      <source>qtn_pt_unit_kilometer</source>
      <translation variants="no">km</translation>
    </message>
    <message numerus="no" id="qtn_pt_journey_no_warranty">
      <source>qtn_pt_journey_no_warranty</source>
      <translation variants="no">Alle informatie wordt geleverd zonder enige garantie</translation>
    </message>
    <message numerus="no" id="qtn_pt_routingerror_showregions">
      <source>qtn_pt_routingerror_showregions</source>
      <translation variants="no">Gebieden weergeven</translation>
    </message>
    <message numerus="no" id="qtn_pt_aboutpage_acknowledgements_source">
      <source>qtn_pt_aboutpage_acknowledgements_source</source>
      <translation variants="no">met de hulp van</translation>
    </message>
    <message numerus="no" id="qtn_pt_homepage_update_updating_text">
      <source>qtn_pt_homepage_update_updating_text</source>
      <translation variants="no">Wacht terwijl de toepassing wordt bijgewerkt. (Hij sluit en opent opnieuw.)</translation>
    </message>
    <message numerus="no" id="qtn_pt_editfavorite_namefield_label">
      <source>qtn_pt_editfavorite_namefield_label</source>
      <translation variants="no">Kies een naam</translation>
    </message>
    <message numerus="no" id="qtn_pt_aboutpage_supportedRegions">
      <source>qtn_pt_aboutpage_supportedRegions</source>
      <translation variants="no">Gedekte gebieden</translation>
    </message>
    <message numerus="no" id="qtn_pt_timepicker_departure">
      <source>qtn_pt_timepicker_departure</source>
      <translation variants="no">Vertrek</translation>
    </message>
    <message numerus="no" id="qtn_pt_timepicker_am">
      <source>qtn_pt_timepicker_am</source>
      <translation variants="no">AM</translation>
    </message>
    <message numerus="no" id="Application short caption">
      <source>Application short caption</source>
      <translation variants="no">Openbaar vervoer</translation>
    </message>
    <message numerus="no" id="qtn_pt_journeydetails_month_day">
      <source>qtn_pt_journeydetails_month_day</source>
      <translation variants="no">d MMM</translation>
    </message>
    <message numerus="no" id="qtn_pt_autocompletion_retry_search">
      <source>qtn_pt_autocompletion_retry_search</source>
      <translation variants="no">Kan geen resultaten vinden</translation>
    </message>
    <message numerus="no" id="qtn_pt_ttdropdown_transportmode_4">
      <source>qtn_pt_ttdropdown_transportmode_4</source>
      <translation variants="no">Voorstadstrein</translation>
    </message>
    <message numerus="no" id="qtn_pt_feedback_recommend_app">
      <source>qtn_pt_feedback_recommend_app</source>
      <translation variants="no">Hoe waarschijnlijk is het dat u %1 aanbeveelt aan een vriend of collega?</translation>
    </message>
    <message numerus="no" id="qtn_pt_editfavorite_helpText">
      <source>qtn_pt_editfavorite_helpText</source>
      <translation variants="no">Haal snel en gemakkelijk reizen naar deze plaats op in het beginscherm %1.</translation>
    </message>
    <message numerus="no" id="qtn_pt_routeplanner_to">
      <source>qtn_pt_routeplanner_to</source>
      <translation variants="no">Naar</translation>
    </message>
    <message numerus="no" id="qtn_pt_journeydetails_title">
      <source>qtn_pt_journeydetails_title</source>
      <translation variants="no">Reis %1/%2</translation>
    </message>
    <message numerus="no" id="qtn_pt_ttdropdown_transportmode_6">
      <source>qtn_pt_ttdropdown_transportmode_6</source>
      <translation variants="no">Veerboot</translation>
    </message>
    <message numerus="no" id="qtn_pt_editfavorite_title">
      <source>qtn_pt_editfavorite_title</source>
      <translation variants="no">Favorieten</translation>
    </message>
    <message numerus="no" id="qtn_pt_stationdetails_elevators">
      <source>qtn_pt_stationdetails_elevators</source>
      <translation variants="no">Liften</translation>
    </message>
    <message numerus="no" id="qtn_pt_ttfilterpage_select_transport">
      <source>qtn_pt_ttfilterpage_select_transport</source>
      <translation variants="no">Kies uw voorkeurswijze van vervoer</translation>
    </message>
    <message numerus="no" id="qtn_pt_editfavorite_caption">
      <source>qtn_pt_editfavorite_caption</source>
      <translation variants="no">Een favoriete bestemming opslaan</translation>
    </message>
    <message numerus="no" id="qtn_pt_favoritedestinationitem_unavailable">
      <source>qtn_pt_favoritedestinationitem_unavailable</source>
      <translation variants="no">Kan u geen reizen laten zien</translation>
    </message>
    <message numerus="no" id="qtn_pt_unit_meter">
      <source>qtn_pt_unit_meter</source>
      <translation variants="no">m</translation>
    </message>
    <message numerus="no" id="qtn_pt_journeydetails_navigation_text">
      <source>qtn_pt_journeydetails_navigation_text</source>
      <translation variants="no">Een ogenblik terwijl Kaarten start</translation>
    </message>
    <message numerus="no" id="qtn_pt_journeycalendaritem_in_minutes">
      <source>qtn_pt_journeycalendaritem_in_minutes</source>
      <translation variants="no">over %1 min</translation>
    </message>
    <message numerus="no" id="qtn_pt_homepage_update_cancel">
      <source>qtn_pt_homepage_update_cancel</source>
      <translation variants="no">Annuleren</translation>
    </message>
    <message numerus="no" id="qtn_pt_homepage_update_low_text">
      <source>qtn_pt_homepage_update_low_text</source>
      <translation variants="no">Voor deze toepassing is een update beschikbaar. Tik op 'Update' om deze nu te installeren of op 'Niet nu' om dit over te slaan.</translation>
    </message>
    <message numerus="no" id="qtn_pt_editfavorite_create">
      <source>qtn_pt_editfavorite_create</source>
      <translation variants="no">Opslaan</translation>
    </message>
    <message numerus="no" id="qtn_pt_feedback_negative">
      <source>qtn_pt_feedback_negative</source>
      <translation variants="no">Zeer onwaarschijnlijk</translation>
    </message>
    <message numerus="no" id="qtn_pt_departures_header_label">
      <source>qtn_pt_departures_header_label</source>
      <translation variants="no">Zoeken naar vervoer in de buurt van</translation>
    </message>
    <message numerus="no" id="qtn_pt_timepicker_arrival">
      <source>qtn_pt_timepicker_arrival</source>
      <translation variants="no">Aankomst</translation>
    </message>
    <message numerus="no" id="qtn_pt_aboutpage_buildnumber">
      <source>qtn_pt_aboutpage_buildnumber</source>
      <translation variants="no">Build %1</translation>
    </message>
    <message numerus="no" id="qtn_pt_journeydetails_platform">
      <source>qtn_pt_journeydetails_platform</source>
      <translation variants="no">Platform %1</translation>
    </message>
    <message numerus="no" id="qtn_pt_routeplanner_earlier_drag">
      <source>qtn_pt_routeplanner_earlier_drag</source>
      <translation variants="no">Slepen om eerdere reizen weer te geven</translation>
    </message>
    <message numerus="no" id="qtn_pt_routeplanner_later_hold">
      <source>qtn_pt_routeplanner_later_hold</source>
      <translation variants="no">Vasthouden om latere reizen op te halen</translation>
    </message>
    <message numerus="no" id="qtn_pt_routeplanner_simpleroutinghint">
      <source>qtn_pt_routeplanner_simpleroutinghint</source>
      <translation variants="no">Kan u geen nauwkeurige planning voor deze reis geven</translation>
    </message>
    <message numerus="no" id="qtn_pt_feedback_send_error">
      <source>qtn_pt_feedback_send_error</source>
      <translation variants="no">Kan uw feedback niet verzenden.</translation>
    </message>
    <message numerus="no" id="qtn_pt_error_places">
      <source>qtn_pt_error_places</source>
      <translation variants="no">Kan geen resultaten vinden.</translation>
    </message>
    <message numerus="no" id="qtn_pt_ttdropdown_transportmode_8">
      <source>qtn_pt_ttdropdown_transportmode_8</source>
      <translation variants="no">Tram</translation>
    </message>
    <message numerus="no" id="qtn_pt_routeplanner_earlier_loading">
      <source>qtn_pt_routeplanner_earlier_loading</source>
      <translation variants="no">Eerdere reizen ophalen</translation>
    </message>
    <message numerus="no" id="qtn_pt_homepage_update_exit">
      <source>qtn_pt_homepage_update_exit</source>
      <translation variants="no">Sluiten</translation>
    </message>
    <message numerus="no" id="qtn_pt_estimate_time">
      <source>qtn_pt_estimate_time</source>
      <translation variants="no">~%1</translation>
    </message>
    <message numerus="no" id="qtn_pt_stationdetails_bicyclesallowed">
      <source>qtn_pt_stationdetails_bicyclesallowed</source>
      <translation variants="no">Fietsen toegestaan</translation>
    </message>
    <message numerus="no" id="qtn_pt_departurenearbystations_nodepartures">
      <source>qtn_pt_departurenearbystations_nodepartures</source>
      <translation variants="no">Geen vertrek binnen 1 uur</translation>
    </message>
    <message numerus="no" id="qtn_pt_homepage_update_timeleft">
      <source>qtn_pt_homepage_update_timeleft</source>
      <translation variants="no">%1 resterend</translation>
    </message>
    <message numerus="no" id="qtn_pt_ttdropdown_transportmode_2">
      <source>qtn_pt_ttdropdown_transportmode_2</source>
      <translation variants="no">Snelle trein</translation>
    </message>
    <message numerus="no" id="qtn_pt_feedback_submit">
      <source>qtn_pt_feedback_submit</source>
      <translation variants="no">Verz.</translation>
    </message>
    <message numerus="no" id="qtn_pt_app_error">
      <source>qtn_pt_app_error</source>
      <translation variants="no">Er is iets fout gegaan</translation>
    </message>
    <message numerus="no" id="qtn_pt_favoritedestinationitem_alreadythere">
      <source>qtn_pt_favoritedestinationitem_alreadythere</source>
      <translation variants="no">U bent nu hier</translation>
    </message>
    <message numerus="no" id="qtn_pt_error_hafas_stations">
      <source>qtn_pt_error_hafas_stations</source>
      <translation variants="no">Kan geen resultaten vinden.
%1</translation>
    </message>
    <message numerus="no" id="qtn_pt_autocompletion_start_searching">
      <source>qtn_pt_autocompletion_start_searching</source>
      <translation variants="no">Bezig met zoeken</translation>
    </message>
    <message numerus="no" id="qtn_pt_autocompletion_currentposition_with_address">
      <source>qtn_pt_autocompletion_currentposition_with_address</source>
      <translation variants="no">Hier, %1</translation>
    </message>
    <message numerus="no" id="qtn_pt_unit_foot">
      <source>qtn_pt_unit_foot</source>
      <translation variants="no">voet</translation>
    </message>
    <message numerus="no" id="qtn_pt_aboutpage_termsconditions">
      <source>qtn_pt_aboutpage_termsconditions</source>
      <translation variants="no">Servicevoorwaarden</translation>
    </message>
    <message numerus="no" id="qtn_pt_departureitem_loading">
      <source>qtn_pt_departureitem_loading</source>
      <translation variants="no">bezig met laden</translation>
    </message>
    <message numerus="no" id="qtn_pt_timepicker_in_60min">
      <source>qtn_pt_timepicker_in_60min</source>
      <translation variants="no">Over 60</translation>
    </message>
    <message numerus="no" id="qtn_pt_error_hafas_connections">
      <source>qtn_pt_error_hafas_connections</source>
      <translation variants="no">Kan geen reizen vinden.</translation>
    </message>
    <message numerus="no" id="qtn_pt_routeplanner_title">
      <source>qtn_pt_routeplanner_title</source>
      <translation variants="no">Reisplanner</translation>
    </message>
    <message numerus="no" id="qtn_pt_stationdetails_escalators">
      <source>qtn_pt_stationdetails_escalators</source>
      <translation variants="no">Roltrappen</translation>
    </message>
    <message numerus="no" id="qtn_pt_aboutpage_noteofthanks">
      <source>qtn_pt_aboutpage_noteofthanks</source>
      <translation variants="no">Bedankbericht</translation>
    </message>
    <message numerus="no" id="qtn_pt_timepicker_title">
      <source>qtn_pt_timepicker_title</source>
      <translation variants="no">Reisopties</translation>
    </message>
    <message numerus="no" id="qtn_pt_termsandconditions">
      <source>qtn_pt_termsandconditions</source>
      <translation variants="no">&lt;p&gt;Het gebruik van diensten of het downloaden van inhoud kan grote hoeveelheden gegevens door het netwerk van uw provider sturen.
Alle diensten zijn mogeljik niet beschikbaar of nauwkeurig op elk moment. Bij het gebruik van deze toepassing in het verkeer moet u op de eerste plaats aan de veiligheid denken. Het gebruik van de dienst kan het verzenden van uw gegevens omvatten.
We kunnen informatie over de telefoon en uw gebruik van de dienst verzamelen om Nokia-producten te verbeteren, en om u relevantere inhoud te bieden.
We delen uw gegevens niet met derden zonder u eerst om toestemming te vragen.
Klik voor meer informatie over privacy [hier|%1].

Door op  'Start'  te klikken, bevestigt u dat u de [Nokia Service-voorwaarden|%2] en het [Privacybeleid|%3] hebt gelezen en ermee akkoord bent.&lt;/p&gt;</translation>
    </message>
    <message numerus="no" id="qtn_pt_coverage_button_skip">
      <source>qtn_pt_coverage_button_skip</source>
      <translation variants="no">Detectie overslaan</translation>
    </message>
    <message numerus="no" id="qtn_pt_coverage_button_showcoveredregions">
      <source>qtn_pt_coverage_button_showcoveredregions</source>
      <translation variants="no">Gedekte gebieden</translation>
    </message>
    <message numerus="no" id="qtn_pt_coverage_position_nocoverage">
      <source>qtn_pt_coverage_position_nocoverage</source>
      <translation variants="no">Op dit moment beschikken we niet over info voor %1.
&lt;/p&gt;
&lt;p&gt;Maar we voegen dagelijks nieuwe steden toe, dus blijf ons volgen.&lt;/p&gt;</translation>
    </message>
    <message numerus="no" id="qtn_pt_coverage_title_nocoverage">
      <source>qtn_pt_coverage_title_nocoverage</source>
      <translation variants="no">Helaas</translation>
    </message>
    <message numerus="no" id="qtn_pt_coverage_position_timetablecoverage">
      <source>qtn_pt_coverage_position_timetablecoverage</source>
      <translation variants="no">U lijkt in &lt;b&gt;%1&lt;/b&gt; te zijn. We ondersteunen %2.n&lt;/p&gt;
&lt;p&gt;
We dekken deze en veel andere steden.
&lt;/p&gt;</translation>
    </message>
    <message numerus="no" id="qtn_pt_firsttimeuse_welcome">
      <source>qtn_pt_firsttimeuse_welcome</source>
      <translation variants="no">Welkom</translation>
    </message>
    <message numerus="no" id="qtn_pt_coverage_button_continue">
      <source>qtn_pt_coverage_button_continue</source>
      <translation variants="no">Doorgaan</translation>
    </message>
    <message numerus="no" id="qtn_pt_coverage_button_retry">
      <source>qtn_pt_coverage_button_retry</source>
      <translation variants="no">Nogmaals proberen</translation>
    </message>
    <message numerus="no" id="qtn_pt_coverage_position_noposition">
      <source>qtn_pt_coverage_position_noposition</source>
      <translation variants="no">Kan uw huidige locatie niet vinden. Zie de dekkingslijst om te controleren of de app in dit gebied werkt.</translation>
    </message>
    <message numerus="no" id="qtn_pt_start">
      <source>qtn_pt_start</source>
      <translation variants="no">Start</translation>
    </message>
    <message numerus="no" id="qtn_pt_nothanks">
      <source>qtn_pt_nothanks</source>
      <translation variants="no">Nee dank u</translation>
    </message>
    <message numerus="no" id="qtn_pt_stationdetails_title">
      <source>qtn_pt_stationdetails_title</source>
      <translation variants="no">Info halte/station</translation>
    </message>
    <message numerus="no" id="qtn_pt_journeydetails_walk_title">
      <source>qtn_pt_journeydetails_walk_title</source>
      <translation variants="no">Wandelnavigatie</translation>
    </message>
    <message numerus="no" id="qtn_pt_journeydetails_show_on_map_title">
      <source>qtn_pt_journeydetails_show_on_map_title</source>
      <translation variants="no">Op kaart weergeven</translation>
    </message>
    <message numerus="no" id="qtn_pt_journeydetails_show_on_map_text">
      <source>qtn_pt_journeydetails_show_on_map_text</source>
      <translation variants="no">Klaar om &lt;b&gt;%1&lt;/b&gt; in Nokia Maps weer te geven</translation>
    </message>
    <message numerus="no" id="qtn_pt_journeydetails_show">
      <source>qtn_pt_journeydetails_show</source>
      <translation variants="no">In kaart</translation>
    </message>
    <message numerus="no" id="qtn_pt_journeydetails_go">
      <source>qtn_pt_journeydetails_go</source>
      <translation variants="no">Laten we gaan</translation>
    </message>
    <message numerus="no" id="qtn_pt_linedetails_title">
      <source>qtn_pt_linedetails_title</source>
      <translation variants="no">Lijninfo</translation>
    </message>
    <message numerus="no" id="qtn_pt_linedetails_on_time">
      <source>qtn_pt_linedetails_on_time</source>
      <translation variants="no">op tijd</translation>
    </message>
    <message numerus="no" id="qtn_pt_linedetails_late">
      <source>qtn_pt_linedetails_late</source>
      <translation variants="no">%1 min later</translation>
    </message>
    <message numerus="no" id="qtn_pt_journeydetails_walk_text">
      <source>qtn_pt_journeydetails_walk_text</source>
      <translation variants="no">Klaar voor de wandelnavigatie naar %1 in Nokia Kaarten.</translation>
    </message>
    <message numerus="no" id="qtn_pt_feedback_contact">
      <source>qtn_pt_feedback_contact</source>
      <translation variants="no">Neem contact met me op voor meer info (optioneel)</translation>
    </message>
    <message numerus="no" id="qtn_pt_feedback_contact_placeholder">
      <source>qtn_pt_feedback_contact_placeholder</source>
      <translation variants="no">E-mailadres</translation>
    </message>
    <message numerus="no" id="qtn_pt_feedback_privacy">
      <source>qtn_pt_feedback_privacy</source>
      <translation variants="no">Uw informatie wordt aan uw toestel gekoppeld en behandeld overeenkomstig het [Nokia Privacy-beleid|%1]</translation>
    </message>
    <message numerus="no" id="qtn_pt_feedback_text_placeholder">
      <source>qtn_pt_feedback_text_placeholder</source>
      <translation variants="no">Uw commentaar</translation>
    </message>
    <message numerus="no" id="qtn_pt_privacy">
      <source>qtn_pt_privacy</source>
      <translation variants="no">&lt;p&gt;
Nokia respecteert uw privacy.
We kunnen informatie verzamelen over uw telefoon en uw gebruik van de dienst om producten van Nokia te verbeteren, en om u te voorzien van relevantere inhoud..

We delen uw gegevens niet met derden zonder u om toestemming te vragent.

[Privacybeleid|%1]

[Uw privacy in %2|%3]
&lt;/p&gt;</translation>
    </message>
    <message numerus="no" id="qtn_pt_aboutpage_support">
      <source>qtn_pt_aboutpage_support</source>
      <translation variants="no">Ondersteuning</translation>
    </message>
    <message numerus="no" id="Application long caption">
      <source>Application long caption</source>
      <translation variants="no">Public Transport</translation>
    </message>
    <message numerus="no" id="qtn_pt_error_noresults">
      <source>qtn_pt_error_noresults</source>
      <translation variants="no">Er is geen complete route beschikbaar.</translation>
    </message>
    <message numerus="no" id="qtn_pt_privacy_title">
      <source>qtn_pt_privacy_title</source>
      <translation variants="no">Privacy</translation>
    </message>
    <message numerus="no" id="qtn_pt_routeplanner_input_watermark">
      <source>qtn_pt_routeplanner_input_watermark</source>
      <translation variants="no">Haltes of plaatsen zoeken</translation>
    </message>
    <message numerus="no" id="qtn_pt_location_no_info">
      <source>qtn_pt_location_no_info</source>
      <translation variants="no">De geselecteerde locatie</translation>
    </message>
    <message numerus="no" id="qtn_pt_location_taiwan">
      <source>qtn_pt_location_taiwan</source>
      <translation variants="no">Taiwan</translation>
    </message>
    <message numerus="no" id="qtn_pt_location_taiwan_area">
      <source>qtn_pt_location_taiwan_area</source>
      <translation variants="no">Taiwan</translation>
    </message>
    <message numerus="no" id="Package name">
      <source>Package name</source>
      <translation variants="no">Public Transport</translation>
    </message>
    <message numerus="no" id="Smart installer package name">
      <source>Smart installer package name</source>
      <translation variants="no">Public Transport</translation>
    </message>
    <message numerus="no" id="qtn_pt_coverage_thanksforinstalling">
      <source>qtn_pt_coverage_thanksforinstalling</source>
      <translation variants="no">Bedankt voor het installeren van %1.&lt;br&gt;We hebben geplande route-info in %2 steden wereldwijd. </translation>
    </message>
  </context>
</TS>
