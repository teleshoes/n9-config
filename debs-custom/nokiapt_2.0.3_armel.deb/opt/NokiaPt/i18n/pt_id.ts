<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="id">
  <context>
    <name>Maps</name>
    <message numerus="no" id="qtn_pt_feedback_text">
      <source>qtn_pt_feedback_text</source>
      <translation variants="no">Dapatkah Anda memberi tahu kami mengapa Anda memberi nilai ini?</translation>
    </message>
    <message numerus="no" id="qtn_pt_ok">
      <source>qtn_pt_ok</source>
      <translation variants="no">OK</translation>
    </message>
    <message numerus="no" id="qtn_pt_aboutpage_title">
      <source>qtn_pt_aboutpage_title</source>
      <translation variants="no">Tentang aplikasi ini</translation>
    </message>
    <message numerus="no" id="qtn_pt_ttdropdown_transportmode_0">
      <source>qtn_pt_ttdropdown_transportmode_0</source>
      <translation variants="no">Kereta api ekspres</translation>
    </message>
    <message numerus="no" id="qtn_pt_timepicker_pm">
      <source>qtn_pt_timepicker_pm</source>
      <translation variants="no">PM</translation>
    </message>
    <message numerus="no" id="qtn_pt_ttdropdown_transportmode_3">
      <source>qtn_pt_ttdropdown_transportmode_3</source>
      <translation variants="no">Kereta api regional</translation>
    </message>
    <message numerus="no" id="qtn_pt_cancel">
      <source>qtn_pt_cancel</source>
      <translation variants="no">Batalkan</translation>
    </message>
    <message numerus="no" id="qtn_pt_journeydetails_walkdistancetime">
      <source>qtn_pt_journeydetails_walkdistancetime</source>
      <translation variants="no">Berjalan selama %2 (%1)</translation>
    </message>
    <message numerus="no" id="qtn_pt_journeydetails_today">
      <source>qtn_pt_journeydetails_today</source>
      <translation variants="no">Hari ini</translation>
    </message>
    <message numerus="no" id="qtn_pt_routeplanner_from">
      <source>qtn_pt_routeplanner_from</source>
      <translation variants="no">Dari</translation>
    </message>
    <message numerus="no" id="qtn_pt_routeplanner_earlier_hold">
      <source>qtn_pt_routeplanner_earlier_hold</source>
      <translation variants="no">Tekan terus untuk melihat perjalanan sebelumnya</translation>
    </message>
    <message numerus="no" id="qtn_pt_value_with_unit">
      <source>qtn_pt_value_with_unit</source>
      <translation variants="no">%1 %2</translation>
    </message>
    <message numerus="no" id="qtn_pt_aboutpage_appdescription">
      <source>qtn_pt_aboutpage_appdescription</source>
      <translation variants="no">Navigasi transportasi umum</translation>
    </message>
    <message numerus="no" id="qtn_pt_stationdetails_blindguidinglines">
      <source>qtn_pt_stationdetails_blindguidinglines</source>
      <translation variants="no">Paving nyaman</translation>
    </message>
    <message numerus="no" id="qtn_pt_journeydetails_navigation_error">
      <source>qtn_pt_journeydetails_navigation_error</source>
      <translation variants="no">Tidak dapat membuka Peta. Silakan coba lagi.</translation>
    </message>
    <message numerus="no" id="qtn_pt_homepage_nextDepartures">
      <source>qtn_pt_homepage_nextDepartures</source>
      <translation variants="no">Perjalanan berikutnya dari sini ke</translation>
    </message>
    <message numerus="no" id="qtn_pt_splashscreen_welcome_to">
      <source>qtn_pt_splashscreen_welcome_to</source>
      <translation variants="no">Selamat datang di</translation>
    </message>
    <message numerus="no" id="qtn_pt_value_less_than_one">
      <source>qtn_pt_value_less_than_one</source>
      <translation variants="no">&lt; 1</translation>
    </message>
    <message numerus="no" id="qtn_pt_supportedRegions_title">
      <source>qtn_pt_supportedRegions_title</source>
      <translation variants="no">Info cakupan</translation>
    </message>
    <message numerus="no" id="qtn_pt_homepage_routeplanner">
      <source>qtn_pt_homepage_routeplanner</source>
      <translation variants="no">Perencana perjalanan</translation>
    </message>
    <message numerus="no" id="qtn_pt_feedback_positive">
      <source>qtn_pt_feedback_positive</source>
      <translation variants="no">Sangat mungkin</translation>
    </message>
    <message numerus="no" id="qtn_pt_homepage_update_notnow">
      <source>qtn_pt_homepage_update_notnow</source>
      <translation variants="no">Tidak skrg</translation>
    </message>
    <message numerus="no" id="qtn_pt_ttdropdown_transportmode_all">
      <source>qtn_pt_ttdropdown_transportmode_all</source>
      <translation variants="no">Semua jenis transportasi</translation>
    </message>
    <message numerus="no" id="qtn_pt_unit_minute">
      <source>qtn_pt_unit_minute</source>
      <translation variants="no">menit</translation>
    </message>
    <message numerus="no" id="qtn_pt_departures_station_title">
      <source>qtn_pt_departures_station_title</source>
      <translation variants="no">Berangkat yg diharapkan</translation>
    </message>
    <message numerus="no" id="qtn_pt_unit_hour">
      <source>qtn_pt_unit_hour</source>
      <translation variants="no">jam</translation>
    </message>
    <message numerus="no" id="qtn_pt_ttdropdown_transportmode_7">
      <source>qtn_pt_ttdropdown_transportmode_7</source>
      <translation variants="no">Bawah tanah</translation>
    </message>
    <message numerus="no" id="qtn_pt_error_area_not_supported">
      <source>qtn_pt_error_area_not_supported</source>
      <translation variants="no">Kami belum memiliki info transportasi untuk wilayah ini.</translation>
    </message>
    <message numerus="no" id="qtn_pt_homepage_update_mandatory_text">
      <source>qtn_pt_homepage_update_mandatory_text</source>
      <translation variants="no">Aplikasi ini harus segera diperbarui. Ketuk 'Perbarui' apabila Anda ingin melakukannya sekarang</translation>
    </message>
    <message numerus="no" id="qtn_pt_journeydetails_tomorrow">
      <source>qtn_pt_journeydetails_tomorrow</source>
      <translation variants="no">Besok</translation>
    </message>
    <message numerus="no" id="qtn_pt_ttdropdown_transportmode_9">
      <source>qtn_pt_ttdropdown_transportmode_9</source>
      <translation variants="no">Pesanan layanan</translation>
    </message>
    <message numerus="no" id="qtn_pt_ttdropdown_transportmode_5">
      <source>qtn_pt_ttdropdown_transportmode_5</source>
      <translation variants="no">Bus</translation>
    </message>
    <message numerus="no" id="qtn_pt_routeplanner_noconnections">
      <source>qtn_pt_routeplanner_noconnections</source>
      <translation variants="no">Tidak ditemukan perjalanan</translation>
    </message>
    <message numerus="no" id="qtn_pt_journeycalendaritem_minutes_ago">
      <source>qtn_pt_journeycalendaritem_minutes_ago</source>
      <translation variants="no">%1 menit yl</translation>
    </message>
    <message numerus="no" id="qtn_pt_homepage_update_update">
      <source>qtn_pt_homepage_update_update</source>
      <translation variants="no">Perbarui</translation>
    </message>
    <message numerus="no" id="qtn_pt_journeydetails_estimateridingtime">
      <source>qtn_pt_journeydetails_estimateridingtime</source>
      <translation variants="no">~%1 menggunakan</translation>
    </message>
    <message numerus="no" id="qtn_pt_loadingindicator_loading">
      <source>qtn_pt_loadingindicator_loading</source>
      <translation variants="no">Memuat</translation>
    </message>
    <message numerus="no" id="qtn_pt_routeplanner_nomoreconnections">
      <source>qtn_pt_routeplanner_nomoreconnections</source>
      <translation variants="no">Tada lagi prjalanan lainnya</translation>
    </message>
    <message numerus="no" id="qtn_pt_routingerror_retry">
      <source>qtn_pt_routingerror_retry</source>
      <translation variants="no">Coba lagi</translation>
    </message>
    <message numerus="no" id="qtn_pt_homepage_favoriteroutesupdated_title">
      <source>qtn_pt_homepage_favoriteroutesupdated_title</source>
      <translation variants="no">Fitur baru</translation>
    </message>
    <message numerus="no" id="qtn_pt_routeplanner_later_loading">
      <source>qtn_pt_routeplanner_later_loading</source>
      <translation variants="no">Mendapatkan perjalanan berikutnya</translation>
    </message>
    <message numerus="no" id="qtn_pt_editfavorite_showHomeScreen">
      <source>qtn_pt_editfavorite_showHomeScreen</source>
      <translation variants="no">Tampilkan perjalanan berikutnya saat start</translation>
    </message>
    <message numerus="no" id="qtn_pt_homepage_favoriteroutesupdated_text">
      <source>qtn_pt_homepage_favoriteroutesupdated_text</source>
      <translation variants="no">Sekarang Anda bisa menyimpan tujuan favorit dari perencana perjalanan dan langsung melihat perjalanan berikutnya. (Favorit yang telah ada akan diperbarui atau disimpan di riwayat pencarian.)</translation>
    </message>
    <message numerus="no" id="qtn_pt_departureitem_minutes">
      <source>qtn_pt_departureitem_minutes</source>
      <translation variants="no">%1mnt</translation>
    </message>
    <message numerus="no" id="qtn_pt_timepicker_in_15min">
      <source>qtn_pt_timepicker_in_15min</source>
      <translation variants="no">Dalam 15 menit</translation>
    </message>
    <message numerus="no" id="qtn_pt_routeplanner_gps_waiting">
      <source>qtn_pt_routeplanner_gps_waiting</source>
      <translation variants="no">Mendapatkan lokasi Anda</translation>
    </message>
    <message numerus="no" id="qtn_pt_autocompletion_currentposition_no_address">
      <source>qtn_pt_autocompletion_currentposition_no_address</source>
      <translation variants="no">Lokasi Anda</translation>
    </message>
    <message numerus="no" id="qtn_pt_error_network_release">
      <source>qtn_pt_error_network_release</source>
      <translation variants="no">Sepertinya sambungan Anda telah hilang. Periksalah dan coba lagi.</translation>
    </message>
    <message numerus="no" id="qtn_pt_journeydetails_from_location">
      <source>qtn_pt_journeydetails_from_location</source>
      <translation variants="no">Dari %1</translation>
    </message>
    <message numerus="no" id="qtn_pt_homepage_update_downloading">
      <source>qtn_pt_homepage_update_downloading</source>
      <translation variants="no">Mengunduh</translation>
    </message>
    <message numerus="no" id="qtn_pt_feedback_title">
      <source>qtn_pt_feedback_title</source>
      <translation variants="no">Masukan</translation>
    </message>
    <message numerus="no" id="qtn_pt_ttfilterpage_title">
      <source>qtn_pt_ttfilterpage_title</source>
      <translation variants="no">Pengaturan filter</translation>
    </message>
    <message numerus="no" id="qtn_pt_homepage_departures">
      <source>qtn_pt_homepage_departures</source>
      <translation variants="no">Transportasi di sekitar</translation>
    </message>
    <message numerus="no" id="qtn_pt_supportedRegions_header_withsimplerouting">
      <source>qtn_pt_supportedRegions_header_withsimplerouting</source>
      <translation variants="no">Tersedia jalur di %1 kota di seluruh dunia, demikian pula jadwal waktu untuk wilayah ini:</translation>
    </message>
    <message numerus="no" id="qtn_pt_unit_mile">
      <source>qtn_pt_unit_mile</source>
      <translation variants="no">mil</translation>
    </message>
    <message numerus="no" id="qtn_pt_feedback_error_no_rating">
      <source>qtn_pt_feedback_error_no_rating</source>
      <translation variants="no">Silakan pilih nilai</translation>
    </message>
    <message numerus="no" id="qtn_pt_routeplanner_later_drag">
      <source>qtn_pt_routeplanner_later_drag</source>
      <translation variants="no">Seret utk p'jalanan berikut</translation>
    </message>
    <message numerus="no" id="qtn_pt_timepicker_now">
      <source>qtn_pt_timepicker_now</source>
      <translation variants="no">Sekarang</translation>
    </message>
    <message numerus="no" id="qtn_pt_journeydetails_to_location">
      <source>qtn_pt_journeydetails_to_location</source>
      <translation variants="no">Ke %1</translation>
    </message>
    <message numerus="no" id="qtn_pt_aboutpage_feedback">
      <source>qtn_pt_aboutpage_feedback</source>
      <translation variants="no">Masukan</translation>
    </message>
    <message numerus="no" id="qtn_pt_aboutpage_acknowledgements_opensource_nokiapt_uses">
      <source>qtn_pt_aboutpage_acknowledgements_opensource_nokiapt_uses</source>
      <translation variants="no">%1 menggunakan Nokia Qt, aplikasi lintas platform dan kerangka UI, dan Zlib Compression Library, ditulis oleh Jean-Loup Gailly dan Mark Adler.</translation>
    </message>
    <message numerus="no" id="qtn_pt_departures_title">
      <source>qtn_pt_departures_title</source>
      <translation variants="no">Transportasi di sekitar</translation>
    </message>
    <message numerus="no" id="qtn_pt_supportedRegions_header_nosimplerouting">
      <source>qtn_pt_supportedRegions_header_nosimplerouting</source>
      <translation variants="no">Apabila tersedia jadwal waktu</translation>
    </message>
    <message numerus="no" id="qtn_pt_ttdropdown_transportmode_1">
      <source>qtn_pt_ttdropdown_transportmode_1</source>
      <translation variants="no">Kereta api antarkota</translation>
    </message>
    <message numerus="no" id="qtn_pt_stationdetails_barrierfree">
      <source>qtn_pt_stationdetails_barrierfree</source>
      <translation variants="no">Bebas banner</translation>
    </message>
    <message numerus="no" id="qtn_pt_aboutpage_acknowledgements_opensource">
      <source>qtn_pt_aboutpage_acknowledgements_opensource</source>
      <translation variants="no">Perangkat lunak sumber-terbuka</translation>
    </message>
    <message numerus="no" id="qtn_pt_unit_kilometer">
      <source>qtn_pt_unit_kilometer</source>
      <translation variants="no">km</translation>
    </message>
    <message numerus="no" id="qtn_pt_journey_no_warranty">
      <source>qtn_pt_journey_no_warranty</source>
      <translation variants="no">Semua informasi disediakan tanpa garansi dalam bentuk apa pun</translation>
    </message>
    <message numerus="no" id="qtn_pt_routingerror_showregions">
      <source>qtn_pt_routingerror_showregions</source>
      <translation variants="no">Tampilkan wilayah</translation>
    </message>
    <message numerus="no" id="qtn_pt_aboutpage_acknowledgements_source">
      <source>qtn_pt_aboutpage_acknowledgements_source</source>
      <translation variants="no">dengan dukungan dari</translation>
    </message>
    <message numerus="no" id="qtn_pt_homepage_update_updating_text">
      <source>qtn_pt_homepage_update_updating_text</source>
      <translation variants="no">Silakan tunggu saat aplikasi diperbarui. (Jangan khawatir, aplikasi akan menutup dan membuka kembali).</translation>
    </message>
    <message numerus="no" id="qtn_pt_editfavorite_namefield_label">
      <source>qtn_pt_editfavorite_namefield_label</source>
      <translation variants="no">Pilih nama</translation>
    </message>
    <message numerus="no" id="qtn_pt_aboutpage_supportedRegions">
      <source>qtn_pt_aboutpage_supportedRegions</source>
      <translation variants="no">Wilayah yang tercakup</translation>
    </message>
    <message numerus="no" id="qtn_pt_timepicker_departure">
      <source>qtn_pt_timepicker_departure</source>
      <translation variants="no">Berangkat</translation>
    </message>
    <message numerus="no" id="qtn_pt_timepicker_am">
      <source>qtn_pt_timepicker_am</source>
      <translation variants="no">AM</translation>
    </message>
    <message numerus="no" id="Application short caption">
      <source>Application short caption</source>
      <translation variants="no">Transportasi Umum</translation>
    </message>
    <message numerus="no" id="qtn_pt_journeydetails_month_day">
      <source>qtn_pt_journeydetails_month_day</source>
      <translation variants="no">d MMM</translation>
    </message>
    <message numerus="no" id="qtn_pt_autocompletion_retry_search">
      <source>qtn_pt_autocompletion_retry_search</source>
      <translation variants="no">Tidak menemukan hasil apa pun</translation>
    </message>
    <message numerus="no" id="qtn_pt_ttdropdown_transportmode_4">
      <source>qtn_pt_ttdropdown_transportmode_4</source>
      <translation variants="no">Kereta api pinggiran kota</translation>
    </message>
    <message numerus="no" id="qtn_pt_feedback_recommend_app">
      <source>qtn_pt_feedback_recommend_app</source>
      <translation variants="no">Seberapa besar kemungkinan Anda akan merekomendasikan %1 kepada teman dan rekan kerja?</translation>
    </message>
    <message numerus="no" id="qtn_pt_editfavorite_helpText">
      <source>qtn_pt_editfavorite_helpText</source>
      <translation variants="no">Dapatkan perjalanan yang cepat dan mudah ke tempat ini dari layar beranda %1.</translation>
    </message>
    <message numerus="no" id="qtn_pt_routeplanner_to">
      <source>qtn_pt_routeplanner_to</source>
      <translation variants="no">Ke</translation>
    </message>
    <message numerus="no" id="qtn_pt_journeydetails_title">
      <source>qtn_pt_journeydetails_title</source>
      <translation variants="no">Perjalanan %1/%2</translation>
    </message>
    <message numerus="no" id="qtn_pt_ttdropdown_transportmode_6">
      <source>qtn_pt_ttdropdown_transportmode_6</source>
      <translation variants="no">Feri</translation>
    </message>
    <message numerus="no" id="qtn_pt_editfavorite_title">
      <source>qtn_pt_editfavorite_title</source>
      <translation variants="no">Favorit</translation>
    </message>
    <message numerus="no" id="qtn_pt_stationdetails_elevators">
      <source>qtn_pt_stationdetails_elevators</source>
      <translation variants="no">Lift</translation>
    </message>
    <message numerus="no" id="qtn_pt_ttfilterpage_select_transport">
      <source>qtn_pt_ttfilterpage_select_transport</source>
      <translation variants="no">Pilih jenis transportasi yang Anda sukai</translation>
    </message>
    <message numerus="no" id="qtn_pt_editfavorite_caption">
      <source>qtn_pt_editfavorite_caption</source>
      <translation variants="no">Simpan tujuan favorit</translation>
    </message>
    <message numerus="no" id="qtn_pt_favoritedestinationitem_unavailable">
      <source>qtn_pt_favoritedestinationitem_unavailable</source>
      <translation variants="no">Tidak dapat menampilkan perjalanan apa pun</translation>
    </message>
    <message numerus="no" id="qtn_pt_unit_meter">
      <source>qtn_pt_unit_meter</source>
      <translation variants="no">m</translation>
    </message>
    <message numerus="no" id="qtn_pt_journeydetails_navigation_text">
      <source>qtn_pt_journeydetails_navigation_text</source>
      <translation variants="no">Tunggu sebentar, Peta akan segera dibuka</translation>
    </message>
    <message numerus="no" id="qtn_pt_journeycalendaritem_in_minutes">
      <source>qtn_pt_journeycalendaritem_in_minutes</source>
      <translation variants="no">dalam %1 menit</translation>
    </message>
    <message numerus="no" id="qtn_pt_homepage_update_cancel">
      <source>qtn_pt_homepage_update_cancel</source>
      <translation variants="no">Batalkan</translation>
    </message>
    <message numerus="no" id="qtn_pt_homepage_update_low_text">
      <source>qtn_pt_homepage_update_low_text</source>
      <translation variants="no">Ada pembaruan untuk aplikasi ini. Ketuk 'Perbarui' untuk menginstalnya sekarang atau 'Tidak sekarang' untuk melewatinya.</translation>
    </message>
    <message numerus="no" id="qtn_pt_editfavorite_create">
      <source>qtn_pt_editfavorite_create</source>
      <translation variants="no">Simpan</translation>
    </message>
    <message numerus="no" id="qtn_pt_feedback_negative">
      <source>qtn_pt_feedback_negative</source>
      <translation variants="no">Sm sekali tak mgkn</translation>
    </message>
    <message numerus="no" id="qtn_pt_departures_header_label">
      <source>qtn_pt_departures_header_label</source>
      <translation variants="no">Cari transportasi di dekat</translation>
    </message>
    <message numerus="no" id="qtn_pt_timepicker_arrival">
      <source>qtn_pt_timepicker_arrival</source>
      <translation variants="no">Tiba</translation>
    </message>
    <message numerus="no" id="qtn_pt_aboutpage_buildnumber">
      <source>qtn_pt_aboutpage_buildnumber</source>
      <translation variants="no">Pembuatan %1</translation>
    </message>
    <message numerus="no" id="qtn_pt_journeydetails_platform">
      <source>qtn_pt_journeydetails_platform</source>
      <translation variants="no">Platform %1</translation>
    </message>
    <message numerus="no" id="qtn_pt_routeplanner_earlier_drag">
      <source>qtn_pt_routeplanner_earlier_drag</source>
      <translation variants="no">Seret utk p'jalanan sblmnya</translation>
    </message>
    <message numerus="no" id="qtn_pt_routeplanner_later_hold">
      <source>qtn_pt_routeplanner_later_hold</source>
      <translation variants="no">Tekan terus untuk mendapatkan perjalanan berikutnya</translation>
    </message>
    <message numerus="no" id="qtn_pt_routeplanner_simpleroutinghint">
      <source>qtn_pt_routeplanner_simpleroutinghint</source>
      <translation variants="no">Tidak dapat menyediakan jadwal yang tepat untuk perjalanan ini.</translation>
    </message>
    <message numerus="no" id="qtn_pt_feedback_send_error">
      <source>qtn_pt_feedback_send_error</source>
      <translation variants="no">Tidak dapat mengirim masukan</translation>
    </message>
    <message numerus="no" id="qtn_pt_error_places">
      <source>qtn_pt_error_places</source>
      <translation variants="no">Tidak dapat menemukan hasil apa pun.</translation>
    </message>
    <message numerus="no" id="qtn_pt_ttdropdown_transportmode_8">
      <source>qtn_pt_ttdropdown_transportmode_8</source>
      <translation variants="no">Tram</translation>
    </message>
    <message numerus="no" id="qtn_pt_routeplanner_earlier_loading">
      <source>qtn_pt_routeplanner_earlier_loading</source>
      <translation variants="no">Mendapatkan perjalanan sebelumnya</translation>
    </message>
    <message numerus="no" id="qtn_pt_homepage_update_exit">
      <source>qtn_pt_homepage_update_exit</source>
      <translation variants="no">Tutup</translation>
    </message>
    <message numerus="no" id="qtn_pt_estimate_time">
      <source>qtn_pt_estimate_time</source>
      <translation variants="no">~%1</translation>
    </message>
    <message numerus="no" id="qtn_pt_stationdetails_bicyclesallowed">
      <source>qtn_pt_stationdetails_bicyclesallowed</source>
      <translation variants="no">Boleh membawa sepeda</translation>
    </message>
    <message numerus="no" id="qtn_pt_departurenearbystations_nodepartures">
      <source>qtn_pt_departurenearbystations_nodepartures</source>
      <translation variants="no">Tiada brkt 1 jm</translation>
    </message>
    <message numerus="no" id="qtn_pt_homepage_update_timeleft">
      <source>qtn_pt_homepage_update_timeleft</source>
      <translation variants="no">%1 tersisa</translation>
    </message>
    <message numerus="no" id="qtn_pt_ttdropdown_transportmode_2">
      <source>qtn_pt_ttdropdown_transportmode_2</source>
      <translation variants="no">Kereta api cepat</translation>
    </message>
    <message numerus="no" id="qtn_pt_feedback_submit">
      <source>qtn_pt_feedback_submit</source>
      <translation variants="no">Kirim</translation>
    </message>
    <message numerus="no" id="qtn_pt_app_error">
      <source>qtn_pt_app_error</source>
      <translation variants="no">Ada yang salah</translation>
    </message>
    <message numerus="no" id="qtn_pt_favoritedestinationitem_alreadythere">
      <source>qtn_pt_favoritedestinationitem_alreadythere</source>
      <translation variants="no">Anda sekarang di sini</translation>
    </message>
    <message numerus="no" id="qtn_pt_error_hafas_stations">
      <source>qtn_pt_error_hafas_stations</source>
      <translation variants="no">Tidak dapat menemukan hasil apa pun..
%1</translation>
    </message>
    <message numerus="no" id="qtn_pt_autocompletion_start_searching">
      <source>qtn_pt_autocompletion_start_searching</source>
      <translation variants="no">Sedang mencari</translation>
    </message>
    <message numerus="no" id="qtn_pt_autocompletion_currentposition_with_address">
      <source>qtn_pt_autocompletion_currentposition_with_address</source>
      <translation variants="no">Di sini, %1</translation>
    </message>
    <message numerus="no" id="qtn_pt_unit_foot">
      <source>qtn_pt_unit_foot</source>
      <translation variants="no">kaki</translation>
    </message>
    <message numerus="no" id="qtn_pt_aboutpage_termsconditions">
      <source>qtn_pt_aboutpage_termsconditions</source>
      <translation variants="no">Persyaratan layanan</translation>
    </message>
    <message numerus="no" id="qtn_pt_departureitem_loading">
      <source>qtn_pt_departureitem_loading</source>
      <translation variants="no">memuat</translation>
    </message>
    <message numerus="no" id="qtn_pt_timepicker_in_60min">
      <source>qtn_pt_timepicker_in_60min</source>
      <translation variants="no">Dalam 60 menit</translation>
    </message>
    <message numerus="no" id="qtn_pt_error_hafas_connections">
      <source>qtn_pt_error_hafas_connections</source>
      <translation variants="no">Tidak dapat menemukan perjalanan apa pun.</translation>
    </message>
    <message numerus="no" id="qtn_pt_routeplanner_title">
      <source>qtn_pt_routeplanner_title</source>
      <translation variants="no">Perencana perjalanan</translation>
    </message>
    <message numerus="no" id="qtn_pt_stationdetails_escalators">
      <source>qtn_pt_stationdetails_escalators</source>
      <translation variants="no">Eskalator</translation>
    </message>
    <message numerus="no" id="qtn_pt_aboutpage_noteofthanks">
      <source>qtn_pt_aboutpage_noteofthanks</source>
      <translation variants="no">Catatan terima kasih</translation>
    </message>
    <message numerus="no" id="qtn_pt_timepicker_title">
      <source>qtn_pt_timepicker_title</source>
      <translation variants="no">Opsi perjalanan</translation>
    </message>
    <message numerus="no" id="qtn_pt_termsandconditions">
      <source>qtn_pt_termsandconditions</source>
      <translation variants="no">&lt;p&gt;Menggunakan layanan atau mengunduh konten mungkin memerlukan transmisi data dalam jumlah besar melalui jaringan penyedia layanan Anda.
Semua layanan mungkin tidak tersedia atau tidak akan selalu akurat sepanjang waktu. Saat menggunakan aplikasi ini di lalu lintas, pertimbangan pertama Anda adalah keselamatan.
Penggunaan layanan dapat melibatkan pengiriman informasi lokasi.
Kami mungkin akan mengumpulkan informasi tentang telepon Anda dan cara penggunaan layanan untuk menyempurnakan produk-produk Nokia, dan untuk menyediakan konten yang lebih relevan bagi Anda.
Kami tidak akan berbagi data dengan pihak ketiga tanpa meminta izin dari Anda terlebih dahulu.
Untuk informasi selengkapnya tentang privasi, klik [di sini|%1].

Dengan memilih 'mulai', berarti Anda mengkonfirmasi bahwa Anda telah membaca dan menyetujui [Syarat Layanan Nokia|%2] dan [Kebijakan Privasi|%3].&lt;/p&gt;</translation>
    </message>
    <message numerus="no" id="qtn_pt_coverage_button_skip">
      <source>qtn_pt_coverage_button_skip</source>
      <translation variants="no">Abaikan Deteksi</translation>
    </message>
    <message numerus="no" id="qtn_pt_coverage_button_showcoveredregions">
      <source>qtn_pt_coverage_button_showcoveredregions</source>
      <translation variants="no">Wilayah yang tercakup</translation>
    </message>
    <message numerus="no" id="qtn_pt_coverage_position_nocoverage">
      <source>qtn_pt_coverage_position_nocoverage</source>
      <translation variants="no">&lt;p&gt;Kami tidak memiliki info untuk %1 saat ini.
&lt;/p&gt;
&lt;p&gt;Namun kami menambahkan nama kota baru setiap hari, jadi tetaplah bersama kami.&lt;/p&gt;</translation>
    </message>
    <message numerus="no" id="qtn_pt_coverage_title_nocoverage">
      <source>qtn_pt_coverage_title_nocoverage</source>
      <translation variants="no">Kami mohon maaf</translation>
    </message>
    <message numerus="no" id="qtn_pt_coverage_position_timetablecoverage">
      <source>qtn_pt_coverage_position_timetablecoverage</source>
      <translation variants="no">&lt;p&gt;
Sepertinya Anda ada di &lt;b&gt;%1&lt;/b&gt;.
&lt;/p&gt;
&lt;p&gt;
Kami menyediakan %2. &lt;br&gt;Kami telah mencakup kota ini dan banyak kota lainnya.
&lt;/p&gt;</translation>
    </message>
    <message numerus="no" id="qtn_pt_firsttimeuse_welcome">
      <source>qtn_pt_firsttimeuse_welcome</source>
      <translation variants="no">Selamat Datang</translation>
    </message>
    <message numerus="no" id="qtn_pt_coverage_button_continue">
      <source>qtn_pt_coverage_button_continue</source>
      <translation variants="no">Lanjutkan</translation>
    </message>
    <message numerus="no" id="qtn_pt_coverage_button_retry">
      <source>qtn_pt_coverage_button_retry</source>
      <translation variants="no">Coba lagi</translation>
    </message>
    <message numerus="no" id="qtn_pt_coverage_position_noposition">
      <source>qtn_pt_coverage_position_noposition</source>
      <translation variants="no">Tidak dapat menemukan lokasi Anda sekarang. Silakan periksa daftar cakupan untuk memastikan aplikasi bekerja di wilayah ini.</translation>
    </message>
    <message numerus="no" id="qtn_pt_start">
      <source>qtn_pt_start</source>
      <translation variants="no">Mulai</translation>
    </message>
    <message numerus="no" id="qtn_pt_nothanks">
      <source>qtn_pt_nothanks</source>
      <translation variants="no">Tdk, trims</translation>
    </message>
    <message numerus="no" id="qtn_pt_stationdetails_title">
      <source>qtn_pt_stationdetails_title</source>
      <translation variants="no">Info perhentian/stasiun</translation>
    </message>
    <message numerus="no" id="qtn_pt_journeydetails_walk_title">
      <source>qtn_pt_journeydetails_walk_title</source>
      <translation variants="no">Panduan jalan kaki</translation>
    </message>
    <message numerus="no" id="qtn_pt_journeydetails_show_on_map_title">
      <source>qtn_pt_journeydetails_show_on_map_title</source>
      <translation variants="no">Tampilkan di peta</translation>
    </message>
    <message numerus="no" id="qtn_pt_journeydetails_show_on_map_text">
      <source>qtn_pt_journeydetails_show_on_map_text</source>
      <translation variants="no">Siap menampilkan &lt;b&gt;%1&lt;/b&gt; di Peta Nokia.</translation>
    </message>
    <message numerus="no" id="qtn_pt_journeydetails_show">
      <source>qtn_pt_journeydetails_show</source>
      <translation variants="no">Petakan</translation>
    </message>
    <message numerus="no" id="qtn_pt_journeydetails_go">
      <source>qtn_pt_journeydetails_go</source>
      <translation variants="no">Ayo</translation>
    </message>
    <message numerus="no" id="qtn_pt_linedetails_title">
      <source>qtn_pt_linedetails_title</source>
      <translation variants="no">Info rute</translation>
    </message>
    <message numerus="no" id="qtn_pt_linedetails_on_time">
      <source>qtn_pt_linedetails_on_time</source>
      <translation variants="no">tepat waktu</translation>
    </message>
    <message numerus="no" id="qtn_pt_linedetails_late">
      <source>qtn_pt_linedetails_late</source>
      <translation variants="no">%1 menit terlambat</translation>
    </message>
    <message numerus="no" id="qtn_pt_journeydetails_walk_text">
      <source>qtn_pt_journeydetails_walk_text</source>
      <translation variants="no">Siap memulai navigasi berjalan ke &lt;b&gt;%1&lt;/b&gt; di Peta Nokia.</translation>
    </message>
    <message numerus="no" id="qtn_pt_feedback_contact">
      <source>qtn_pt_feedback_contact</source>
      <translation variants="no">Hubungi saya untuk info selengkapnya (opsional)</translation>
    </message>
    <message numerus="no" id="qtn_pt_feedback_contact_placeholder">
      <source>qtn_pt_feedback_contact_placeholder</source>
      <translation variants="no">Alamat email</translation>
    </message>
    <message numerus="no" id="qtn_pt_feedback_privacy">
      <source>qtn_pt_feedback_privacy</source>
      <translation variants="no">Informasi Anda akan dikaitkan dengan perangkat Anda dan diperlakukan menurut [Kebijakan Privasi Nokia|%1]</translation>
    </message>
    <message numerus="no" id="qtn_pt_feedback_text_placeholder">
      <source>qtn_pt_feedback_text_placeholder</source>
      <translation variants="no">Komentar Anda</translation>
    </message>
    <message numerus="no" id="qtn_pt_privacy">
      <source>qtn_pt_privacy</source>
      <translation variants="no">&lt;p&gt;
Nokia menghargai privasi Anda.
Kami mungkin akan mengumpulkan informasi tentang telepon Anda dan cara penggunaan layanan untuk menyempurnakan produk-produk Nokia, dan untuk menyediakan konten yang lebih relevan bagi Anda..

Kami tidak akan berbagi data dengan pihak ketiga tanpa meminta izin dari Anda terlebih dahulu.

[Kebijakan Privasi|%1]

[Privasi Anda di %2|%3]
&lt;/p&gt;</translation>
    </message>
    <message numerus="no" id="qtn_pt_aboutpage_support">
      <source>qtn_pt_aboutpage_support</source>
      <translation variants="no">Dukungan</translation>
    </message>
    <message numerus="no" id="Application long caption">
      <source>Application long caption</source>
      <translation variants="no">Transportasi Umum</translation>
    </message>
    <message numerus="no" id="qtn_pt_error_noresults">
      <source>qtn_pt_error_noresults</source>
      <translation variants="no">Tidak tersedia rute lengkap.</translation>
    </message>
    <message numerus="no" id="qtn_pt_privacy_title">
      <source>qtn_pt_privacy_title</source>
      <translation variants="no">Privasi</translation>
    </message>
    <message numerus="no" id="qtn_pt_routeplanner_input_watermark">
      <source>qtn_pt_routeplanner_input_watermark</source>
      <translation variants="no">Cari untuk perhentian atau tempat</translation>
    </message>
    <message numerus="no" id="qtn_pt_location_no_info">
      <source>qtn_pt_location_no_info</source>
      <translation variants="no">Lokasi pilihan Anda</translation>
    </message>
    <message numerus="no" id="qtn_pt_location_taiwan">
      <source>qtn_pt_location_taiwan</source>
      <translation variants="no">Taiwan</translation>
    </message>
    <message numerus="no" id="qtn_pt_location_taiwan_area">
      <source>qtn_pt_location_taiwan_area</source>
      <translation variants="no">Wilayah Taiwan</translation>
    </message>
    <message numerus="no" id="Package name">
      <source>Package name</source>
      <translation variants="no">Transportasi Umum</translation>
    </message>
    <message numerus="no" id="Smart installer package name">
      <source>Smart installer package name</source>
      <translation variants="no">Transportasi Umum</translation>
    </message>
    <message numerus="no" id="qtn_pt_coverage_thanksforinstalling">
      <source>qtn_pt_coverage_thanksforinstalling</source>
      <translation variants="no">Terima kasih Anda telah menginstal %1. &lt;br&gt;Kami memiliki info rute terjadwal di %2 kota di seluruh dunia.</translation>
    </message>
  </context>
</TS>
