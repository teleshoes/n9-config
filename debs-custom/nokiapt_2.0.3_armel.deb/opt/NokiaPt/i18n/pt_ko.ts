<?xml version="1.0" encoding="utf-8"?>
<TS version="1.0" sourcelanguage="en" language="ko">
  <context>
    <name>Maps</name>
    <message numerus="no" id="qtn_pt_feedback_text">
      <source>qtn_pt_feedback_text</source>
      <translation variants="no">이 점수를 매긴 이유는 무엇입니까?</translation>
    </message>
    <message numerus="no" id="qtn_pt_ok">
      <source>qtn_pt_ok</source>
      <translation variants="no">확인</translation>
    </message>
    <message numerus="no" id="qtn_pt_aboutpage_title">
      <source>qtn_pt_aboutpage_title</source>
      <translation variants="no">해당 앱 관련 정보</translation>
    </message>
    <message numerus="no" id="qtn_pt_ttdropdown_transportmode_0">
      <source>qtn_pt_ttdropdown_transportmode_0</source>
      <translation variants="no">급행 열차</translation>
    </message>
    <message numerus="no" id="qtn_pt_timepicker_pm">
      <source>qtn_pt_timepicker_pm</source>
      <translation variants="no">오후</translation>
    </message>
    <message numerus="no" id="qtn_pt_ttdropdown_transportmode_3">
      <source>qtn_pt_ttdropdown_transportmode_3</source>
      <translation variants="no">지역 기차</translation>
    </message>
    <message numerus="no" id="qtn_pt_cancel">
      <source>qtn_pt_cancel</source>
      <translation variants="no">취소</translation>
    </message>
    <message numerus="no" id="qtn_pt_journeydetails_walkdistancetime">
      <source>qtn_pt_journeydetails_walkdistancetime</source>
      <translation variants="no">%2 동안 도보로 이동(%1)</translation>
    </message>
    <message numerus="no" id="qtn_pt_journeydetails_today">
      <source>qtn_pt_journeydetails_today</source>
      <translation variants="no">오늘</translation>
    </message>
    <message numerus="no" id="qtn_pt_routeplanner_from">
      <source>qtn_pt_routeplanner_from</source>
      <translation variants="no">출발</translation>
    </message>
    <message numerus="no" id="qtn_pt_routeplanner_earlier_hold">
      <source>qtn_pt_routeplanner_earlier_hold</source>
      <translation variants="no">이전 여정을 살펴보시려면 누르십시오.</translation>
    </message>
    <message numerus="no" id="qtn_pt_value_with_unit">
      <source>qtn_pt_value_with_unit</source>
      <translation variants="no">%1 %2</translation>
    </message>
    <message numerus="no" id="qtn_pt_aboutpage_appdescription">
      <source>qtn_pt_aboutpage_appdescription</source>
      <translation variants="no">대중교통 안내</translation>
    </message>
    <message numerus="no" id="qtn_pt_stationdetails_blindguidinglines">
      <source>qtn_pt_stationdetails_blindguidinglines</source>
      <translation variants="no">점자 블럭</translation>
    </message>
    <message numerus="no" id="qtn_pt_journeydetails_navigation_error">
      <source>qtn_pt_journeydetails_navigation_error</source>
      <translation variants="no">지도를 열 수 없습니다. 다시 시도하십시오.</translation>
    </message>
    <message numerus="no" id="qtn_pt_homepage_nextDepartures">
      <source>qtn_pt_homepage_nextDepartures</source>
      <translation variants="no">이 곳에서부터 다음 여정</translation>
    </message>
    <message numerus="no" id="qtn_pt_splashscreen_welcome_to">
      <source>qtn_pt_splashscreen_welcome_to</source>
      <translation variants="no">환영합니다</translation>
    </message>
    <message numerus="no" id="qtn_pt_value_less_than_one">
      <source>qtn_pt_value_less_than_one</source>
      <translation variants="no">&lt; 1</translation>
    </message>
    <message numerus="no" id="qtn_pt_supportedRegions_title">
      <source>qtn_pt_supportedRegions_title</source>
      <translation variants="no">적용 범위 정보</translation>
    </message>
    <message numerus="no" id="qtn_pt_homepage_routeplanner">
      <source>qtn_pt_homepage_routeplanner</source>
      <translation variants="no">여정 플래너</translation>
    </message>
    <message numerus="no" id="qtn_pt_feedback_positive">
      <source>qtn_pt_feedback_positive</source>
      <translation variants="no">매우 적극 추천</translation>
    </message>
    <message numerus="no" id="qtn_pt_homepage_update_notnow">
      <source>qtn_pt_homepage_update_notnow</source>
      <translation variants="no">나중에</translation>
    </message>
    <message numerus="no" id="qtn_pt_ttdropdown_transportmode_all">
      <source>qtn_pt_ttdropdown_transportmode_all</source>
      <translation variants="no">모든 교통 수단 모드</translation>
    </message>
    <message numerus="no" id="qtn_pt_unit_minute">
      <source>qtn_pt_unit_minute</source>
      <translation variants="no">분</translation>
    </message>
    <message numerus="no" id="qtn_pt_departures_station_title">
      <source>qtn_pt_departures_station_title</source>
      <translation variants="no">예상 출발</translation>
    </message>
    <message numerus="no" id="qtn_pt_unit_hour">
      <source>qtn_pt_unit_hour</source>
      <translation variants="no">시간</translation>
    </message>
    <message numerus="no" id="qtn_pt_ttdropdown_transportmode_7">
      <source>qtn_pt_ttdropdown_transportmode_7</source>
      <translation variants="no">지하철</translation>
    </message>
    <message numerus="no" id="qtn_pt_error_area_not_supported">
      <source>qtn_pt_error_area_not_supported</source>
      <translation variants="no">현재 이 지역에 대한 교통 수단 정보를 제공하지 않습니다.</translation>
    </message>
    <message numerus="no" id="qtn_pt_homepage_update_mandatory_text">
      <source>qtn_pt_homepage_update_mandatory_text</source>
      <translation variants="no">이 앱을 곧 업데이트해야 합니다. 지금 업데이트하려면 '업데이트'를 누르십시오.</translation>
    </message>
    <message numerus="no" id="qtn_pt_journeydetails_tomorrow">
      <source>qtn_pt_journeydetails_tomorrow</source>
      <translation variants="no">내일</translation>
    </message>
    <message numerus="no" id="qtn_pt_ttdropdown_transportmode_9">
      <source>qtn_pt_ttdropdown_transportmode_9</source>
      <translation variants="no">주문한 서비스</translation>
    </message>
    <message numerus="no" id="qtn_pt_ttdropdown_transportmode_5">
      <source>qtn_pt_ttdropdown_transportmode_5</source>
      <translation variants="no">버스</translation>
    </message>
    <message numerus="no" id="qtn_pt_routeplanner_noconnections">
      <source>qtn_pt_routeplanner_noconnections</source>
      <translation variants="no">여정을 찾을 수 없음</translation>
    </message>
    <message numerus="no" id="qtn_pt_journeycalendaritem_minutes_ago">
      <source>qtn_pt_journeycalendaritem_minutes_ago</source>
      <translation variants="no">%1분 전</translation>
    </message>
    <message numerus="no" id="qtn_pt_homepage_update_update">
      <source>qtn_pt_homepage_update_update</source>
      <translation variants="no">업데이트</translation>
    </message>
    <message numerus="no" id="qtn_pt_journeydetails_estimateridingtime">
      <source>qtn_pt_journeydetails_estimateridingtime</source>
      <translation variants="no">~%1 사용 중</translation>
    </message>
    <message numerus="no" id="qtn_pt_loadingindicator_loading">
      <source>qtn_pt_loadingindicator_loading</source>
      <translation variants="no">로드 중</translation>
    </message>
    <message numerus="no" id="qtn_pt_routeplanner_nomoreconnections">
      <source>qtn_pt_routeplanner_nomoreconnections</source>
      <translation variants="no">추가 여정을 찾을 수 없음</translation>
    </message>
    <message numerus="no" id="qtn_pt_routingerror_retry">
      <source>qtn_pt_routingerror_retry</source>
      <translation variants="no">재시도</translation>
    </message>
    <message numerus="no" id="qtn_pt_homepage_favoriteroutesupdated_title">
      <source>qtn_pt_homepage_favoriteroutesupdated_title</source>
      <translation variants="no">새 기능</translation>
    </message>
    <message numerus="no" id="qtn_pt_routeplanner_later_loading">
      <source>qtn_pt_routeplanner_later_loading</source>
      <translation variants="no">이후 여정 살펴보기</translation>
    </message>
    <message numerus="no" id="qtn_pt_editfavorite_showHomeScreen">
      <source>qtn_pt_editfavorite_showHomeScreen</source>
      <translation variants="no">시작 시 다음 여정 표시</translation>
    </message>
    <message numerus="no" id="qtn_pt_homepage_favoriteroutesupdated_text">
      <source>qtn_pt_homepage_favoriteroutesupdated_text</source>
      <translation variants="no">이제 여정 플래너에서 즐겨 이용하는 목적지를 저장하고 다음 번 여정에서 바로 확인할 수 있습니다. (기존의 즐겨찾기가 업데이트되거나 검색 기록에 저장됩니다.)</translation>
    </message>
    <message numerus="no" id="qtn_pt_departureitem_minutes">
      <source>qtn_pt_departureitem_minutes</source>
      <translation variants="no">%1분</translation>
    </message>
    <message numerus="no" id="qtn_pt_timepicker_in_15min">
      <source>qtn_pt_timepicker_in_15min</source>
      <translation variants="no">15분 후</translation>
    </message>
    <message numerus="no" id="qtn_pt_routeplanner_gps_waiting">
      <source>qtn_pt_routeplanner_gps_waiting</source>
      <translation variants="no">위치 가져오기</translation>
    </message>
    <message numerus="no" id="qtn_pt_autocompletion_currentposition_no_address">
      <source>qtn_pt_autocompletion_currentposition_no_address</source>
      <translation variants="no">현재 위치</translation>
    </message>
    <message numerus="no" id="qtn_pt_error_network_release">
      <source>qtn_pt_error_network_release</source>
      <translation variants="no">연결이 끊긴 것 같습니다. 연결을 확인하고 다시 시도하십시오.</translation>
    </message>
    <message numerus="no" id="qtn_pt_journeydetails_from_location">
      <source>qtn_pt_journeydetails_from_location</source>
      <translation variants="no">%1에서 출발</translation>
    </message>
    <message numerus="no" id="qtn_pt_homepage_update_downloading">
      <source>qtn_pt_homepage_update_downloading</source>
      <translation variants="no">다운로드 중</translation>
    </message>
    <message numerus="no" id="qtn_pt_feedback_title">
      <source>qtn_pt_feedback_title</source>
      <translation variants="no">피드백</translation>
    </message>
    <message numerus="no" id="qtn_pt_ttfilterpage_title">
      <source>qtn_pt_ttfilterpage_title</source>
      <translation variants="no">필터 설정</translation>
    </message>
    <message numerus="no" id="qtn_pt_homepage_departures">
      <source>qtn_pt_homepage_departures</source>
      <translation variants="no">인근 교통 수단</translation>
    </message>
    <message numerus="no" id="qtn_pt_supportedRegions_header_withsimplerouting">
      <source>qtn_pt_supportedRegions_header_withsimplerouting</source>
      <translation variants="no">해당 지역의 시간표에 따라 전세계 %1개 도시에서 회선을 이용할 수 있습니다:</translation>
    </message>
    <message numerus="no" id="qtn_pt_unit_mile">
      <source>qtn_pt_unit_mile</source>
      <translation variants="no">마일</translation>
    </message>
    <message numerus="no" id="qtn_pt_feedback_error_no_rating">
      <source>qtn_pt_feedback_error_no_rating</source>
      <translation variants="no">등급을 선택하십시오.</translation>
    </message>
    <message numerus="no" id="qtn_pt_routeplanner_later_drag">
      <source>qtn_pt_routeplanner_later_drag</source>
      <translation variants="no">이후 여정을 살펴보시려면 드래그하십시오.</translation>
    </message>
    <message numerus="no" id="qtn_pt_timepicker_now">
      <source>qtn_pt_timepicker_now</source>
      <translation variants="no">지금</translation>
    </message>
    <message numerus="no" id="qtn_pt_journeydetails_to_location">
      <source>qtn_pt_journeydetails_to_location</source>
      <translation variants="no">%1에 도착</translation>
    </message>
    <message numerus="no" id="qtn_pt_aboutpage_feedback">
      <source>qtn_pt_aboutpage_feedback</source>
      <translation variants="no">피드백</translation>
    </message>
    <message numerus="no" id="qtn_pt_aboutpage_acknowledgements_opensource_nokiapt_uses">
      <source>qtn_pt_aboutpage_acknowledgements_opensource_nokiapt_uses</source>
      <translation variants="no">%1은(는) Nokia Qt, 교차 플랫폼 애플리케이션 및 UI 프레임워크, Jean-Loup Gailly와 Mark Adler가 작성한 Zlib 압축 라이브러리를 사용합니다.</translation>
    </message>
    <message numerus="no" id="qtn_pt_departures_title">
      <source>qtn_pt_departures_title</source>
      <translation variants="no">인근 교통 수단</translation>
    </message>
    <message numerus="no" id="qtn_pt_supportedRegions_header_nosimplerouting">
      <source>qtn_pt_supportedRegions_header_nosimplerouting</source>
      <translation variants="no">시간표 이용 가능 지역</translation>
    </message>
    <message numerus="no" id="qtn_pt_ttdropdown_transportmode_1">
      <source>qtn_pt_ttdropdown_transportmode_1</source>
      <translation variants="no">도시 간 기차</translation>
    </message>
    <message numerus="no" id="qtn_pt_stationdetails_barrierfree">
      <source>qtn_pt_stationdetails_barrierfree</source>
      <translation variants="no">장애물 없는 시설</translation>
    </message>
    <message numerus="no" id="qtn_pt_aboutpage_acknowledgements_opensource">
      <source>qtn_pt_aboutpage_acknowledgements_opensource</source>
      <translation variants="no">오픈 소스 소프트웨어</translation>
    </message>
    <message numerus="no" id="qtn_pt_unit_kilometer">
      <source>qtn_pt_unit_kilometer</source>
      <translation variants="no">킬로미터</translation>
    </message>
    <message numerus="no" id="qtn_pt_journey_no_warranty">
      <source>qtn_pt_journey_no_warranty</source>
      <translation variants="no">모든 정보는 보증서가 생략된 채 제공됩니다.</translation>
    </message>
    <message numerus="no" id="qtn_pt_routingerror_showregions">
      <source>qtn_pt_routingerror_showregions</source>
      <translation variants="no">지역 표시</translation>
    </message>
    <message numerus="no" id="qtn_pt_aboutpage_acknowledgements_source">
      <source>qtn_pt_aboutpage_acknowledgements_source</source>
      <translation variants="no">지원</translation>
    </message>
    <message numerus="no" id="qtn_pt_homepage_update_updating_text">
      <source>qtn_pt_homepage_update_updating_text</source>
      <translation variants="no">앱을 업데이트하는 동안 기다리십시오(앱이 닫혔다 다시 열립니다).</translation>
    </message>
    <message numerus="no" id="qtn_pt_editfavorite_namefield_label">
      <source>qtn_pt_editfavorite_namefield_label</source>
      <translation variants="no">이름 선택</translation>
    </message>
    <message numerus="no" id="qtn_pt_aboutpage_supportedRegions">
      <source>qtn_pt_aboutpage_supportedRegions</source>
      <translation variants="no">적용되는 지역</translation>
    </message>
    <message numerus="no" id="qtn_pt_timepicker_departure">
      <source>qtn_pt_timepicker_departure</source>
      <translation variants="no">출발</translation>
    </message>
    <message numerus="no" id="qtn_pt_timepicker_am">
      <source>qtn_pt_timepicker_am</source>
      <translation variants="no">오전</translation>
    </message>
    <message numerus="no" id="Application short caption">
      <source>Application short caption</source>
      <translation variants="no">대중교통</translation>
    </message>
    <message numerus="no" id="qtn_pt_journeydetails_month_day">
      <source>qtn_pt_journeydetails_month_day</source>
      <translation variants="no">d MMM</translation>
    </message>
    <message numerus="no" id="qtn_pt_autocompletion_retry_search">
      <source>qtn_pt_autocompletion_retry_search</source>
      <translation variants="no">결과를 찾을 수 없음</translation>
    </message>
    <message numerus="no" id="qtn_pt_ttdropdown_transportmode_4">
      <source>qtn_pt_ttdropdown_transportmode_4</source>
      <translation variants="no">교외 기차</translation>
    </message>
    <message numerus="no" id="qtn_pt_feedback_recommend_app">
      <source>qtn_pt_feedback_recommend_app</source>
      <translation variants="no">친구 또는 동료에게 %1을(를) 추천하시겠습니까?</translation>
    </message>
    <message numerus="no" id="qtn_pt_editfavorite_helpText">
      <source>qtn_pt_editfavorite_helpText</source>
      <translation variants="no">%1 홈 화면에서 이 장소까지 바로 이동하기 위한 빠르고 쉬운 여정을 확인하실 수 있습니다.</translation>
    </message>
    <message numerus="no" id="qtn_pt_routeplanner_to">
      <source>qtn_pt_routeplanner_to</source>
      <translation variants="no">도착</translation>
    </message>
    <message numerus="no" id="qtn_pt_journeydetails_title">
      <source>qtn_pt_journeydetails_title</source>
      <translation variants="no">여정 %1/%2</translation>
    </message>
    <message numerus="no" id="qtn_pt_ttdropdown_transportmode_6">
      <source>qtn_pt_ttdropdown_transportmode_6</source>
      <translation variants="no">페리</translation>
    </message>
    <message numerus="no" id="qtn_pt_editfavorite_title">
      <source>qtn_pt_editfavorite_title</source>
      <translation variants="no">즐겨찾기</translation>
    </message>
    <message numerus="no" id="qtn_pt_stationdetails_elevators">
      <source>qtn_pt_stationdetails_elevators</source>
      <translation variants="no">엘리베이터</translation>
    </message>
    <message numerus="no" id="qtn_pt_ttfilterpage_select_transport">
      <source>qtn_pt_ttfilterpage_select_transport</source>
      <translation variants="no">선호하는 교통 수단 모드를 선택하십시오.</translation>
    </message>
    <message numerus="no" id="qtn_pt_editfavorite_caption">
      <source>qtn_pt_editfavorite_caption</source>
      <translation variants="no">즐겨찾기 목적지 저장</translation>
    </message>
    <message numerus="no" id="qtn_pt_favoritedestinationitem_unavailable">
      <source>qtn_pt_favoritedestinationitem_unavailable</source>
      <translation variants="no">여정을 표시할 수 없음</translation>
    </message>
    <message numerus="no" id="qtn_pt_unit_meter">
      <source>qtn_pt_unit_meter</source>
      <translation variants="no">미터</translation>
    </message>
    <message numerus="no" id="qtn_pt_journeydetails_navigation_text">
      <source>qtn_pt_journeydetails_navigation_text</source>
      <translation variants="no">지도가 실행되는 동안 잠시만 기다려 주십시오.</translation>
    </message>
    <message numerus="no" id="qtn_pt_journeycalendaritem_in_minutes">
      <source>qtn_pt_journeycalendaritem_in_minutes</source>
      <translation variants="no">%1분 후</translation>
    </message>
    <message numerus="no" id="qtn_pt_homepage_update_cancel">
      <source>qtn_pt_homepage_update_cancel</source>
      <translation variants="no">취소</translation>
    </message>
    <message numerus="no" id="qtn_pt_homepage_update_low_text">
      <source>qtn_pt_homepage_update_low_text</source>
      <translation variants="no">이 앱에 대해 업데이트를 사용할 수 있습니다. 지금 설치하려면 '업데이트'를, 건너뛰려면 '나중에'를 누르십시오.</translation>
    </message>
    <message numerus="no" id="qtn_pt_editfavorite_create">
      <source>qtn_pt_editfavorite_create</source>
      <translation variants="no">저장</translation>
    </message>
    <message numerus="no" id="qtn_pt_feedback_negative">
      <source>qtn_pt_feedback_negative</source>
      <translation variants="no">절대 추천 안 함</translation>
    </message>
    <message numerus="no" id="qtn_pt_departures_header_label">
      <source>qtn_pt_departures_header_label</source>
      <translation variants="no">인근 교통 수단 검색</translation>
    </message>
    <message numerus="no" id="qtn_pt_timepicker_arrival">
      <source>qtn_pt_timepicker_arrival</source>
      <translation variants="no">도착</translation>
    </message>
    <message numerus="no" id="qtn_pt_aboutpage_buildnumber">
      <source>qtn_pt_aboutpage_buildnumber</source>
      <translation variants="no">%1 적용 중</translation>
    </message>
    <message numerus="no" id="qtn_pt_journeydetails_platform">
      <source>qtn_pt_journeydetails_platform</source>
      <translation variants="no">플랫폼 %1</translation>
    </message>
    <message numerus="no" id="qtn_pt_routeplanner_earlier_drag">
      <source>qtn_pt_routeplanner_earlier_drag</source>
      <translation variants="no">이전 여정을 살펴보시려면 드래그하십시오.</translation>
    </message>
    <message numerus="no" id="qtn_pt_routeplanner_later_hold">
      <source>qtn_pt_routeplanner_later_hold</source>
      <translation variants="no">이후 여정을 살펴보시려면 누르십시오.</translation>
    </message>
    <message numerus="no" id="qtn_pt_routeplanner_simpleroutinghint">
      <source>qtn_pt_routeplanner_simpleroutinghint</source>
      <translation variants="no">이 여정에 대한 정확한 스케줄을 제공할 수 없습니다.</translation>
    </message>
    <message numerus="no" id="qtn_pt_feedback_send_error">
      <source>qtn_pt_feedback_send_error</source>
      <translation variants="no">피드백을 전송할 수 없습니다.</translation>
    </message>
    <message numerus="no" id="qtn_pt_error_places">
      <source>qtn_pt_error_places</source>
      <translation variants="no">결과를 찾을 수 없습니다.</translation>
    </message>
    <message numerus="no" id="qtn_pt_ttdropdown_transportmode_8">
      <source>qtn_pt_ttdropdown_transportmode_8</source>
      <translation variants="no">전차</translation>
    </message>
    <message numerus="no" id="qtn_pt_routeplanner_earlier_loading">
      <source>qtn_pt_routeplanner_earlier_loading</source>
      <translation variants="no">이전 여정 가져오기</translation>
    </message>
    <message numerus="no" id="qtn_pt_homepage_update_exit">
      <source>qtn_pt_homepage_update_exit</source>
      <translation variants="no">닫기</translation>
    </message>
    <message numerus="no" id="qtn_pt_estimate_time">
      <source>qtn_pt_estimate_time</source>
      <translation variants="no">~%1</translation>
    </message>
    <message numerus="no" id="qtn_pt_stationdetails_bicyclesallowed">
      <source>qtn_pt_stationdetails_bicyclesallowed</source>
      <translation variants="no">자전거 도로</translation>
    </message>
    <message numerus="no" id="qtn_pt_departurenearbystations_nodepartures">
      <source>qtn_pt_departurenearbystations_nodepartures</source>
      <translation variants="no">1시간 이내 출발 여정 없음</translation>
    </message>
    <message numerus="no" id="qtn_pt_homepage_update_timeleft">
      <source>qtn_pt_homepage_update_timeleft</source>
      <translation variants="no">%1 남음</translation>
    </message>
    <message numerus="no" id="qtn_pt_ttdropdown_transportmode_2">
      <source>qtn_pt_ttdropdown_transportmode_2</source>
      <translation variants="no">고속 열차</translation>
    </message>
    <message numerus="no" id="qtn_pt_feedback_submit">
      <source>qtn_pt_feedback_submit</source>
      <translation variants="no">전송</translation>
    </message>
    <message numerus="no" id="qtn_pt_app_error">
      <source>qtn_pt_app_error</source>
      <translation variants="no">문제가 발생했습니다.</translation>
    </message>
    <message numerus="no" id="qtn_pt_favoritedestinationitem_alreadythere">
      <source>qtn_pt_favoritedestinationitem_alreadythere</source>
      <translation variants="no">현재 위치</translation>
    </message>
    <message numerus="no" id="qtn_pt_error_hafas_stations">
      <source>qtn_pt_error_hafas_stations</source>
      <translation variants="no">결과를 찾을 수 없습니다.
%1</translation>
    </message>
    <message numerus="no" id="qtn_pt_autocompletion_start_searching">
      <source>qtn_pt_autocompletion_start_searching</source>
      <translation variants="no">검색 중</translation>
    </message>
    <message numerus="no" id="qtn_pt_autocompletion_currentposition_with_address">
      <source>qtn_pt_autocompletion_currentposition_with_address</source>
      <translation variants="no">현재 위치, %1</translation>
    </message>
    <message numerus="no" id="qtn_pt_unit_foot">
      <source>qtn_pt_unit_foot</source>
      <translation variants="no">피트</translation>
    </message>
    <message numerus="no" id="qtn_pt_aboutpage_termsconditions">
      <source>qtn_pt_aboutpage_termsconditions</source>
      <translation variants="no">서비스 약관</translation>
    </message>
    <message numerus="no" id="qtn_pt_departureitem_loading">
      <source>qtn_pt_departureitem_loading</source>
      <translation variants="no">로드 중</translation>
    </message>
    <message numerus="no" id="qtn_pt_timepicker_in_60min">
      <source>qtn_pt_timepicker_in_60min</source>
      <translation variants="no">60분 후</translation>
    </message>
    <message numerus="no" id="qtn_pt_error_hafas_connections">
      <source>qtn_pt_error_hafas_connections</source>
      <translation variants="no">여정을 찾을 수 없습니다.</translation>
    </message>
    <message numerus="no" id="qtn_pt_routeplanner_title">
      <source>qtn_pt_routeplanner_title</source>
      <translation variants="no">여정 플래너</translation>
    </message>
    <message numerus="no" id="qtn_pt_stationdetails_escalators">
      <source>qtn_pt_stationdetails_escalators</source>
      <translation variants="no">에스컬레이터</translation>
    </message>
    <message numerus="no" id="qtn_pt_aboutpage_noteofthanks">
      <source>qtn_pt_aboutpage_noteofthanks</source>
      <translation variants="no">감사 노트</translation>
    </message>
    <message numerus="no" id="qtn_pt_timepicker_title">
      <source>qtn_pt_timepicker_title</source>
      <translation variants="no">여정 옵션</translation>
    </message>
    <message numerus="no" id="qtn_pt_termsandconditions">
      <source>qtn_pt_termsandconditions</source>
      <translation variants="no">&lt;p&gt;서비스를 사용하거나 콘텐츠를 다운로드할 경우 서비스 사업자 네트워크를 통해 대량의 데이터가 전송될 수 있습니다.
모든 서비스가 항상 이용 가능하거나 정확한 것은 아닙니다. 이동 중 이 앱을 사용하는 경우 안전을 최우선으로 고려해야 합니다.
서비스 이용 시 위치 정보 전송이 포함될 수 있습니다.
Nokia 제품을 개선하고 보다 관련된 컨텐츠를 제공하기 위한 용도로 휴대전화와 서비스 이용에 관한 정보를 수집할 수 있습니다.
Nokia는 사용자의 사전 동의 없이 해당 데이터를 제3자와 절대 공유하지 않습니다.
개인 정보 보호 정책에 대한 자세한 내용은 [여기|%1]를 클릭하십시오.

'시작'을 선택하면 [Nokia 서비스 약관|%2]과 [개인 정보 보호 정책|%3]을 읽고 해당 내용에 동의함을 확인하는 것입니다.&lt;/p&gt;</translation>
    </message>
    <message numerus="no" id="qtn_pt_coverage_button_skip">
      <source>qtn_pt_coverage_button_skip</source>
      <translation variants="no">검색 건너뛰기</translation>
    </message>
    <message numerus="no" id="qtn_pt_coverage_button_showcoveredregions">
      <source>qtn_pt_coverage_button_showcoveredregions</source>
      <translation variants="no">적용되는 지역</translation>
    </message>
    <message numerus="no" id="qtn_pt_coverage_position_nocoverage">
      <source>qtn_pt_coverage_position_nocoverage</source>
      <translation variants="no">&lt;p&gt;현재 %1에 대한 정보를 제공하지 않습니다.
&lt;/p&gt;
&lt;p&gt;그러나 매일 새로운 도시가 신규로 추가되므로 나중에 방문하셔서 업데이트를 확인해주시기 바랍니다.&lt;/p&gt;</translation>
    </message>
    <message numerus="no" id="qtn_pt_coverage_title_nocoverage">
      <source>qtn_pt_coverage_title_nocoverage</source>
      <translation variants="no">죄송합니다.</translation>
    </message>
    <message numerus="no" id="qtn_pt_coverage_position_timetablecoverage">
      <source>qtn_pt_coverage_position_timetablecoverage</source>
      <translation variants="no">&lt;p&gt;
현재 위치가 &lt;b&gt;%1&lt;/b&gt;인 것으로 보입니다.
&lt;/p&gt;
&lt;p&gt;
당사는 %2을(를) 지원합니다.  &lt;br&gt;이 위치를 비롯하여 다른 많은 지역이 지원됩니다.
&lt;/p&gt;</translation>
    </message>
    <message numerus="no" id="qtn_pt_firsttimeuse_welcome">
      <source>qtn_pt_firsttimeuse_welcome</source>
      <translation variants="no">환영합니다</translation>
    </message>
    <message numerus="no" id="qtn_pt_coverage_button_continue">
      <source>qtn_pt_coverage_button_continue</source>
      <translation variants="no">계속</translation>
    </message>
    <message numerus="no" id="qtn_pt_coverage_button_retry">
      <source>qtn_pt_coverage_button_retry</source>
      <translation variants="no">다시 시도</translation>
    </message>
    <message numerus="no" id="qtn_pt_coverage_position_noposition">
      <source>qtn_pt_coverage_position_noposition</source>
      <translation variants="no">현재 위치를 찾을 수 없습니다. 적용 범위 목록을 확인하여 이 지역에서 앱이 작동하는지 확인하십시오.</translation>
    </message>
    <message numerus="no" id="qtn_pt_start">
      <source>qtn_pt_start</source>
      <translation variants="no">시작</translation>
    </message>
    <message numerus="no" id="qtn_pt_nothanks">
      <source>qtn_pt_nothanks</source>
      <translation variants="no">아니오</translation>
    </message>
    <message numerus="no" id="qtn_pt_stationdetails_title">
      <source>qtn_pt_stationdetails_title</source>
      <translation variants="no">정거장/정류장 정보</translation>
    </message>
    <message numerus="no" id="qtn_pt_journeydetails_walk_title">
      <source>qtn_pt_journeydetails_walk_title</source>
      <translation variants="no">도보 안내</translation>
    </message>
    <message numerus="no" id="qtn_pt_journeydetails_show_on_map_title">
      <source>qtn_pt_journeydetails_show_on_map_title</source>
      <translation variants="no">지도에 표시</translation>
    </message>
    <message numerus="no" id="qtn_pt_journeydetails_show_on_map_text">
      <source>qtn_pt_journeydetails_show_on_map_text</source>
      <translation variants="no">Nokia 맵에 &lt;b&gt;%1&lt;/b&gt;을(를) 표시할 준비가 되었습니다.</translation>
    </message>
    <message numerus="no" id="qtn_pt_journeydetails_show">
      <source>qtn_pt_journeydetails_show</source>
      <translation variants="no">지도에 표시</translation>
    </message>
    <message numerus="no" id="qtn_pt_journeydetails_go">
      <source>qtn_pt_journeydetails_go</source>
      <translation variants="no">출발</translation>
    </message>
    <message numerus="no" id="qtn_pt_linedetails_title">
      <source>qtn_pt_linedetails_title</source>
      <translation variants="no">회선 정보</translation>
    </message>
    <message numerus="no" id="qtn_pt_linedetails_on_time">
      <source>qtn_pt_linedetails_on_time</source>
      <translation variants="no">정시</translation>
    </message>
    <message numerus="no" id="qtn_pt_linedetails_late">
      <source>qtn_pt_linedetails_late</source>
      <translation variants="no">%1분 지연</translation>
    </message>
    <message numerus="no" id="qtn_pt_journeydetails_walk_text">
      <source>qtn_pt_journeydetails_walk_text</source>
      <translation variants="no">Nokia 맵에서 &lt;b&gt;%1&lt;/b&gt;(으)로 도보 안내를 시작할 준비가 되었습니다.</translation>
    </message>
    <message numerus="no" id="qtn_pt_feedback_contact">
      <source>qtn_pt_feedback_contact</source>
      <translation variants="no">추가 정보가 필요하면 연락 주십시오(옵션)</translation>
    </message>
    <message numerus="no" id="qtn_pt_feedback_contact_placeholder">
      <source>qtn_pt_feedback_contact_placeholder</source>
      <translation variants="no">이메일 주소</translation>
    </message>
    <message numerus="no" id="qtn_pt_feedback_privacy">
      <source>qtn_pt_feedback_privacy</source>
      <translation variants="no">귀하의 정보는 사용 중인 장치와 연관되어 [Nokia 개인 정보 보호 정책|%1]에 따라 처리됩니다.</translation>
    </message>
    <message numerus="no" id="qtn_pt_feedback_text_placeholder">
      <source>qtn_pt_feedback_text_placeholder</source>
      <translation variants="no">의견</translation>
    </message>
    <message numerus="no" id="qtn_pt_privacy">
      <source>qtn_pt_privacy</source>
      <translation variants="no">&lt;p&gt;
Nokia는 사용자의 프라이버시를 존중합니다.
Nokia 제품을 개선하고 보다 관련된 컨텐츠를 제공하기 위한 용도로 휴대전화와 서비스 이용에 관한 정보를 수집할 수 있습니다.

Nokia는 사용자의 사전 동의 없이 해당 데이터를 제3자와 절대 공유하지 않습니다.

[개인 정보 보호 정책|%1]

[%2의 개인 정보 보호 정책|%3]
&lt;/p&gt;</translation>
    </message>
    <message numerus="no" id="qtn_pt_aboutpage_support">
      <source>qtn_pt_aboutpage_support</source>
      <translation variants="no">지원</translation>
    </message>
    <message numerus="no" id="Application long caption">
      <source>Application long caption</source>
      <translation variants="no">대중교통</translation>
    </message>
    <message numerus="no" id="qtn_pt_error_noresults">
      <source>qtn_pt_error_noresults</source>
      <translation variants="no">사용 가능한 전체 경로가 없습니다.</translation>
    </message>
    <message numerus="no" id="qtn_pt_privacy_title">
      <source>qtn_pt_privacy_title</source>
      <translation variants="no">개인 정보 보호 정책</translation>
    </message>
    <message numerus="no" id="qtn_pt_routeplanner_input_watermark">
      <source>qtn_pt_routeplanner_input_watermark</source>
      <translation variants="no">경유지 또는 장소 검색</translation>
    </message>
    <message numerus="no" id="qtn_pt_location_no_info">
      <source>qtn_pt_location_no_info</source>
      <translation variants="no">선택한 위치</translation>
    </message>
    <message numerus="no" id="qtn_pt_location_taiwan">
      <source>qtn_pt_location_taiwan</source>
      <translation variants="no">대만</translation>
    </message>
    <message numerus="no" id="qtn_pt_location_taiwan_area">
      <source>qtn_pt_location_taiwan_area</source>
      <translation variants="no">대만 지역</translation>
    </message>
    <message numerus="no" id="Package name">
      <source>Package name</source>
      <translation variants="no">대중교통</translation>
    </message>
    <message numerus="no" id="Smart installer package name">
      <source>Smart installer package name</source>
      <translation variants="no">대중교통</translation>
    </message>
    <message numerus="no" id="qtn_pt_coverage_thanksforinstalling">
      <source>qtn_pt_coverage_thanksforinstalling</source>
      <translation variants="no">%1을(를) 설치해 주셔서 감사합니다.&lt;br&gt;현재 전세계 %2개 도시에서 스케줄되어 있는 경로 정보를 제공하고 있습니다.</translation>
    </message>
  </context>
</TS>
