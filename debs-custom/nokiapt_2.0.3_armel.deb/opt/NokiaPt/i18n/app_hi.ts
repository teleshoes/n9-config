<?xml version='1.0' encoding='utf-8'?>
<!DOCTYPE TS>
<TS version="2.0" sourcelanguage="en" language="hi">
    <context>
        <name/>
        <message id="qtn_pt_value_with_unit">
            <source/>
            <oldsource>qtn_pt_value_with_unit</oldsource>
            <translation type="unfinished">%1 %2</translation>
        </message>
        <message id="qtn_pt_splashscreen_welcome_to">
            <source/>
            <oldsource>qtn_pt_splashscreen_welcome_to</oldsource>
            <translation type="unfinished">निम्न में आपका स्वागत है</translation>
        </message>
        <message id="qtn_pt_value_less_than_one">
            <source/>
            <oldsource>qtn_pt_value_less_than_one</oldsource>
            <translation type="unfinished">&lt; 1</translation>
        </message>
        <message id="qtn_pt_unit_minute">
            <source/>
            <oldsource>qtn_pt_unit_minute</oldsource>
            <translation type="unfinished">मिनट</translation>
        </message>
        <message id="qtn_pt_unit_hour">
            <source/>
            <oldsource>qtn_pt_unit_hour</oldsource>
            <translation type="unfinished">घं.</translation>
        </message>
        <message id="qtn_pt_unit_mile">
            <source/>
            <oldsource>qtn_pt_unit_mile</oldsource>
            <translation type="unfinished">मील</translation>
        </message>
        <message id="qtn_pt_unit_kilometer">
            <source/>
            <oldsource>qtn_pt_unit_kilometer</oldsource>
            <translation type="unfinished">कि.मी.</translation>
        </message>
        <message id="Application short caption">
            <source/>
            <oldsource>Application short caption</oldsource>
            <translation type="unfinished">सार्वजनिक यातायात</translation>
        </message>
        <message id="qtn_pt_unit_meter">
            <source/>
            <oldsource>qtn_pt_unit_meter</oldsource>
            <translation type="unfinished">मी.</translation>
        </message>
        <message id="qtn_pt_unit_foot">
            <source/>
            <oldsource>qtn_pt_unit_foot</oldsource>
            <translation type="unfinished">फ़ुट</translation>
        </message>
        <message id="qtn_pt_location_no_info">
            <source/>
            <translation type="unfinished"/>
        </message>
    </context>
    <context>
        <name>QtApplicationCaptions</name>
        <message>
            <source>Application short caption</source>
            <extracomment>Application short caption, currently only relevant for application projects in Symbian.</extracomment>
            <translation type="unfinished">सार्वजनिक यातायात</translation>
        </message>
        <message>
            <source>Application long caption</source>
            <extracomment>Application long caption, currently only relevant for application projects in Symbian.</extracomment>
            <translation type="unfinished">सार्वजनिक यातायात</translation>
        </message>
    </context>
    <context>
        <name>QtPackageNames</name>
        <message>
            <source>Package name</source>
            <extracomment>Installation package name, currently only relevant for Symbian projects that deploy something.</extracomment>
            <translation type="unfinished">सार्वजनिक यातायात</translation>
        </message>
        <message>
            <source>Smart installer package name</source>
            <extracomment>Smart installer installation package name, currently only relevant for Symbian projects that deploy something.</extracomment>
            <translation type="unfinished">सार्वजनिक यातायात</translation>
        </message>
    </context>
</TS>
