function locationText(item, itemSource) {
    if (item) {
        var title = !itemSource || itemSource.indexOf("currentPosition") == -1
            ? (item.favoriteName || (item.title + (item.description && ", " + item.description)))
            : "";

        return title || item.address.asOneLine || item.address.country || "";
    }
    return "";
}

function getValueText(value, isCurrentPosition) {
    var locationStr = locationText(value, value && value.source);

    if (isCurrentPosition) {
        if (value && value.address && value.address.valid) {
            if (App.currentPosition.notAvailable) {
                return locationStr;
            }

            return qsTrId("qtn_pt_autocompletion_currentposition_with_address").arg(locationStr);
        }
        return qsTrId("qtn_pt_autocompletion_currentposition_no_address");
    }

    return (value && value.displayName) || "";
}

function clearLocationList() {
    autocompletions.listModel = [];
}

function updateLocationList(newSearch) {

    var getTypeScore = function(loc) {
        if ("currentPosition" === loc.source) {
            return 1000;
        }
        if ("PtStation" === loc.type) {
            return 500;
        }
        return 0;
    };

    clear();

    var rootArr = [App.currentPosition.location];

    var longNameFilter = {};
    if (exclude) {
        longNameFilter[exclude.displayName] = true;
    }

    var queryText = text; // copy property
    if (queryText.length > 0 && (!input.value || newSearch)) {
        autocompletions.listModel = undefined;
        var req = Search.queryPlace(queryText, App.currentPosition.location, true);
        req = req.joinQueries(
                    Search.queryFavorite(queryText),
                    //Search.queryContact(queryText),
                    App.source.supportsStationSearch
                        ? App.source.queryStation(queryText, App.currentPosition.location)
                        : Search.queryStation(queryText, App.currentPosition.location));
        req.finished.connect(function(error, results) {
                                 if (error === QueryResult.NoError) {
                                     if (results.length) {
                                         // filter results and replace locations with favorite instances
                                         results = results
                                         .filter(function(loc) { return !longNameFilter[loc.displayName]; })
                                         .map(function(loc) { return App.favorites.find(loc) || loc; })
                                         .sort(function(a, b) { return getTypeScore(b) - getTypeScore(a); });
                                         // filter active ?
                                         if (input.filter) {
                                             results = results.filter(function(loc) {
                                                                          return (input.filter == loc.type);
                                                                      });
                                         }
                                         results.forEach(function(loc) {
                                                             loc.parent = autocompletions.input;
                                                         });
                                     }
                                     autocompletions.listModel = results;
                                     app.analytics.logEvent("GotSearch", {
                                             numResults: results.length,
                                             searchStringLength: queryText.length,
                                             bearerType: req.bearerType || "?",
                                             responseTime: req.responseTime
                                         });
                                 } else {
                                     app.displayMessage("error", qsTrId("qtn_pt_error_places"), error);
                                     autocompletions.listModel = [];
                                     app.analytics.logEvent("GotSearchError", {
                                             errorCode: error,
                                             searchStringLength: queryText.length,
                                             bearerType: req.bearerType || "?",
                                             responseTime: req.responseTime
                                         });
                                 }
                             });
        App.queries.autoComplete = req;
    } else {
        // get favorites and filter them
        var favorites = App.favorites.get()
        .filter(function(loc) {
                    return rootArr.indexOf(loc) === -1 && !longNameFilter[loc.displayName];
                });
        // get history and filter them
        var history = App.history.get()
        .filter(function(loc) { // filter elements
                    return rootArr.indexOf(loc) === -1 && !App.favorites.find(loc) && !longNameFilter[loc.displayName];
                })
        .map(function(loc) { // mark favorites
                 return App.favorites.find(loc) || loc;
             });
        // merge nearby, favorites and history
        rootArr = rootArr.concat(favorites, history);

        autocompletions.listModel = rootArr;
    }
}

function clear() {
    autocompletions.listModel = [];
    cancelSearch();
}

function cancelSearch() {
    if (App.queries.autoComplete) {
        App.queries.autoComplete.cancel();
        App.queries.autoComplete.destroy();
        delete App.queries.autoComplete;
    }
}

function copyCurrentPosition() {
    var loc = App.currentPosition.location;
    var locCopy = Qt.createQmlObject("import com.nokia.pt 1.0 \n PtLocation {}", input);

    locCopy.latitude = loc.latitude;
    locCopy.longitude = loc.longitude;
    locCopy.source = loc.source;
    locCopy.title = "";
    locCopy.description = "";
    locCopy.address = loc.address;
    locCopy.parent = input;

    return locCopy;
}
