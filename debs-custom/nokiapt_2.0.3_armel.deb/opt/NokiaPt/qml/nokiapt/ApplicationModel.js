.pragma library

console.error = function() { console.log(["!"].concat(Array.prototype.slice.call(arguments))); }
console.warn = function() { console.log(["*"].concat(Array.prototype.slice.call(arguments))); }

Qt.include("../../js/base_fw.js");

var favorites;      // models/Favorites.qml
var history;        // models/History.qml
var storage;        // models/Storage.qml
var currentPosition;// models/CurrentPosition.qml || models/FakeCurrentPosition.qml
var ticketing;      // models/Ticketing.qml - if ticketing enabled

var convertedFavoriteRoutes = false;

// current source queries (for cancelling)
var queries = {};

var gcPreventer = {};

var settings = {};

var app = null;

var source;

var system;

var init = function(application, sourceType, sourceName, sys) {
    app = application;
    system = sys;

    if (sourceType == "native") {
        source = sourceName;
        app.sourceCompleted();
    } else {
        throw new Error("Only supported source is native");
    }
}

// pushs a page and calls the callback on returning to previous page
var pushPage = function pushPage(pageStack, page, args, callback) {
    var prevPage = pageStack.currentPage;

    var backHandler = function() {
        if ("Activating" === prevPage.statusStr && prevPage === pageStack.currentPage) {
            prevPage.statusStrChanged.disconnect(backHandler);
            callback();
        }
    }
    prevPage.statusStrChanged.connect(backHandler);

    return pageStack.push(page, args);
}

// Initialize all application models etc.
var sourceCompleted = function(app) {
    var Class;

    // create storage (must be the first component)
    if ((Class = Qt.createComponent("models/Storage.qml")).status !== 1) {
        throw new Error("Error while loading models/Storage.qml: " + Class.errorString());
    }
    storage = Class.createObject(app);

    // create position model
    var posComp = Qt.createComponent("models/CurrentPosition.qml");
    currentPosition = posComp.createObject(app);
    if (!currentPosition) {
        if (posComp.status == 3) {
            console.warn("Error while loading posComp: " + posComp.errorString());
        }
        posComp = Qt.createComponent("models/FakeCurrentPosition.qml");
        currentPosition = posComp.createObject(app);
    }
    if (posComp.status == 3) {
        throw new Error("Error while loading posComp: " + posComp.errorString());
    }

    // create favorites
    if ((Class = Qt.createComponent("models/Favorites.qml")).status !== 1) {
        throw new Error("Error while loading Class models/Favorites.qml: " + Class.errorString());
    }
    favorites = Class.createObject(app);

    // create history
    if ((Class = Qt.createComponent("models/History.qml")).status !== 1) {
        throw new Error("Error while loading Class models/History.qml: " + Class.errorString());
    }
    history = Class.createObject(app);

//    if (Ticket.ticketingAvailable) {
        // create ticketing
        if ((Class = Qt.createComponent("models/Ticketing.qml")).status !== 1) {
            throw new Error("Error while loading Class models/Ticketing.qml: " + Class.errorString());
        }
        ticketing = Class.createObject(app);
//    }

    settings = deserialize(storage.get("Settings_1.0") || "{}");
    console.log("settings loaded");

    // update from old versions
    updateFavoriteRoutes();
}

var saveSettings = function() {
    storage.set("Settings_1.0", serialize(settings));
    console.log("settings saved");
}

var updateFavoriteRoutes = function() {
    var converted = 0;

    var favRoutesString = storage.get("FavoriteRoutes_1.0");

    if (favRoutesString) {
        // Restore all route location objects
        var favoriteRoutes = deserialize(favRoutesString || "[]");
        for (var i = 0, l = favoriteRoutes.length; i < l; i++) {
            var from = null, to = null;

            favoriteRoutes[i].from.favoriteName = favoriteRoutes[i].to.favoriteName = "";
            if (favoriteRoutes[i].from.source.indexOf("currentPosition") === -1) {
                from = system.deserialize(favoriteRoutes[i].from, "favorites");
            }
            if (favoriteRoutes[i].to.source.indexOf("currentPosition") === -1) {
                to = system.deserialize(favoriteRoutes[i].to, "favorites");
            }

            if (!from && !to) {
                continue;
            }

            if (!from && to) {
                favorites.add(to, to.title || to.address.asOneLine, true);
            } else if (from && !to) {
                favorites.add(from, from.title || from.address.asOneLine, true);
            } else {
                history.add(from);
                history.add(to);
            }

            converted++;
        }

        storage.remove("FavoriteRoutes_1.0");

        console.log("converted", converted, "favorite routes");
    }

    convertedFavoriteRoutes = converted !== 0;
}

var Queue = function() {
    this._queue = [];
    this._in = false;
    this._canceller = null;
}
Queue.prototype = {
    add: function(fun, index) {
        if (undefined === index) {
            this._queue.push(fun);
        } else {
            this._queue.splice(index, 0, fun);
        }
        this._fire();
    },
    clear: function() {
        this._queue.length = 0;
        if (this._canceller) this._canceller();
        this._in = false;
    },
    _fire: function() {
        if (this._in) return;

        this._canceller = null;
        var that = this,
            fun = this._queue.shift();
        if (fun) {
            this._in = true;
            fun(function() {
                // req finished
                that._in = false;
                that._fire();
            }, function(canceller) {
                that._canceller = canceller;
            });
        }
    }
}

var queue = new Queue();
