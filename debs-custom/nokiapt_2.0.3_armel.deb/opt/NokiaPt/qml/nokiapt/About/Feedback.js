function submitVote(rating, comments, emailAddress) {
    app.forceActiveFocus();

    feedbackScene.busy = true;

    var areaType;
    if (App.currentPosition.notAvailable) {
        areaType = "no_position";
    } else {
        switch (App.source.routingTypeAt(App.currentPosition.location)) {
            case PublicTransportRouter.ROUTING_TIMETABLE: areaType = "timetable"; break;
            case PublicTransportRouter.ROUTING_SIMPLE_VERIFIED: areaType = "simple_verified"; break;
            case PublicTransportRouter.ROUTING_SIMPLE: areaType = "simple"; break;
            case PublicTransportRouter.ROUTING_NONE: areaType = "no_coverage"; break;
            default: areaType = "unknown"; break;
        }
    }

    var req = System.sendNpsFeedback(rating, comments, emailAddress, areaType);
    req.finished.connect(function(error, results) {
                             feedbackScene.busy = false;
                             if (error) {
                                 app.displayMessage("error", qsTrId("qtn_pt_feedback_send_error"));
                                 app.analytics.logEvent("SendingNPSError", {
                                     rating: rating,
                                     comments: comments | "",
                                     areaType: areaType
                                 });
                             } else {
                                 App.settings.lastNpsVote = Date.now();
                                 App.saveSettings();

                                 if (feedbackScene.pageStack.currentPage === feedbackScene) {
                                     feedbackScene.pageStack.pop();
                                 }
                                 app.analytics.logEvent("SendingNPS", {
                                     rating: rating,
                                     comments: comments | "",
                                     areaType: areaType
                                 });
                             }
                         });
}
