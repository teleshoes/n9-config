function queryStations() {
    stationModel.clear();
    departurePage.stations = undefined;
    departurePage.stationIndex = undefined;
    App.queue.clear();
    errorCode = QueryResult.NoError;

    if (!location) return;

    App.queue.add(function(next, canceller) {
        var req = App.source.queryNearbyStations(location, 10);
        req.finished.connect(function(error, results) {
            if (error === QueryResult.NoError) {
                // calc the max and average distance
                var maxDist = 0, avgDist = 0;
                results = results.filter(function(station) {
                    var dist = App.computeDistance(location, station);
                    if (dist > 20000) return false; // skip this station
                    maxDist = Math.max(maxDist, dist);
                    avgDist += dist;
                    return true;
                });
                results.forEach(function(station) {
                    stationModel.append({
                        displayName: station.displayName,
                        displayDepartures: "",
                        imageSource: "",
                        isMore: false,
                        isEnabled: true
                    });
                });
                departurePage.stations = results;
                app.analytics.logEvent("GotStations", {
                        numStationsFound: results.length,
                        rangeMax: Math.round(maxDist),
                        rangeAvg: Math.round(avgDist ? avgDist / results.length : 0),
                        bearerType: req.bearerType || "?",
                        responseTime: req.responseTime
                    });
            } else {
                departurePage.stations = [];
                app.analytics.logEvent("GotStationsError", {
                        errorCode: req.error,
                        bearerType: req.bearerType || "?",
                        responseTime: req.responseTime
                    });
            }
            departurePage.errorCode = error;
       });
       canceller(req.cancel);
    });

    if (mapLoader.ready) {
        map.location = location;
    }
}

function queryStationDepartures(station, i, callback, canceller) {
    var req = App.source.queryDepartures(station, new Date(new Date() - lateTime * 1000));
    req.finished.connect(function(error, results) {
            var _departures = departurePage.departures;
            _departures[i] = error === QueryResult.NoError ? results : [];

            stationModel.set(i, {
                    displayDepartures: getDepartures(_departures[i]),
                    imageSource: getIcon(_departures[i]),
                    isMore: isDepartures(_departures[i]),
                    isEnabled: isEnabled(_departures[i])
                });

            departurePage.departures = _departures;
            if (mapLoader.ready) {
                map.departures = _departures;
            }
            if (callback) {
                callback(error, _departures[i]);
            }
        });

    if (canceller) {
        canceller(req.cancel);
    }
}

function queryMissingStationDepartures() {
    if (departurePage.stations) {
        departurePage.stations.forEach(function(station, i) {
            if (!departurePage.departures[i]) {
                App.queue.add(function(next, canceller) {
                    queryStationDepartures(station, i, next, canceller);
                });
            }
        });
    } else {
//        stationModel.query(location);
        queryStations();
    }
}

function cleanup() {
    var cutTime = Date.now() - lateTime * 1000 + 60;
    var _departures = departurePage.departures;
    _departures.forEach(function(departure, i) {
        if (departure) {
            var l = _departures[i].length;
            _departures[i] = _departures[i].filter(function(elem) {
                   return elem.time >= cutTime
                });
            if (l !== _departures[i].length) {
                stationModel.set(i, {
                        displayDepartures: getDepartures(_departures[i]),
                        imageSource: getIcon(_departures[i]),
                        isMore: isDepartures(_departures[i]),
                        isEnabled: isEnabled(_departures[i])
                    });
            }
        }
    });
    departurePage.departures = _departures;
}

function getIcon(departures) {
    var icon;
    if (departures) {
        for (var i = 0, departure; (departure = departures[i]); i++) {
            if (!icon) icon = departure.line.transitType.defaultType.iconUri(34);
            else if (icon !== departure.line.transitType.defaultType.iconUri(34))
                return "../../../images/icon_all_transport_34X34.png";
        }
        return icon || "../../../images/icon_all_transport_34X34.png";
    }
    return "";
}

function getDepartures(departures) {
    var result = [];
    if (departures) {
        for (var i = 0; i < departures.length && i < 10; i++) {
            var name = departures[i].line.name;
            if (result.indexOf(name) < 0)
                result.push(departures[i].line.name);
        }
        return result.join(", ") || qsTrId("qtn_pt_departurenearbystations_nodepartures");
    }
    return "";
}

function isDepartures(departures) {
    return !!(departures && departures.length);
}

function isEnabled(departures) {
    return !departures || departures.length;
}
