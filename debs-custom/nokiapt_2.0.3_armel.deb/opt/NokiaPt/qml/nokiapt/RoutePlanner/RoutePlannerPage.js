Qt.include("../../js/base_fw.js");

// Todo: API needs improvement
// e.g. query(queryConf); -> queryConf can be cached (to replace caching of arguments)
function query(from, to, date, arrival, allowedTypes, info) {
    from = from || fromInput.value;
    to = to || toInput.value;

    listRef.load();
    reset();

    if (App.currentPosition.notAvailable &&
        ((!from && fromInput.isCurrentPosition) || (!to && toInput.isCurrentPosition))) {
        gpsWaitingIndicator.show();
        return;
    }

    routePlanner.from = from;
    routePlanner.to = to;

    if(!date) info = info || routePlanner.info;

    routePlanner.info = info; // please see function comment

    loadingIndicator.visible = true;
    errorNotification.errorCode = QueryResult.NoError;

    date = date || new Date();

    var analyticsData = App._currConReq = {
        from: _getLocationType(from),
        fromIndex: info.fromIndex,
        to: _getLocationType(to),
        toIndex: info.toIndex,
        time: arrival ? "arrival" : "departure",
        reason: "query"
    };

    var req = App.source.queryConnections(from, to,
                                          date,
                                          arrival,
                                          arrival ? 10 * 60 * 1000 : 4 * 60 * 1000 /* 4 min into the past, 10 for arrivals */,
                                          allowedTypes || null);
    req.finished.connect(function(error, result) {
                             routePlanner.lastSearchTime = new Date().getTime();
                             loadingIndicator.visible = false;

                             if (error === QueryResult.NoError && !result.connections.length) {
                                 error = QueryResult.NoResults;
                             }
                             if (error === QueryResult.NoError && result.connections.length) {
                                 listRef.list.setModel(result.connections);
                             }
                             errorNotification.errorCode = error;
                             routePlanner.journeys = result;

                             analyticsData = App.merge(analyticsData, {
                                 type: req.getProperty("routingMethod") || "?",
                                 bearerType: req.bearerType || "?",
                                 responseTime: req.responseTime
                             });
                             if (QueryResult.NoError === error) {
                                 app.analytics.logEvent("GotJourneys", App.merge(analyticsData, { numJourneys: result.connections.length }));
                             } else {
                                 app.analytics.logEvent("GotJourneysError", App.merge(analyticsData, { errorCode: error }));
                             }
                         });

    req.cancelled.connect(function() {
            loadingIndicator.visible = false;
            errorNotification.errorCode = QueryResult.NoError;
            app.analytics.logEvent("GotJourneysError", App.merge(analyticsData, { errorCode: "Cancelled" }));
            if (App.queries.connection) {
                App.queries.connection.destroy();
                delete App.queries.connection;
            }
        });
    App.queries.connection = req;
}

function reset() {
    routePlanner.from = null;
    routePlanner.to = null;
    routePlanner.journeys = null;

    if (listRef.list) {
        listRef.list.reset();
        listRef.list.setModel([]);
    }

    errorNotification.errorCode = QueryResult.NoError;

    if (App.queries.connection) {
        App.queries.connection.cancel();
    }
}

function updateInput(input, when, arrival, allowedTypes) {
    reset();

    if (!routePlanner.ignoreInputValueChanges) {
        if (toInput === input && toInput.value && (fromInput.value === toInput.value || fromInput.isCurrentPosition && toInput.isCurrentPosition)) {
            fromInput.isCurrentPosition = false;
            fromInput.value = fromInput.preValue = null;
        }
        if (fromInput === input && fromInput.value && (toInput.value === fromInput.value || toInput.isCurrentPosition && fromInput.isCurrentPosition)) {
            toInput.isCurrentPosition = false;
            toInput.value = toInput.preValue = null;
        }

        if (input === fromInput && fromInput.isSet() && !toInput.isSet()) {
            toInput.selected = true;
        } else if (input === toInput && toInput.isSet() && !fromInput.isSet()) {
            fromInput.selected = true;
        } else if (fromInput.isSet() && toInput.isSet()) {
            Logic.query(fromInput.value, toInput.value, when, arrival, allowedTypes, {
                    fromIndex: fromInput.valueIndex,
                    toIndex: toInput.valueIndex
                }); // might API needs improvement
            toInput.selected = false;
            fromInput.selected = false;
        }
    }
}

function _getLocationType(loc) {
    if (loc.source.indexOf("currentPosition") > -1) return "position";
    if (loc.favorite) return "favorite";
    if (App.history.contains(loc)) return "history";
    return "search";
}
