    function queryMore(routePlanner, earlier, snapper) {
        if (!routePlanner.journeys) {
            return;
        }

        var lastConnection = App.queries.connection;

        var analyticsData = App.merge(App._currConReq, {
            reason: earlier ? "earlier" : "later"
        });

        var req = App.source.queryMoreConnections(routePlanner.journeys, earlier);
        req.finished.connect(function(error, result) {
            analyticsData = App.merge(analyticsData, {
                    type: req.getProperty("routingMethod"),
                    bearerType: req.bearerType || "?",
                    responseTime: req.responseTime
                });

            if (error === QueryResult.NoError) {
                if (result.connections.length) {
                    var pos = list.getCurrentPosition();
                    var diff = result.connections.length - list.count
                    list.setModel(result.connections);

                    if (earlier) {
                        list.setCurrentPosition(pos.time, pos.conn + diff);
                    } else {
                        list.setCurrentPosition(pos.time, pos.conn);
                    }

                    lastConnection.destroy();
                    app.analytics.logEvent("GotJourneys", App.merge(analyticsData, {}));
                } else {
                    app.displayMessage("info", qsTrId("qtn_pt_routeplanner_nomoreconnections")); // "Found no more connections."
                }
            } else {
                app.displayMessage("error", error); // TODO: a real error message
                app.analytics.logEvent("GotJourneysError", App.merge(analyticsData, { error: error }));
            }
            routePlanner.journeys = result;
            snapper.finished();
        });

        req.cancelled.connect(function() {
            app.analytics.logEvent("GotJourneysError", App.merge(analyticsData, { error: "Cancelled" }));
        });

        App.queries.connection = req;
    }
