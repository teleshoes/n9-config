function isSameDay(date1, date2) {
    return (date1.getFullYear() === date2.getFullYear()) && (date1.getMonth() === date2.getMonth()) &&
            (date1.getDate() === date2.getDate());
}

function buildTimeToStartText(startTime, currTime) {
    var timeTillStart = Math.ceil((startTime - currTime)/60000);

    if (timeTillStart < 0) {
        return qsTrId("qtn_pt_journeycalendaritem_minutes_ago").arg(-timeTillStart);
    }

    if (timeTillStart == 0) {
        return qsTrId("qtn_pt_timepicker_now");
    } else if (timeTillStart > 0 && timeTillStart <= 120) {
        return qsTrId("qtn_pt_journeycalendaritem_in_minutes").arg(timeTillStart);  // "Your journey starts in %1 minutes"
    }

    var startDate = new Date(startTime);
    var now = new Date(currTime);
    // today?
    if (isSameDay(startDate, now)) {
        return qsTrId("qtn_pt_journeydetails_today");
    } else {
        // tomorrow?
        var tomorrow = new Date();
        tomorrow.setDate(now.getDate() + 1);
        if (isSameDay(startDate, tomorrow)) {
            return qsTrId("qtn_pt_journeydetails_tomorrow") + ", " + System.formatDateTime(startTime, qsTrId("qtn_pt_journeydetails_month_day")).datetime; // TODO: refactor
        }
    }

    return System.formatDate(startTime);
}

function bikeAllowed(model) {
    if (model && (model.length > 1 || !model[0].line.isWalk)) {
        var modelData;
        for (var i = 0, l=model.length; i < l; i++) {
            modelData = model[i];
            if (modelData.line.isWalk) continue;
            if (!modelData.line.bicyclesAllowed) return false;
        }
        return true;
    }
    return false;
}
