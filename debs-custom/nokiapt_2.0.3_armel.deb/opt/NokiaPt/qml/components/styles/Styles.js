.pragma library

var listItemStyle;
var listItemTextStyle;
var richTextStyle;
var viewHeadingStyle

function initialize(app) {
    var Class;

    if ((Class = Qt.createComponent("ListItemStyle.qml")).status !== 1) {
        throw new Error("Error while loading styles/ListItemStyle.qml: " + Class.errorString());
    }
    listItemStyle = Class.createObject(app);

    if ((Class = Qt.createComponent("ListItemTextStyle.qml")).status !== 1) {
        throw new Error("Error while loading styles/ListItemTextStyle.qml: " + Class.errorString());
    }
    listItemTextStyle = Class.createObject(app);

    if ((Class = Qt.createComponent("RichTextStyle.qml")).status !== 1) {
        throw new Error("Error while loading styles/RichTextStyle.qml: " + Class.errorString());
    }
    richTextStyle = Class.createObject(app);

    if ((Class = Qt.createComponent("ViewHeadingStyle.qml")).status !== 1) {
        throw new Error("Error while loading styles/ViewHeadingStyle.qml: " + Class.errorString());
    }
    viewHeadingStyle = Class.createObject(app);

}
