var formatDuration = function(duration) {
    if (duration < 0) {
        return "Gone";
    } else if (duration < 30000) {
        return "Now";
    }

    var hours = Math.floor(duration/3600000);
    var minutes = Math.floor(duration%3600000/60000);

    if (minutes < 10) {
        minutes = "0" + minutes;
    }

    return hours + ":" + minutes;
};

var computeDistance = function(from, to) {
    if (!from || !to) {
        return NaN;
    }
    // geometric mean radius of WGS84: 6371e3 meters
    var PI_OVER_180 = Math.PI / 180,
        latRadians = from.latitude * PI_OVER_180,
        otherLatRadians = to.latitude * PI_OVER_180;
    var distance = 6371e3 * 2 * Math.asin(Math.min( 1.0, Math.sqrt(
            Math.pow( Math.sin( latRadians - otherLatRadians ) / 2, 2 ) +
            Math.cos( latRadians ) * Math.cos( otherLatRadians ) *
            Math.pow( Math.sin( ( from.longitude * PI_OVER_180 ) -
            ( to.longitude  * PI_OVER_180 ) ) / 2, 2 ) ) ) );

    return distance;
};

var lastLog = new Date();
var log = function(string) {
    var logTime = new Date();
    var args = [Qt.formatTime(logTime, "hh:mm:ss.zzz"), logTime.getTime() - lastLog.getTime()].concat(splat(arguments));
    console.log.apply(console, args);
    lastLog = logTime;
};

var serialize = function(objectList) {
    return JSON.stringify(objectList, function(key, val) {
                              if ("parent" !== key) return val;
                          });
};

var deserialize = function(string) {
    return JSON.parse(string);
};

var beautify = function(object) {
    return JSON.stringify(object, function(key, val) {
                              if ("parent" !== key) return val;
                          }, 2);
};

var merge = function(obj /* source, source, source*/) {
    var sources = Array.prototype.slice.call(arguments, 1),
        i = 0,
        l = sources.length,
        source,
        result = obj || {};
    for (; i < l; i++) {
        source = sources[i];
        for (var key in source) {
            result[key] = source[key];
        }
    }
    return result;
}
