#!/bin/sh

echo "rootme" | devel-su -c "echo $1 > /sys/devices/omapdss/display0/backlight/display0/brightness"
